import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { fixupConfigRules } from '@eslint/compat';
import { FlatCompat } from '@eslint/eslintrc';
import js from '@eslint/js';
import { ReactJsRecommended } from '@nationalgrid-engineering/eslint-config-typescript/configs.mjs';
import config from '@nationalgrid-engineering/eslint-nges';
import reactRefresh from 'eslint-plugin-react-refresh';
import globals from 'globals';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const compat = new FlatCompat({
  baseDirectory: __dirname,
  recommendedConfig: js.configs.recommended,
  allConfig: js.configs.all,
});

export default [
  ...ReactJsRecommended,
  ...config,
  {
    ignores: ['**/dist'],
  },
  ...fixupConfigRules(
    compat.extends(
      'plugin:react-hooks/recommended',
      'plugin:storybook/recommended',
    ),
  ),
  {
    plugins: {
      'react-refresh': reactRefresh,
    },

    languageOptions: {
      globals: {
        ...globals.browser,
      },
    },

    rules: {
      'react-refresh/only-export-components': [
        'warn',
        {
          allowConstantExport: true,
        },
      ],
      'import/no-default-export': 'off',
    },
  },
];
