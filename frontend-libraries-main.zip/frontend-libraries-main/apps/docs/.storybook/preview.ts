import type { Preview } from '@storybook/react';

import { FlexDecorator } from './decorators/FlexDecorator';
import { ThemeDecorator } from './decorators/ThemeDecorator';

import './overrides.css';

const preview: Preview = {
  decorators: [FlexDecorator, ThemeDecorator],
  globalTypes: {
    theme: {
      name: 'Theme',
      description: 'Theme for the components',
      defaultValue: 'light',
      toolbar: {
        // The icon for the toolbar item
        icon: 'circlehollow',
        // Array of options
        items: [
          { value: 'light', icon: 'circlehollow', title: 'light' },
          { value: 'dark', icon: 'circle', title: 'dark' },
        ],
        // Property that specifies if the name of the item will be displayed
        showName: true,
      },
    },
  },
  parameters: {
    options: {
      storySort: {
        // method: 'alphabetical',
        order: [
          // 'Getting Started',
          'styled-components',
          [
            'introduction',
            ['Installation', 'Buttons', 'Inputs', 'Text', '*'],

            'buttons',
            'inputs',
            'text',
            'atoms',
            ['Colors', 'Colors (Dark Mode)', 'Colors (Base)', '*'],
            '*',
            'theme',
          ],
          '*',
          ['Installation', '*'],
        ],

        includeNames: true,
      },
    },
    actions: { argTypesRegex: '^on.*' },
    backgrounds: {
      default: 'bg',
      values: [
        {
          name: 'bg',
          value: 'bg',
        },
        {
          name: 'bgPrimary',
          value: 'bgPrimary',
        },
      ],
    },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
  },
};

export default preview;
