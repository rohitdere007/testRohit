import { create } from '@storybook/theming/create';

import {
  Color,
  getColor,
} from '../../../packages/styled-components/src/styles/color';
import { lightMode } from '../../../packages/styled-components/src/theme/modes';

const color = (c: Color) => getColor(c)({ theme: lightMode });

export const NGtheme = create({
  base: 'light',

  // Brand
  brandTitle: 'NGES Storybook',
  brandUrl: 'https://nationalgrid.com',
  brandImage: '/images/NationalGridLogo.png',
  brandTarget: '_self',

  // Typography
  fontBase: `${lightMode.fonts.body}`,
  fontCode: 'monospace',

  // Text
  textColor: color('fg'),
  textInverseColor: color('fgInverse'),
  textMutedColor: color('fgSubtle'),

  // SideBar
  colorPrimary: color('fg'),
  colorSecondary: color('fgPlaceholder'),

  // // // UI
  appBg: color('bgPrimary'), // left sidebar bg

  appContentBg: color('bg'), // main bg
  appBorderColor: color('border'), // border around main content and inputs
  appBorderRadius: 0,

  // Bar
  barBg: color('bgPrimary'),
  buttonBg: color('bgPrimary'),
  barSelectedColor: color('fg'),
  barHoverColor: color('fg'),
  barTextColor: color('fgSubtle'),

  // // // Top Toolbar default and active colors
  //

  // // Form colors
  inputBg: color('bgPrimary'),
  inputBorder: color('border'),
  inputTextColor: color('fg'),
  inputBorderRadius: 4,
});
