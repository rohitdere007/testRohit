import { dirname, join } from 'path';

import type { StorybookConfig } from '@storybook/react-vite';
import { mergeConfig } from 'vite';
import tsconfigPaths from 'vite-tsconfig-paths';

/**
 * This function is used to resolve the absolute path of a package.
 * It is needed in projects that use Yarn PnP or are set up within a monorepo.
 */
function getAbsolutePath(value: string): string {
  return dirname(require.resolve(join(value, 'package.json')));
}

const packages = [
  ['styled-components', 'styled-components'],
  ['styled-theme', 'styled-theme'],
  ['react-hot-toast', 'react-hot-toast'],
  ['react-select', 'react-select'],
  ['react-tiny-popover', 'react-tiny-popover'],
  ['headless-ui', 'headless-ui'],
];

const packageStories = packages.map(([dir, titlePrefix]) => ({
  directory: join('../../../packages', dir, 'src'),
  titlePrefix,
}));

const config: StorybookConfig = {
  stories: [
    ...packageStories,
    // { directory: './GettingStarted', titlePrefix: 'Getting Started' },
    './*.mdx',
  ],
  staticDirs: ['./public'],
  addons: [
    getAbsolutePath('@storybook/addon-a11y'),
    getAbsolutePath('@storybook/addon-essentials'),
    getAbsolutePath('@storybook/addon-interactions'),
    getAbsolutePath('storybook-addon-remix-react-router'),
  ],
  core: {
    builder: '@storybook/builder-vite', // 👈 The builder enabled here.
  },
  framework: {
    name: getAbsolutePath('@storybook/react-vite'),
    options: {},
  },
  docs: {
    autodocs: 'tag',
  },
  viteFinal: async (c) =>
    mergeConfig(c, {
      plugins: [tsconfigPaths()],
    }),
};
export default config;
