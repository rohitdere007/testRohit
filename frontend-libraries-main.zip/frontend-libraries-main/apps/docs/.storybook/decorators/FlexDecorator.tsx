import {
  Flex,
  MinHeightProps,
  getSpacing,
  isMinHeightProp,
  isPaddingPropName,
  minHeight as minHeightStyles,
  padding,
} from '@nationalgrid-engineering/styled-components';
import type { Decorator } from '@storybook/react';
import React, { PropsWithChildren } from 'react';
import styled from 'styled-components';

export const StoryWrapper = styled(Flex).withConfig({
  shouldForwardProp: (p) => !isMinHeightProp(p) && !isPaddingPropName(p),
})<PropsWithChildren<MinHeightProps>>`
  width: 100%;
  box-sizing: border-box;
  padding: ${getSpacing('3 3 9')};
  position: relative;
  ${minHeightStyles}
  ${padding}
`;

export const FlexDecorator: Decorator = (Story, context) => {
  if (context?.parameters?.layout !== 'flex') {
    return Story();
  }

  const direction = context?.parameters.flexDirection || 'column';
  const align = context?.parameters.alignItems || 'flex-start';
  const justify = context?.parameters.justifyContent || 'flex-start';
  const gap = context?.parameters.gap || 0;
  const minHeight = context?.parameters.minHeight;
  const paddingProp = context?.parameters.padding;
  const props = {
    direction,
    align,
    justify,
    gap,
    minHeight,
    padding: paddingProp,
  };
  return (
    <StoryWrapper {...props} className="nges-wrapper">
      <Story />
    </StoryWrapper>
  );
};
