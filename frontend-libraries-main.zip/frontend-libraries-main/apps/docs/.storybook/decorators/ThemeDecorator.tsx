import {
  Color,
  ThemeProvider,
  getColor,
} from '@nationalgrid-engineering/styled-components';
import { Decorator } from '@storybook/react';
import React from 'react';
import { createGlobalStyle } from 'styled-components';

export const StoryGlobalStyles = createGlobalStyle<{ $bg: Color }>`
  .docs-story.docs-story,
  .sb-show-main.sb-show-main {
    background-color: ${({ $bg, theme }) =>
      getColor($bg)({ theme })} !important;
  }
`;

export const ThemeDecorator: Decorator = (StoryFn, context) => {
  // Get values from story parameter first, else fallback to globals
  const theme = context.parameters.theme || context.globals.theme || 'light';
  const bg = context.globals.backgrounds?.value || 'bg';

  return (
    <ThemeProvider defaultValue={theme} fontPath="/fonts">
      <StoryGlobalStyles $bg={bg} />
      {StoryFn()}
    </ThemeProvider>
  );
};
