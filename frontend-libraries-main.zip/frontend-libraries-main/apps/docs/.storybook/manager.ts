import { addons } from '@storybook/manager-api';

import { NGtheme } from './NGtheme';

addons.setConfig({
  theme: NGtheme,
  showRoots: false,
});
