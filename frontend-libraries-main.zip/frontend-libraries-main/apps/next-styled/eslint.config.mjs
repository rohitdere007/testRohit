import path from "node:path";
import { fileURLToPath } from "node:url";
import { fixupConfigRules } from "@eslint/compat";
import eslint from "@eslint/js";
import { FlatCompat } from "@eslint/eslintrc";
import { NextJsRecommended } from "@nationalgrid-engineering/eslint-config-typescript/configs.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const compat = new FlatCompat({
    baseDirectory: __dirname,
    recommendedConfig: eslint.configs.recommended,
    allConfig: eslint.configs.all
});

export default [
    ...fixupConfigRules(compat.extends("next")), 
    ...NextJsRecommended,
    {
        files: ["**/*.spec.ts*"],
        ignores: ["**/.next"],
        rules: {
            "@typescript-eslint/no-var-requires": "off",
            "@typescript-eslint/no-explicit-any": "off",
        },
    },
];