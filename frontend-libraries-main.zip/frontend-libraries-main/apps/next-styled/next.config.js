/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ["@nationalgrid-engineering/styled-components"],
  compiler: {
    styledComponents: true,
  },
};

module.exports = nextConfig;
