module.exports = {
  root: true,
  extends: ['next'],
};