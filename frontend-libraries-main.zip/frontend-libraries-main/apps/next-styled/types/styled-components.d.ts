import { CSSProp } from 'styled-components';

import { ThemeType } from '@/theme/modes';

declare module 'styled-components' {
  // eslint-disable-next-line @typescript-eslint/no-empty-interface
  export interface DefaultTheme extends ThemeType {}
}

declare module 'react' {
  // eslint-disable-next-line unused-imports/no-unused-vars
  interface DOMAttributes<T> {
    css?: CSSProp;
  }
}
