import { BreakPoint } from '@nationalgrid-engineering/styled-components';
import { Property } from 'csstype';
import '@tanstack/react-table';

declare module '@tanstack/table-core' {
  // eslint-disable-next-line unused-imports/no-unused-vars
  interface ColumnMeta<TData extends RowData, TValue> {
    sticky?: BreakPoint;
    offset?: string;
    shadow?: boolean;
    align?: Property.TextAlign;
    width?: string;
    hideLabel?: boolean;
  }
}
