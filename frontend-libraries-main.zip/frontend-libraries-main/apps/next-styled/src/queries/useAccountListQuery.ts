import { ParsedUrlQuery } from 'querystring';

import { useQuery } from '@tanstack/react-query';

import { Account } from '@/app/api/accounts/route';
import {
  PaginationParams,
  SortParams,
  queryToPaginationParams,
  queryToSortParams,
} from '@/utils/url';

export type AccountListParams = PaginationParams & SortParams;

export const queryToAccountListParams = (
  query: ParsedUrlQuery,
): AccountListParams => {
  const { pageIndex, pageSize } = queryToPaginationParams(query);
  const { sortBy, sortOrder } = queryToSortParams(query);

  return {
    pageIndex,
    pageSize: pageSize <= 100 ? pageSize : 25,
    sortBy,
    sortOrder,
  };
};

export interface AccountListResponse {
  data: Account[];
  total: number;
}

const accountListApiCall = async (params: AccountListParams) => {
  const queryString = new URLSearchParams(
    params as unknown as Record<string, string>,
  );

  const resp = await fetch(
    `${process.env.BASE_URL ?? ''}/api/accounts${
      queryString && `?${queryString}`
    }`,
  );

  const json: AccountListResponse = await resp.json();

  if (!resp.ok) {
    throw json;
  }
  return json;
};

const getAccountListQueryKey = (options: Partial<AccountListParams>) => [
  'AccountList',
  options,
];

export const getAccountListQueryConfig = (params: ParsedUrlQuery) => {
  const options = queryToAccountListParams(params);
  return {
    queryKey: getAccountListQueryKey(options),
    queryFn: () => accountListApiCall(options),
  };
};

export const useAccountListQuery = (params: ParsedUrlQuery) =>
  useQuery<AccountListResponse, Error>(getAccountListQueryConfig(params));
