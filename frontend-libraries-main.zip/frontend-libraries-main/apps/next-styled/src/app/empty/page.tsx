import EmptyStatePage from '@/organisms/EmptyPage';

const EmptyState = () => <EmptyStatePage />;

export default EmptyState;
