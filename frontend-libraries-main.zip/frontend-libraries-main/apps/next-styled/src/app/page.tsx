import { ParsedUrlQuery } from 'querystring';

import {
  HydrationBoundary,
  QueryClient,
  dehydrate,
} from '@tanstack/react-query';

import { AccountListPage } from '@/organisms/AccountListPage';
import { getAccountListQueryConfig } from '@/queries/useAccountListQuery';

interface PageProps {
  searchParams?: Promise<{
    query?: ParsedUrlQuery;
    page?: string;
  }>;
}

const AccountList = async (props: PageProps) => {
  const queryClient = new QueryClient();
  const { query } = (await props.searchParams) || {};
  if (query) {
    await queryClient.prefetchQuery(getAccountListQueryConfig(query));
  }
  return (
    <HydrationBoundary state={dehydrate(queryClient)}>
      <AccountListPage />
    </HydrationBoundary>
  );
};

export default AccountList;
