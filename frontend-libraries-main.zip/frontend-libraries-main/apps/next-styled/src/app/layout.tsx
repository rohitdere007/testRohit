import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { PropsWithChildren } from 'react';

import StyledComponentsRegistry from '@/lib/StyledComponentsRegistry';
import { ThemeProvider } from '@/lib/ThemeProvider';
import { MainLayout } from '@/organisms/MainLayout';
import { AppInsightsProvider } from '@/providers/ApplicationInsights';
import { QueryProvider } from '@/providers/QueryProvider';

import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'NextJS Sample App',
  description: 'A Sample App using NextJS App Router & Styled Components',
};

export default function RootLayout({ children }: PropsWithChildren) {
  return (
    <html lang="en" dir="ltr">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body className={inter.className}>
        <AppInsightsProvider>
          <QueryProvider>
            <StyledComponentsRegistry>
              <ThemeProvider>
                <MainLayout>{children}</MainLayout>
              </ThemeProvider>
            </StyledComponentsRegistry>
          </QueryProvider>
        </AppInsightsProvider>
      </body>
    </html>
  );
}
