'use client';

import {
  EmptyState,
  SvgError,
} from '@nationalgrid-engineering/styled-components';

function NotFoundPage() {
  return (
    <EmptyState
      image={<SvgError />}
      title="Page not found"
      titleAs="h1"
      message="This is not the URL you're looking for."
    />
  );
}

export default NotFoundPage;
