import { faker } from '@faker-js/faker';

export type Account = {
  firstName: string;
  lastName: string;
  jobTitle: string;
  gender: string;
  age: number;
  visits: number;
  progress: number;
  status: 'relationship' | 'complicated' | 'single';
};

const newPerson = (): Account => ({
  firstName: faker.person.firstName(),
  lastName: faker.person.lastName(),
  jobTitle: faker.person.jobTitle(),
  gender: faker.person.gender(),
  age: faker.number.int(40),
  visits: faker.number.int(1000),
  progress: faker.number.int(100),
  status: faker.helpers.shuffle<Account['status']>([
    'relationship',
    'complicated',
    'single',
  ])[0] as Account['status'],
});

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const limit = Number(searchParams.get('pageSize')) || 5;
  // const page = Number(searchParams.get('page')) || 1;
  const data = Array(limit).fill(null).map(newPerson);
  return Response.json({ data, total: 500 });
}
