'use client';

import {
  Notification,
  Pagination,
  Skeleton,
  Table,
  TableBody,
  TableData,
  TableHead,
  TableHeader,
  TableHeaderButton,
  TableRow,
  TableSide,
  TableWrapper,
} from '@nationalgrid-engineering/styled-components';
import {
  CellContext,
  SortingState,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import React, { RefObject, useCallback, useRef } from 'react';

import { Account } from '@/app/api/accounts/route';
import { useAccountListColumns } from '@/hooks/useAccountListColumns';
import {
  queryToAccountListParams,
  useAccountListQuery,
} from '@/queries/useAccountListQuery';

export const AccountTable = () => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentQuery = new URLSearchParams(Array.from(searchParams.entries()));

  const query = {
    pageIndex: searchParams.get('pageIndex') || '0',
    pageSize: searchParams.get('pageSize') || '25',
    sortBy: searchParams.get('sortBy') || undefined,
    sortOrder: searchParams.get('sortOrder') || undefined,
  };

  const params = queryToAccountListParams(query);
  const { error, data, isFetching, isError } = useAccountListQuery(query);
  const { pageIndex, pageSize, sortBy, sortOrder } = params;
  const { total, data: columnData } = data || {};

  const activeButtonRef = useRef<HTMLButtonElement>();

  const pageCount = total ? Math.ceil(total / pageSize) : 0;

  const sorting: SortingState | undefined = sortBy
    ? [{ id: sortBy, desc: sortOrder === 'desc' }]
    : [];

  const onCellClick = useCallback(
    (
      ref: RefObject<HTMLButtonElement>,
      props: CellContext<Account, unknown>,
    ) => {
      activeButtonRef.current = ref.current || undefined;
      console.info('cell props', props);
    },
    [],
  );

  const columns = useAccountListColumns({ onCellClick });

  const table = useReactTable({
    data: columnData ?? Array(params.pageSize).fill({}),
    columns: isFetching
      ? columns.map(({ ...column }) => ({
          ...column,
          cell: () => <Skeleton height="24px" width="100%" />,
        }))
      : columns,
    pageCount,
    state: {
      pagination: { pageIndex, pageSize },
      sorting,
      columnPinning: {
        left: [],
        right: ['actions'],
      },
    },
    onColumnPinningChange: (args) => {
      console.info('onColumnPinningChange', args);
    },
    onPaginationChange: (args) => {
      console.info('onPaginationChange', args);
      // const obj: Partial<AccountListParams> = {};
      // for (const k in p) {
      //   switch (k) {
      //     case 'pageIndex':
      //     case 'pageSize':
      //       if (p[k] !== params[k]) {
      //         obj[k] = p[k];
      //       }
      //     default:
      //       break;
      //   }
      // }
      // if (Object.keys(obj).length) {
      //   setQueryParam(obj);
      // }
    },
    onSortingChange: (sortingUpdater) => {
      if (!sorting) {
        return;
      }
      const newSortArray = (
        sortingUpdater as (s: SortingState) => SortingState
      )(sorting);
      const [newSort] = newSortArray;

      if (newSort) {
        if (newSort.desc) {
          currentQuery.set('sortOrder', 'desc');
        } else {
          currentQuery.delete('sortOrder');
        }
        currentQuery.set('sortBy', newSort.id);
      } else {
        currentQuery.delete('sortBy');
        currentQuery.delete('sortOrder');
      }
      const search = currentQuery.toString();
      router.push(`${pathname}${search ? `?${search}` : ''}`);
    },
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
  });

  return (
    <>
      {isError && (
        <Notification title="We're Sorry" open>
          {error?.message || 'An Unexpected Error Occurred'}
        </Notification>
      )}
      <TableWrapper>
        <Table aria-label="Accounts Table" cellSize="sm">
          <TableHead sticky>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map(
                  ({ column, id, colSpan, isPlaceholder, getContext }) => {
                    const { header } = column.columnDef;
                    const headerText =
                      typeof header === 'string'
                        ? header
                        : header?.(getContext());
                    const sortHandler = column.getToggleSortingHandler();
                    const { sticky, offset, width, shadow, hideLabel } =
                      column.columnDef.meta || {};
                    return (
                      <TableHeader
                        key={id}
                        colSpan={colSpan}
                        aria-label={headerText}
                        side={column.getIsPinned().toString() as TableSide}
                        sticky={!!column.getIsPinned() && sticky}
                        offset={offset}
                        width={width}
                        shadow={shadow}
                        hideLabel={hideLabel}
                      >
                        {isPlaceholder
                          ? null
                          : sortHandler && (
                              <TableHeaderButton
                                onClick={sortHandler}
                                canSort={column.getCanSort()}
                                isSorted={column.getIsSorted()}
                                label={headerText}
                              >
                                {flexRender(header, getContext())}
                              </TableHeaderButton>
                            )}
                      </TableHeader>
                    );
                  },
                )}
              </TableRow>
            ))}
          </TableHead>
          {!isError && (
            <TableBody>
              {table.getRowModel().rows.map((row) => (
                <tr key={row.id}>
                  {row.getVisibleCells().map((cell) => {
                    const { sticky, offset, shadow, align } =
                      cell.column.columnDef.meta || {};
                    return (
                      <TableData
                        key={cell.id}
                        sticky={!!cell.column.getIsPinned() && sticky}
                        side={cell.column.getIsPinned().toString() as TableSide}
                        offset={offset}
                        shadow={shadow}
                        align={align}
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext(),
                        )}
                      </TableData>
                    );
                  })}
                </tr>
              ))}
            </TableBody>
          )}
        </Table>
      </TableWrapper>
      <Pagination
        setPageSize={(size: number) => {
          currentQuery.set('pageSize', '' + size);
          const search = currentQuery.toString();
          router.push(`${pathname}${search ? `?${search}` : ''}`);
        }}
        setPageIndex={(index: number) => {
          currentQuery.set('pageIndex', '' + index);
          const search = currentQuery.toString();
          router.push(`${pathname}${search ? `?${search}` : ''}`);
        }}
        pageSize={pageSize}
        pageIndex={pageIndex}
        pageCount={pageCount}
      />
    </>
  );
};
