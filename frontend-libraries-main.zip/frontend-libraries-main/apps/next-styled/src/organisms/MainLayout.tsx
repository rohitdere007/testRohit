'use client';

import {
  Layout,
  MainNav as Nav,
} from '@nationalgrid-engineering/styled-components';
import Head from 'next/head';
import { ReactElement, ReactNode } from 'react';

import { MainNav } from '@/organisms/MainNav';

import { AppHeader } from './AppHeader';

interface MainLayout {
  children?: ReactNode;
  title?: string;
}

export const MainLayout = ({ children, title }: MainLayout) => (
  <Layout>
    <Head>
      <link rel="shortcut icon" href="favicon.ico" />
      <title>{title}</title>
      <meta name="description" content="Hubble" />
    </Head>
    <Nav.Provider open>
      <AppHeader />
      <Layout.Columns>
        <MainNav />
        <Layout.Main overflow="hidden">{children}</Layout.Main>
      </Layout.Columns>
    </Nav.Provider>
  </Layout>
);

export const getMainLayout = (page: ReactElement) => (
  <MainLayout title={page.props.title}>{page}</MainLayout>
);
