'use client';

import { mdiWhiteBalanceSunny } from '@mdi/js';
import {
  AppBar,
  IconButton,
  MoonIcon,
  useThemeContext,
} from '@nationalgrid-engineering/styled-components';

export const AppHeader = () => {
  const [mode, setMode] = useThemeContext();

  return (
    <AppBar>
      <IconButton
        ghost
        icon={mode === 'light' ? <MoonIcon /> : mdiWhiteBalanceSunny}
        aria-label={(mode === 'light' ? 'Dark' : 'Light') + ' Mode'}
        onClick={() => setMode(mode === 'light' ? 'dark' : 'light')}
        size="xl"
      />
    </AppBar>
  );
};
