'use client';

import { mdiAccountHardHatOutline, mdiFolder } from '@mdi/js';
import { MainNav as Nav } from '@nationalgrid-engineering/styled-components';
import Link from 'next/link';

export const MainNav = () => (
  <Nav>
    <Nav.Item
      as={Link}
      href={'/'}
      icon={mdiAccountHardHatOutline}
      title="Something"
    />
    <Nav.Item as={Link} href={'/empty'} icon={mdiFolder} title="Empty State" />
    <Nav.Item
      as={Link}
      href={'/bar'}
      icon={mdiAccountHardHatOutline}
      title="Something Bar"
    />
    <Nav.Item
      as={Link}
      href={'/biz'}
      icon={mdiAccountHardHatOutline}
      title="Something Biz"
    />
    <Nav.Spacer />
  </Nav>
);
