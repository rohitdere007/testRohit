'use client';

import {
  Button,
  EmptyState,
  SvgNoResults,
} from '@nationalgrid-engineering/styled-components';

export const EmptyStatePage = () => (
  <EmptyState
    image={<SvgNoResults />}
    title="Welcome user, to an empty state screen"
    message="Some sort of message explaining the current situation to the user that isn't '500 Internal Server Error'"
    actions={
      <>
        <Button>Back</Button>
        <Button variant="primary">Create</Button>
      </>
    }
  />
);

export default EmptyStatePage;
