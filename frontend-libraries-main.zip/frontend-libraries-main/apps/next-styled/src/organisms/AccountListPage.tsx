'use client';

import { Breadcrumbs, Page } from '@nationalgrid-engineering/styled-components';

import { AccountTable } from './AccountTable';

export const AccountListPage = () => (
  <Page>
    <Page.Header>
      <Page.Title
        title="Accounts"
        breadcrumbs={
          <Breadcrumbs aria-label="Breadcrumbs">
            <Breadcrumbs.Current>Home</Breadcrumbs.Current>
          </Breadcrumbs>
        }
      />
    </Page.Header>
    <AccountTable />
  </Page>
);
