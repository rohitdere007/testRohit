'use client';

import { ThemeProvider as StyledThemeProvider } from '@nationalgrid-engineering/styled-components';
import { PropsWithChildren } from 'react';

export const ThemeProvider = ({ children }: PropsWithChildren) => (
  <StyledThemeProvider>{children}</StyledThemeProvider>
);
