import { objToQuery, queryToPaginationParams, queryToSortParams } from './url';

describe('queryToPaginationParams', () => {
  describe('pageSize', () => {
    it('should default to 25', () => {
      const { pageSize } = queryToPaginationParams({});
      expect(pageSize).toBe(25);
    });

    it('should return 25 if the query param is not numeric', () => {
      const { pageSize } = queryToPaginationParams({
        pageSize: 'foo',
      });
      expect(pageSize).toBe(25);
    });

    it('should take the first value if there is more than 1', () => {
      const { pageSize } = queryToPaginationParams({
        pageSize: ['50', '100'],
      });
      expect(pageSize).toBe(50);
    });
  });
  describe('pageIndex', () => {
    it('should default to 0', () => {
      const { pageIndex } = queryToPaginationParams({});
      expect(pageIndex).toBe(0);
    });

    it('should return 0 if the query param is not numeric', () => {
      const { pageIndex } = queryToPaginationParams({
        pageIndex: 'foo',
      });
      expect(pageIndex).toBe(0);
    });

    it('should take the first value if there is more than 1', () => {
      const { pageIndex } = queryToPaginationParams({
        pageIndex: ['50', '100'],
      });
      expect(pageIndex).toBe(50);
    });
  });
});

describe('queryToSortParams', () => {
  describe('sortBy', () => {
    it('should be undefined if not present in the query', () => {
      const { sortBy } = queryToSortParams({});
      expect(sortBy).toBe(undefined);
    });
    it('should return the string value if present', () => {
      const { sortBy } = queryToSortParams({ sortBy: 'foo' });
      expect(sortBy).toBe('foo');
    });
    it('should take the first value if there is more than 1', () => {
      const { pageSize } = queryToPaginationParams({
        pageSize: ['100', 'bar'],
      });
      expect(pageSize).toBe(100);
    });
  });
  describe('sortOrder', () => {
    it('should be undefined if not present in the query', () => {
      const { sortOrder } = queryToSortParams({});
      expect(sortOrder).toBe(undefined);
    });
    it('should default to asc when sortBy is present in the query', () => {
      const { sortOrder } = queryToSortParams({ sortBy: 'foo' });
      expect(sortOrder).toBe('asc');
    });
    it('should be undefined if sortBy is not present in the query', () => {
      const { sortOrder } = queryToSortParams({ sortOrder: 'asc' });
      expect(sortOrder).toBe(undefined);
    });
    it('should return undefined if is not valid', () => {
      const { sortOrder } = queryToSortParams({
        sortBy: 'foo',
        sortOrder: 'bar',
      });
      expect(sortOrder).toBe(undefined);
    });
    it('should return the passed value when both sortBy & sortOrder are valid', () => {
      const { sortOrder } = queryToSortParams({
        sortBy: 'foo',
        sortOrder: 'asc',
      });
      expect(sortOrder).toBe('asc');
    });
    it('should take the first value if there is more than 1', () => {
      const { sortOrder } = queryToSortParams({
        sortBy: 'foo',
        sortOrder: ['desc', 'asc'],
      });
      expect(sortOrder).toBe('desc');
    });
  });
});

describe('objToQuery', () => {
  test.each([[null], [undefined], [{}], [{ key: null }], [{ key: undefined }]])(
    'returns empty when object is %p',
    (input) => {
      expect(objToQuery(input)).toBe('');
    },
  );

  test.each([
    [{ a: '1', b: undefined, c: '2' }],
    [{ a: '1', b: null, c: '2' }],
    [{ a: '1', b: [null], c: '2' }],
  ])('prunes null or undefined from values %p', (input) => {
    expect(objToQuery(input)).toBe('a=1&c=2');
  });

  test.each([
    [{ a: ['1', '2'], b: '3' }],
    [{ a: [null, '1', '2'], b: ['3', undefined] }],
  ])('expands arrays %p', (input) => {
    expect(objToQuery(input)).toBe('a=1&a=2&b=3');
  });
});
