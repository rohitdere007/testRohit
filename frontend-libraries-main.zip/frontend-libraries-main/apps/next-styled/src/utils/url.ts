import { ParsedUrlQuery } from 'querystring';

import { SortDirection } from '@tanstack/react-table';

export interface PaginationParams {
  pageIndex: number;
  pageSize: number;
}

export const queryToPaginationParams = ({
  pageIndex: page = '0',
  pageSize: size = '25',
}: ParsedUrlQuery = {}): PaginationParams => {
  const [i] = Array.isArray(page) ? page : [page];
  const pageIndex = (!Number.isNaN(i) && parseInt(i, 10)) || 0;
  const [s] = Array.isArray(size) ? size : [size];
  const pageSize = (!Number.isNaN(s) && parseInt(s, 10)) || 25;
  return { pageIndex, pageSize };
};

export interface SortParams {
  sortBy?: string;
  sortOrder: false | SortDirection;
}

export const queryToSortParams = ({
  sortBy: by,
  sortOrder: order = 'asc',
}: ParsedUrlQuery = {}): SortParams => {
  const [sortBy] = Array.isArray(by) ? by : [by];
  const [firstOrder] = Array.isArray(order) ? order : [order];
  const sortOrder =
    sortBy && ['asc', 'desc'].includes(firstOrder) ? firstOrder : undefined;
  return { sortBy, sortOrder: sortOrder as SortDirection };
};

// null and undefined values are pruned
// array items are duplicated (null and undefined pruned)
export const objToQuery = <T extends object>(obj: T | undefined | null) =>
  Object.entries(obj || ({} as T))
    .reduce((params, [key, value]) => {
      if (value !== null && value !== undefined) {
        if (Array.isArray(value)) {
          value
            .filter((item) => item !== null && item !== undefined)
            .forEach((item) => params.append(key, item));
        } else {
          params.append(key, value);
        }
      }
      return params;
    }, new URLSearchParams())
    .toString();
