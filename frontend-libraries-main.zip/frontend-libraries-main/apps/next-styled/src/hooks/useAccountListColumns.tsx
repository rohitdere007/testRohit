import { mdiCommentTextMultipleOutline } from '@mdi/js';
import { IconButton } from '@nationalgrid-engineering/styled-components';
import { CellContext, ColumnDef } from '@tanstack/react-table';
import { RefObject, useRef } from 'react';

import { Account } from '@/app/api/accounts/route';

interface AccountListColumnEvents {
  onCellClick: (
    ref: RefObject<HTMLButtonElement>,
    props: CellContext<Account, unknown>,
  ) => void;
}

type CellProps = CellContext<Account, unknown> & AccountListColumnEvents;

const ActionsCell = ({ onCellClick, ...props }: CellProps) => {
  const ref = useRef<HTMLButtonElement>(null);

  return (
    <IconButton
      ref={ref}
      onClick={() => onCellClick(ref, props)}
      icon={mdiCommentTextMultipleOutline}
      aria-label="Comments"
      ghost
    />
  );
};

export const useAccountListColumns = ({
  onCellClick,
}: AccountListColumnEvents) => {
  const availableColumns: Record<string, ColumnDef<Account>> = {
    firstName: {
      id: 'firstName',
      accessorKey: 'firstName',
      header: 'Given Name',
      enableSorting: true,
      enablePinning: false,
    },
    lastName: {
      id: 'lastName',
      accessorKey: 'lastName',
      header: 'Family Name',
      enableSorting: true,
      enablePinning: false,
    },
    jobTitle: {
      id: 'jobTitle',
      accessorKey: 'jobTitle',
      header: 'Job Title',
      enableSorting: false,
      enablePinning: false,
    },
    age: {
      id: 'age',
      accessorKey: 'age',
      header: 'Age',
      enableSorting: false,
      enablePinning: false,
    },
    status: {
      id: 'status',
      accessorKey: 'status',
      header: 'Status',
      enableSorting: false,
      enablePinning: false,
    },
    visits: {
      id: 'visits',
      accessorKey: 'visits',
      header: 'Visits',
      enableSorting: false,
      enablePinning: false,
    },
    progress: {
      id: 'progress',
      accessorKey: 'progress',
      header: 'Progress',
      enableSorting: false,
      enablePinning: false,
    },
    actions: {
      id: 'actions',
      header: 'Actions',
      enableSorting: false,
      enablePinning: true,
      meta: {
        width: '48px',
        align: 'center',
        shadow: true,
        hideLabel: true,
      },
      cell: (props) => <ActionsCell {...props} onCellClick={onCellClick} />,
    },
  };

  const defaultColumns: Array<keyof typeof availableColumns> = [
    'firstName',
    'lastName',
    'jobTitle',
    'age',
    'visits',
    'progress',
    'status',
    'actions',
  ];

  return defaultColumns.map((key) => availableColumns[key]);
};
