'use client';
import {
  AppInsightsContext,
  ReactPlugin,
} from '@microsoft/applicationinsights-react-js';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import { FC, PropsWithChildren } from 'react';

const instrumentationKey =
  process.env.REACT_APP_APPLICATION_INSIGHTS_INSTRUMENTATION_KEY;

const reactPlugin = new ReactPlugin();
export const appInsights = new ApplicationInsights({
  config: {
    connectionString: instrumentationKey,
    extensions: [reactPlugin],
    extensionConfig: {},
    enableAutoRouteTracking: true,
    disableAjaxTracking: false,
    autoTrackPageVisitTime: true,
    enableCorsCorrelation: true,
    enableRequestHeaderTracking: true,
    enableResponseHeaderTracking: true,
  },
});

// Checks for existing key should be removed when it exists in .env
if (instrumentationKey) {
  appInsights.loadAppInsights();
}

export const AppInsightsProvider: FC<PropsWithChildren> = ({ children }) => (
  <AppInsightsContext.Provider value={reactPlugin}>
    {children}
  </AppInsightsContext.Provider>
);
