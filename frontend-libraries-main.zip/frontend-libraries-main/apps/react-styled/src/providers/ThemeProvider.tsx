import { ThemeProvider as StyledThemeProvider } from '@nationalgrid-engineering/styled-components';
import { PropsWithChildren } from 'react';

import { getTheme } from '../utils/theme';

const theme = getTheme() || undefined;

export const ThemeProvider = ({ children }: PropsWithChildren) => (
  <StyledThemeProvider defaultValue={theme}>{children}</StyledThemeProvider>
);
