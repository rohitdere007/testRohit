import { mdiPencil } from '@mdi/js';
import {
  Button,
  Drawer,
  Flex,
  HeadingText,
  Icon,
  InputRange,
  UIText,
  getSpace,
} from '@nationalgrid-engineering/styled-components';
import { Link } from 'react-router-dom';
import { styled } from 'styled-components';

import { Person } from '../types/Person';

interface DeveloperDrawerProps {
  activeRow: Person | null;
  onClose: () => void;
}

const DrawerBody = styled(Drawer.Body)`
  gap: ${getSpace(4)};
`;

export const DeveloperDrawer = ({
  activeRow,
  onClose,
}: DeveloperDrawerProps) => (
  <Drawer
    open={!!activeRow}
    onClose={onClose}
    onOverlayClick={onClose}
    size="lg"
  >
    <Drawer.Header>
      <Drawer.Title title="Developer Details" />
    </Drawer.Header>

    <DrawerBody>
      {activeRow && (
        <>
          <HeadingText size="xs" as="h2" weight="bold">
            User Information
          </HeadingText>

          <Flex direction="column" gap={1}>
            <HeadingText size="xs" as="h3" weight="bold">
              Name
            </HeadingText>
            <UIText>
              {activeRow?.givenName} {activeRow?.surname}
            </UIText>
          </Flex>

          <Flex direction="column" gap={1}>
            <HeadingText size="xs" as="h3" weight="bold">
              National Grid Email
            </HeadingText>
            <UIText>{activeRow?.email}</UIText>
          </Flex>

          <Flex direction="column" padding="0 0 2 0" gap={1}>
            <HeadingText size="xs" as="h3" weight="bold">
              Phone Number
            </HeadingText>
            <UIText>{activeRow?.phoneNumber}</UIText>
          </Flex>

          <HeadingText size="xs" as="h3" weight="bold">
            Skill Matrix
          </HeadingText>
          {activeRow?.skills.map((skill) => (
            <InputRange
              disabled
              label={skill.name}
              max={5}
              min={1}
              name="skillRating"
              value={skill.level}
            />
          ))}
        </>
      )}
    </DrawerBody>
    <Drawer.Footer>
      <Button
        size="md"
        variant="base"
        as={Link}
        to="/edit"
        title="National Grid"
      >
        <Icon icon={mdiPencil} />
        Update
      </Button>
    </Drawer.Footer>
  </Drawer>
);
