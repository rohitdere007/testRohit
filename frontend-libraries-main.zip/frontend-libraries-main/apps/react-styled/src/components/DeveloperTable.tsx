import { mdiDotsVertical } from '@mdi/js';
import {
  Flex,
  PlainIconButton,
  ScreenReaderText,
  Table,
  TableHeaderButton,
} from '@nationalgrid-engineering/styled-components';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';

import { Person } from '../types/Person';

import fakeData from './MockEmployees.json';

const columnHelper = createColumnHelper<Person>();

const columns = [
  columnHelper.accessor('givenName', {
    header: () => 'Firstname',
    cell: (info) => info.getValue(),
  }),
  columnHelper.accessor('surname', {
    header: () => 'Lastname',
    cell: (info) => info.getValue(),
  }),
  columnHelper.accessor('email', {
    header: () => 'Email',
    cell: (info) => info.getValue(),
  }),
  columnHelper.accessor('skills', {
    header: () => 'Skills',
    cell: (info) =>
      info
        .getValue()
        .map(({ name }) => name)
        .join(', '),
  }),
];

interface DeveloperTableProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  setActiveRow: (row: Person) => void;
}

export const DeveloperTable = ({
  searchTerm,
  setSearchTerm,
  setActiveRow,
}: DeveloperTableProps) => {
  const table = useReactTable({
    data: fakeData,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    state: {
      globalFilter: searchTerm,
    },
    onGlobalFilterChange: setSearchTerm,
  });

  return (
    <Table cellSize="md">
      <Table.Head sticky>
        {table.getHeaderGroups().map((headerGroup) => (
          <Table.Row key={headerGroup.id}>
            {headerGroup.headers.map(
              ({ column, id, isPlaceholder, getContext }) => {
                const { header } = column.columnDef;
                const headerText =
                  typeof header === 'string' ? header : header?.(getContext());
                const sortHandler = column.getToggleSortingHandler();

                return (
                  <Table.Header key={id}>
                    {isPlaceholder
                      ? null
                      : sortHandler && (
                          <TableHeaderButton
                            onClick={sortHandler}
                            canSort={column.getCanSort()}
                            isSorted={column.getIsSorted()}
                            label={headerText}
                          >
                            {flexRender(header, getContext())}
                          </TableHeaderButton>
                        )}
                  </Table.Header>
                );
              },
            )}
            <Table.Header>
              <ScreenReaderText>Actions</ScreenReaderText>
            </Table.Header>
          </Table.Row>
        ))}
      </Table.Head>
      <Table.Body>
        {table.getRowModel().rows.map((row) => (
          <Table.Row key={row.id}>
            {row.getVisibleCells().map((cell) => (
              <Table.Data key={cell.id}>
                {flexRender(cell.column.columnDef.cell, cell.getContext())}
              </Table.Data>
            ))}
            <Table.Data>
              <Flex direction="row" justify="flex-end">
                <PlainIconButton
                  icon={mdiDotsVertical}
                  onClick={() => {
                    setActiveRow(row.original);
                  }}
                />
              </Flex>
            </Table.Data>
          </Table.Row>
        ))}
      </Table.Body>
    </Table>
  );
};
