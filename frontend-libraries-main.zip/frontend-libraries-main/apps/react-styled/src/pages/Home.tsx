import { mdiAccountPlus } from '@mdi/js';
import {
  Button,
  Icon,
  InputSearch,
  Page,
} from '@nationalgrid-engineering/styled-components';
import { useState } from 'react';
import { Link } from 'react-router-dom';

import { DeveloperDrawer } from '../components/DeveloperDrawer';
import { DeveloperTable } from '../components/DeveloperTable';
import { Person } from '../types/Person';

export const Home = () => {
  const onClose = () => {
    setActiveRow(null);
  };

  const [activeRow, setActiveRow] = useState<Person | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <Page>
      <Page.Header>
        <Page.Title title="Developers" subtitle="A list of your developers" />
        <Page.Actions>
          <InputSearch
            label="Filter by Skill"
            value={searchTerm}
            placeholder="Search Skill"
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
            width="lg"
            hideLabel
            size="md"
          />
          <Button size="md" as={Link} to="/add" title="Add Developer">
            <Icon icon={mdiAccountPlus} />
            Add Developers
          </Button>
        </Page.Actions>
      </Page.Header>
      <DeveloperTable
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        setActiveRow={setActiveRow}
      />
      <DeveloperDrawer activeRow={activeRow} onClose={onClose} />
    </Page>
  );
};
