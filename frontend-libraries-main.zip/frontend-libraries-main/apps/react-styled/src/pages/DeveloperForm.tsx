import { mdiContentSave } from '@mdi/js';
import {
  Breadcrumbs,
  Button,
  Divider,
  Flex,
  Grid,
  HeadingText,
  Icon,
  Input,
  InputRange,
  Page,
  Section,
  UIText,
  getSize,
  getSpace,
  getSpacing,
} from '@nationalgrid-engineering/styled-components';
import { Controller, useForm } from 'react-hook-form';
import { styled } from 'styled-components';

import { Person } from '../types/Person';

const SKILLS = [
  'SQL',
  'C#',
  'ASP.Net#',
  'Python',
  'Java',
  'Ruby',
  'ReactJS',
  'EntityFramework',
  'HTML',
  'JavaScript',
];

export interface FormInputs extends Omit<Person, 'skills'> {
  skillsRating: number[];
}

interface DeveloperFormProps {
  data?: FormInputs;
}

const PageBody = styled(Page.Body)`
  gap: ${getSpace(6)};
  padding: ${getSpacing('3 0')};
`;

const PageInputs = styled.div`
  max-width: ${getSize(160)};
`;

export const DeveloperForm = ({ data }: DeveloperFormProps) => {
  const { register, control, handleSubmit } = useForm<FormInputs>({
    defaultValues: data,
  });
  const name = data ? `${data.givenName} ${data.surname}` : 'New Developer';
  return (
    <form onSubmit={handleSubmit((submitted) => console.info(submitted))}>
      <Page>
        <Page.Header>
          <Page.Title
            title={name}
            subtitle={
              data
                ? 'Edit Information and Skill Rating and delete Developer.'
                : 'Add your new developer info and skills. Once complete, click "Save".'
            }
            breadcrumbs={
              <Breadcrumbs>
                <Breadcrumbs.Item as="a" href="/" title="Developers">
                  Developers
                </Breadcrumbs.Item>
                <Breadcrumbs.Current>{name}</Breadcrumbs.Current>
              </Breadcrumbs>
            }
          />
          <Page.Actions>
            <Button
              type="submit"
              className=" bordered"
              size="lg"
              variant="primary"
            >
              <Icon icon={mdiContentSave} />
              Save
            </Button>
          </Page.Actions>
        </Page.Header>
        <PageBody>
          <Grid columnGap={3} rowGap={3}>
            <Grid.Cell span={[12, 4]}>
              <Flex direction="column" gap={1}>
                <HeadingText size="xs" as="h2" weight="bold">
                  User Information
                </HeadingText>
                <UIText color="fgSubtle">
                  Fill in the developers general information
                </UIText>
              </Flex>
            </Grid.Cell>

            <Grid.Cell span={[12, 8]}>
              <PageInputs>
                <Section width="100%">
                  <Section.Body border={false}>
                    <Grid rowGap={3} columnGap={3}>
                      <Grid.Cell span={[12, 6]}>
                        <Input
                          {...register('givenName')}
                          label="Given Name"
                          placeholder="Sample"
                          type="text"
                        />
                      </Grid.Cell>
                      <Grid.Cell span={[12, 6]}>
                        <Input
                          {...register('surname')}
                          label="Surname"
                          placeholder="User"
                          type="text"
                        />
                      </Grid.Cell>
                      <Grid.Cell span={12}>
                        <Input
                          {...register('email')}
                          label="Email"
                          placeholder="sample.user@nationalgrid.com"
                          type="email"
                        />
                      </Grid.Cell>
                      <Grid.Cell span={12}>
                        <Input
                          {...register('phoneNumber')}
                          label="Phone Number"
                          placeholder="+441234567890"
                          type="string"
                        />
                      </Grid.Cell>
                    </Grid>
                  </Section.Body>
                </Section>
              </PageInputs>
            </Grid.Cell>
          </Grid>
          <Divider />
          <Grid columnGap={3} rowGap={3}>
            <Grid.Cell span={[12, 4]}>
              <Flex direction="column" gap={1}>
                <HeadingText size="xs" as="h2" weight="bold">
                  Skill Matrix
                </HeadingText>
                <UIText color="fgSubtle">
                  Add your skills and the rate them on a scale of 1 - 5.
                </UIText>
              </Flex>
            </Grid.Cell>
            <Grid.Cell span={[12, 8]}>
              <PageInputs>
                <Section width="100%">
                  <Section.Body border={false}>
                    <Flex direction="column" gap={3}>
                      {SKILLS.map((skill, index) => (
                        <Controller
                          render={({ field }) => (
                            <InputRange
                              {...field}
                              label={skill}
                              max={5}
                              min={1}
                            />
                          )}
                          name={`skillsRating.${index}`}
                          control={control}
                        />
                      ))}
                    </Flex>
                  </Section.Body>
                </Section>
              </PageInputs>
            </Grid.Cell>
          </Grid>
        </PageBody>
      </Page>
    </form>
  );
};
