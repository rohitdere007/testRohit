type Skill = {
  name: string;
  level: number;
};

export type Person = {
  id: number;
  givenName: string;
  surname: string;
  email: string;
  phoneNumber: string;
  skills: Skill[];
};
