import {
  Layout,
  MainNav as Nav,
} from '@nationalgrid-engineering/styled-components';
import { PropsWithChildren } from 'react';
import { Outlet } from 'react-router-dom';

import { AppHeader } from './layout/AppHeader';
import { MainNav } from './layout/MainNav';

const App = ({ children }: PropsWithChildren) => (
  <Layout>
    <Nav.Provider open>
      <AppHeader />
      <Layout.Columns>
        <MainNav />
        <Layout.Main>
          <Outlet />
          {children}
        </Layout.Main>
      </Layout.Columns>
    </Nav.Provider>
  </Layout>
);

export default App;
