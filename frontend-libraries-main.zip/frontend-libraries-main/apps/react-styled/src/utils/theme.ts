const themeKey = 'nges.theme';

export const setTheme = (value: string) =>
  localStorage.setItem(themeKey, value);

export const getTheme = () =>
  localStorage.getItem(themeKey) as 'light' | 'dark' | null;
