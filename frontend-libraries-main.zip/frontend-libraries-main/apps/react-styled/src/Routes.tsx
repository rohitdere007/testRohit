import {
  EmptyState,
  SvgOnboarding,
} from '@nationalgrid-engineering/styled-components';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';

import App from './App';
import { DeveloperForm, FormInputs } from './pages/DeveloperForm';
import { Home } from './pages/Home';
import { ThemeProvider } from './providers/ThemeProvider';

const sampleUser: FormInputs = {
  id: 0,
  givenName: 'Sample',
  surname: 'User',
  email: 'sample.user@nationalgrid.com',
  phoneNumber: '555 0123',
  skillsRating: [3, 4, 2, 5, 1, 3, 2, 5, 5, 3],
};

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      {
        path: 'add',
        element: <DeveloperForm />,
      },
      {
        path: 'edit',
        element: <DeveloperForm data={sampleUser} />,
      },
      {
        path: 'empty',
        element: (
          <EmptyState
            image={<SvgOnboarding />}
            title="Empty State"
            message="This is an example of an empty state"
          />
        ),
      },
      {
        path: '',
        element: <Home />,
      },
    ],
  },
]);

export const Routes = () => (
  <ThemeProvider>
    <RouterProvider router={router} />
  </ThemeProvider>
);
