import { mdiMagnify } from '@mdi/js';
import { MainNav as Nav } from '@nationalgrid-engineering/styled-components';
import { NavLink } from 'react-router-dom';

export const MainNav = () => (
  <Nav inline>
    <Nav.Item as={NavLink} to="/" icon={mdiMagnify} title="Developers" />
    <Nav.Item as={NavLink} to="/empty" icon={mdiMagnify} title="Empty State" />
  </Nav>
);
