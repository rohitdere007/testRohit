import { mdiDotsGrid, mdiWhiteBalanceSunny } from '@mdi/js';
import {
  AppBar,
  IconButton,
  MoonIcon,
  ShowAt,
  useThemeContext,
} from '@nationalgrid-engineering/styled-components';

import { setTheme } from '../utils/theme';

export const AppHeader = () => {
  const [mode, setMode] = useThemeContext();

  return (
    <AppBar>
      <ShowAt breakpoint="sm">
        <IconButton
          aria-label="Account"
          ghost
          icon="M12,19.2C9.5,19.2 7.29,17.92 6,16C6.03,14 10,12.9 12,12.9C14,12.9 17.97,14 18,16C16.71,17.92 14.5,19.2 12,19.2M12,5A3,3 0 0,1 15,8A3,3 0 0,1 12,11A3,3 0 0,1 9,8A3,3 0 0,1 12,5M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"
          size="xl"
        />
      </ShowAt>
      <IconButton
        ghost
        icon={mode === 'light' ? <MoonIcon /> : mdiWhiteBalanceSunny}
        aria-label={(mode === 'light' ? 'Dark' : 'Light') + ' Mode'}
        onClick={() => {
          setTheme(mode === 'light' ? 'dark' : 'light');
          setMode(mode === 'light' ? 'dark' : 'light');
        }}
        size="xl"
      />
      <ShowAt breakpoint="sm">
        <IconButton aria-label="Dashboard" ghost icon={mdiDotsGrid} size="xl" />
      </ShowAt>
    </AppBar>
  );
};
