import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { FlatCompat } from '@eslint/eslintrc';
import js from '@eslint/js';
import { ReactJsRecommended } from '@nationalgrid-engineering/eslint-config-typescript/configs.mjs';
import testingLibrary from 'eslint-plugin-testing-library';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const compat = new FlatCompat({
  baseDirectory: __dirname,
  recommendedConfig: js.configs.recommended,
  allConfig: js.configs.all,
});

export default [
  ...ReactJsRecommended,
  ...compat.extends('plugin:testing-library/react'),
  {
    plugins: {
      'testing-library': testingLibrary,
    },
    rules: {
      'react/prop-types': 'off',
      'react/react-in-jsx-scope': 'off',
      '@next/next/no-html-link-for-pages': 'off',
      '@next/next/no-img-element': 'off',
      'import/no-default-export': 'error',
      'testing-library/no-node-access': ['off'],
    },
  },
  {
    files: ['turbo/generators/config.ts', '**/*.stories.tsx', '*.mjs'],
    rules: {
      'import/no-default-export': 'off',
    },
  },
];
