import { render, screen } from '@testing-library/react';

import { withTheme } from '@/utils/jest';

import { Avatar } from './Avatar';

const author = 'John Wayne';
const image = '/path/to/image.jpeg';

const params = { wrapper: withTheme };

describe('Avatar', () => {
  it('should render the image if passed', () => {
    render(<Avatar author={author} image={image} />, params);
    expect(screen.getByRole<HTMLImageElement>('img').src).toBe(
      'http://localhost' + image,
    );
  });

  it('should render initials if no image value is present', () => {
    render(<Avatar author={author} />, params);
    expect(screen.getByRole<HTMLImageElement>('img').src).toBe(
      'https://api.dicebear.com/7.x/initials/svg?chars=2&fontSize=40&size=32&radius=50&seed=JW',
    );
  });
});
