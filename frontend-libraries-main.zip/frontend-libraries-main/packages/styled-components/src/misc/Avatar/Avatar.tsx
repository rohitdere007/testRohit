import styled, { css } from 'styled-components';

import { getRadius } from '@/styles/radius';

interface AvatarProps {
  author: string;
  image?: string;
}

interface SizeProp {
  size: number;
}

const AvatarWrapper = styled.div.withConfig({
  shouldForwardProp: (propName) => propName !== 'size',
})<SizeProp>`
  border-radius: ${getRadius('full')};
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
  flex-shrink: 0;
`;

const AvatarImage = styled.img.withConfig({
  shouldForwardProp: (propName) => propName !== 'size',
})<SizeProp>`
  ${({ size }) => css`
    height: ${size}px;
    width: ${size}px;
  `}
`;

export const Avatar = ({ image, author }: AvatarProps) => {
  const size = 32;
  const src =
    image ||
    'https://api.dicebear.com/7.x/initials/svg' +
      '?chars=2' +
      '&fontSize=40' +
      '&size=' +
      size +
      '&radius=50' +
      '&seed=' +
      author.replace(/[^A-Z]+/g, '');

  return (
    <AvatarWrapper size={size}>
      <AvatarImage src={src} alt={author} size={size} />
    </AvatarWrapper>
  );
};
