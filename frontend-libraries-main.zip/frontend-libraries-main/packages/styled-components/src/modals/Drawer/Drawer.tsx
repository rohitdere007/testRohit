import { ReactNode } from 'react';

import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { ModalCloseContext } from '@/modals/Modal/ModalCloseContext';

import { DrawerBody } from './DrawerBody';
import { DrawerClose } from './DrawerClose';
import { DrawerContent } from './DrawerContent';
import { DrawerFooter } from './DrawerFooter';
import { DrawerHeader } from './DrawerHeader';
import { DrawerOverlay } from './DrawerOverlay';
import { DrawerTitle } from './DrawerTitle';
import { DrawerWrapper, DrawerWrapperProps } from './DrawerWrapper';

export interface DrawerProps extends Omit<DrawerWrapperProps, 'zIndex'> {
  onClose?: () => void;
  onOverlayClick?: () => void;
  overlay?: boolean;
  children: ReactNode;
  zIndex?: number;
}

const onCloseFallback = () => void 0;

export const Drawer = ({
  open: openProp = false,
  children,
  overlay,
  delay = 500,
  inline,
  left,
  size = 'lg',
  zIndex = 9997,
  onClose = onCloseFallback,
  onOverlayClick,
}: DrawerProps) => {
  const openState = useDebouncedValue(openProp, !openProp ? 500 : 0);
  if (!openProp && !openState) {
    return null;
  }

  return (
    <ModalCloseContext.Provider value={onClose}>
      <DrawerOverlay
        visible={!!overlay}
        delay={delay}
        open={openProp && openState}
        inline={inline}
        onClick={onOverlayClick}
        zIndex={zIndex}
      />
      <DrawerWrapper
        open={openProp && openState}
        delay={delay}
        size={size}
        inline={inline}
        left={left}
        zIndex={zIndex + 1}
      >
        <DrawerContent size={size} left={left} inline={inline}>
          {children}
        </DrawerContent>
      </DrawerWrapper>
    </ModalCloseContext.Provider>
  );
};

Drawer.displayName = 'Drawer';

Drawer.Title = DrawerTitle;
Drawer.Header = DrawerHeader;
Drawer.Close = DrawerClose;
Drawer.Body = DrawerBody;
Drawer.Footer = DrawerFooter;
