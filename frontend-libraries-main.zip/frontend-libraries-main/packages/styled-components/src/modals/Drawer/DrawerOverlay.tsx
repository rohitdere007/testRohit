import styled, { css } from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';
import { getColor } from '@/styles/color';

import { DrawerWrapperProps, isDrawerWrapperProp } from './DrawerWrapper';

export interface DrawerOverlayProps
  extends Pick<DrawerWrapperProps, 'delay' | 'open' | 'inline'> {
  visible: boolean;
  zIndex: number;
}

export const DrawerOverlay = styled.div.withConfig({
  shouldForwardProp: (p) =>
    !['visible', 'zIndex'].includes(p) && !isDrawerWrapperProp(p),
})<DrawerOverlayProps>`
  background: ${getColor('black')};
  opacity: ${({ open, visible }) => (visible && open ? 0.4 : 0)};
  transition: opacity ${({ delay }) => delay}ms ease-in-out;
  position: absolute;
  inset: 0;
  z-index: ${({ zIndex }) => zIndex};
  ${({ inline }) =>
    inline !== undefined &&
    css`
      ${getBreakpoint(inline === true ? 'md' : inline)} {
        pointer-events: none;
        opacity: 0;
      }
    `}
`;
