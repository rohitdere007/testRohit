import styled, { css } from 'styled-components';

import { Color, getColor } from '@/styles/color';

import { Dialog, DialogBaseProps, isDialogProp } from '../Dialog';

export interface DrawerDialogProps extends DialogBaseProps {
  width?: string;
  left?: boolean;
  bgColor?: Color;
}

const DrawerDialogElement = styled.dialog.withConfig({
  shouldForwardProp: (p) =>
    !isDialogProp(p) && !['width', 'left', 'bgColor'].includes(p),
})<DrawerDialogProps>`
  position: fixed;
  inset-inline-start: unset;
  inset-inline-end: unset;
  inset: unset;
  top: 0;
  bottom: 0;
  height: 100dvh;
  max-height: 100dvh;
  max-width: 100%;
  margin: unset;
  padding: 0;
  border: none;
  background: ${({ bgColor = 'bg', theme }) => getColor(bgColor)({ theme })};
  overflow: hidden;
  outline: none;

  ${({ width, left, open, delay }) => css`
    ${left ? 'left' : 'right'}: 0;
    transition: transform ${delay}ms ease-in-out;
    @media (prefers-reduced-motion) {
      transition-duration: 0ms;
    }
    width: ${width};
    transform: translate(${open ? 0 : left ? '-100%' : '100%'}, 0);
    box-shadow: 0px 0px 10px ${getColor('border')};
    &::backdrop {
      ${getColor('bgPrimary')};
      opacity: ${open ? 0.4 : 0};
      transition: opacity ${delay}ms ease-in-out;
      overflow: hidden;
    }
  `}
`;

export const DrawerDialog = (props: DrawerDialogProps) => (
  <Dialog {...props} as={DrawerDialogElement} />
);

DrawerDialog.defaultProps = {
  delay: 500,
  width: '30em',
};

DrawerDialog.displayName = 'Drawer.Dialog';
