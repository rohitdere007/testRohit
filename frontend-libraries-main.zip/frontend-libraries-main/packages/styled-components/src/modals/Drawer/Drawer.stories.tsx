import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';
import { BodyText } from '@/typography/BodyText';

import { Notification } from '../../info/Notification';
import { Confirm } from '../Confirm';

import { drawerSizes } from './DrawerContent';

import { Drawer, DrawerBody, DrawerFooter, DrawerHeader, DrawerTitle } from '.';

export default {
  component: Drawer,
  parameters: {
    layout: 'flex',
    minHeight: '500px',
    flexDirection: 'row',
    gap: 3,
    docs: {
      description: {
        component:
          '<p>The Drawer component is a screen height element that animates in from the side of the page</p>' +
          '<p>By default the drawer will open from the right of the page but can open from the left when provided a left prop boolean value</p>',
      },
    },
  },
  args: {
    size: 'lg',
    open: false,
    left: false,
    overlay: true,
    onOverlayClick: action('onOverlayClick'),
    onClose: action('onClose'),
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the dialog',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'If the dialog is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    left: {
      control: { type: 'boolean' },
      description: 'Open the dialog on the left instead of the right',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    inline: {
      control: { type: 'boolean' },
      description: 'If the drawer is inline',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    delay: {
      control: { type: 'number' },
      description: 'The time in miliseconds for the transitions',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '500' },
      },
    },
    size: {
      options: Object.keys(drawerSizes),
      description: 'The width of the drawer for larger breakpoints',
      table: {
        type: {
          summary: Object.keys(drawerSizes).join(' | '),
        },
        defaultValue: { summary: '"lg"' },
      },
      control: {
        type: 'select',
      },
    },
    zIndex: {
      control: { type: 'number' },
      description: 'The zIndex of the drawer overlay',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '9997' },
      },
    },
    onOverlayClick: {
      action: 'clicked',
      description:
        'The native dialog click handler to handle clicking the backdrop',
    },
    onClose: {
      description:
        'a method to set the value of the open prop when the dialog is closed',
    },
  },
} satisfies Meta<typeof Drawer>;

type Story = StoryObj<typeof Drawer>;

export const Demo: Story = {
  render: ({ open, ...props }) => {
    const [openState, setOpenState] = useState(open);

    const onClose = () => {
      setOpenState(false);
      props.onClose?.();
    };
    const onClick = () => {
      setOpenState(false);
      props.onOverlayClick?.();
    };

    return (
      <>
        <Drawer
          {...props}
          open={openState}
          onClose={onClose}
          onOverlayClick={onClick}
        >
          <DrawerHeader>
            <DrawerTitle title="Modal Title" />
          </DrawerHeader>
          <DrawerBody>
            <BodyText as="p">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Pellentesque magna diam, semper eget lectus vel, lacinia varius
              est. Proin egestas metus eget ex dictum, et fringilla nunc
              dapibus. Donec vel ligula dapibus, convallis arcu ut, scelerisque
              leo. Ut risus ipsum, dictum eu mauris ac, feugiat aliquet nisi.
              Morbi sagittis libero eu diam placerat malesuada. Vestibulum ante
              ipsum primis in faucibus orci luctus et ultrices posuere cubilia
              curae; Nulla facilisi. Nam at tristique erat.
            </BodyText>
          </DrawerBody>
          <DrawerFooter secondary={<Button onClick={close}>Secondary</Button>}>
            <Button variant="primary" onClick={close} autoFocus>
              Confirm
            </Button>
            <Button onClick={close}>Cancel</Button>
          </DrawerFooter>
        </Drawer>
        <Button onClick={() => setOpenState((prev) => !prev)}>
          {open ? 'Close' : 'Open'}
        </Button>
      </>
    );
  },
};

export const NestedDialogs: Story = {
  render: ({ open, ...props }) => {
    const [, updateArgs] = useArgs();

    const onClose = () => {
      updateArgs({ open: false });
      props.onClose?.();
    };
    const onClick = () => {
      updateArgs({ open: false });
      props.onOverlayClick?.();
    };

    const [isDeleteOpen, setIsDeleteOpen] = useState(false);

    return (
      <>
        <Button onClick={() => updateArgs({ open: !open })}>
          {open ? 'Close' : 'Open'}
        </Button>

        <Drawer
          {...props}
          open={open}
          onClose={onClose}
          onOverlayClick={onClick}
        >
          <DrawerHeader>
            <DrawerTitle title="Modal Title" />
          </DrawerHeader>
          <DrawerBody>
            <Notification open title="Success">
              Something was successful
            </Notification>
          </DrawerBody>
          <DrawerFooter
            secondary={
              <Button onClick={() => setIsDeleteOpen(true)}>Secondary</Button>
            }
          >
            <Button variant="primary" onClick={close} autoFocus>
              Confirm
            </Button>
            <Button onClick={close}>Cancel</Button>
          </DrawerFooter>
          <Confirm
            id="confirm"
            open={isDeleteOpen}
            title="Confirm Something"
            onConfirm={() => void 0}
            onClose={() => setIsDeleteOpen(false)}
          />
        </Drawer>
      </>
    );
  },
};
