import { mdiFileEdit } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';

import { Icon } from '../../atoms/Icon';

import { Drawer } from './Drawer';

export default {
  component: Drawer.Title,
  title: 'modals/Drawer.Title',
  args: {
    as: 'h1',
    title: 'Drawer Title',
    subtitle: 'Drawer Subtitle',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Drawer.Title` provides uniform props with other `Title` components. It requires a `title` value and takes optional `subtitle` & `icon` props. It is important to specify the `as` prop to specify a heading level to give context to screen readers.',
      },
    },
  },
  argTypes: {
    title: {
      control: {
        type: 'text',
      },
      description: 'The main title text',
      table: {
        type: { summary: 'string' },
      },
    },
    as: {
      control: {
        type: 'select',
      },
      description: 'the html element the title text should be contained within',
      defaultValue: 'span',
      table: {
        type: {
          summary: ['span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].join(
            ' | ',
          ),
        },
        defaultValue: { summary: '"span"' },
      },
      options: ['span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
    },
    subtitle: {
      control: {
        type: 'text',
      },
      description: 'The subtitle text',
      table: {
        type: { summary: 'string' },
      },
    },
    icon: {
      control: undefined,
      description: 'The Drawer icon',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Drawer.Title>;

type Story = StoryObj<typeof Drawer.Title>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer open={open} onClose={close} onOverlayClick={close}>
          <Drawer.Header>
            <Drawer.Title {...props} />
          </Drawer.Header>
          <Drawer.Body></Drawer.Body>
        </Drawer>
      </>
    );
  },
};

export const WithIcon: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer open={open} onClose={close} onOverlayClick={close}>
          <Drawer.Header>
            <Drawer.Title
              {...props}
              icon={<Icon icon={mdiFileEdit} size="lg" />}
            />
          </Drawer.Header>
          <Drawer.Body></Drawer.Body>
        </Drawer>
      </>
    );
  },
};
