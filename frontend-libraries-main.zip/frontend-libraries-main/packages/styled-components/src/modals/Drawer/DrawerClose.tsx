import { ModalClose, ModalCloseProps } from '../Modal';

export const DrawerClose: React.FC<ModalCloseProps> = (props) => (
  <ModalClose {...props} />
);

DrawerClose.displayName = 'Drawer.Close';
