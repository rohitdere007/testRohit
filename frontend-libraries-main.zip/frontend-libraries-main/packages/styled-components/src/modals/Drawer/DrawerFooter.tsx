import styled from 'styled-components';

import { ActionsFooter, ActionsFooterProps } from '@/layouts/ActionsFooter';

const DrawerFooterElement = styled.div`
  margin-top: auto;
`;

export const DrawerFooter = (props: ActionsFooterProps) => (
  <DrawerFooterElement>
    <ActionsFooter {...props} />
  </DrawerFooterElement>
);

DrawerFooter.displayName = 'Drawer.Footer';
