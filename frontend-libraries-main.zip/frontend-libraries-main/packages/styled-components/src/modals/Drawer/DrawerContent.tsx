import { PropsWithChildren } from 'react';
import styled, { css } from 'styled-components';

import { BreakPoint, getBreakpoint } from '@/styles/breakpoint';
import { Size, getSize } from '@/styles/size';

export type DrawerSize = 'sm' | 'md' | 'lg' | 'xl' | 'full';

export const drawerSizes: Record<DrawerSize, Size> = {
  sm: 60,
  md: 80,
  lg: 112,
  xl: 160,
  full: '100%',
};

export interface DrawerContentProps extends PropsWithChildren {
  inline?: true | BreakPoint;
  size?: DrawerSize | Size;
  left?: boolean;
}

export const isDrawerContentProp = (p: string) =>
  ['inline', 'size', 'left'].includes(p);

export const DrawerContent = styled.div.withConfig({
  shouldForwardProp: (p) => !isDrawerContentProp(p),
})<DrawerContentProps>`
  position: relative;
  width: ${({ size, theme }) =>
    getSize(drawerSizes[size as DrawerSize] || size)({ theme })};
  max-width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  ${({ left }) =>
    left
      ? css`
          left: 0;
        `
      : css`
          right: 0;
        `}

  ${({ inline }) =>
    inline !== undefined &&
    css`
      ${getBreakpoint(inline === true ? 'md' : inline)} {
        max-width: unset;
      }
    `}
`;
