import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';
import { Drawer } from '@/modals/Drawer';

import { DrawerHeader } from './DrawerHeader';

export default {
  component: DrawerHeader,
  title: 'modals/Drawer.Header',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Drawer.Header` component is a header element expecting a single child. The `Drawer.Header` provides the `Modal.Close` instance. Most commonly it would be used within a `Drawer` and have a `Drawer.Title` instance as a child.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof DrawerHeader>;

type Story = StoryObj<typeof DrawerHeader>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer open={open} onClose={close} onOverlayClick={close}>
          <Drawer.Header {...props}>
            <Drawer.Title title="Hello World" />
          </Drawer.Header>
          <Drawer.Body></Drawer.Body>
        </Drawer>
      </>
    );
  },
};
