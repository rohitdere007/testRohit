import styled from 'styled-components';

import { getSpace, getSpacing } from '@/styles/space';

export const DrawerBody = styled.div`
  padding: ${getSpacing('2 3')};
  display: flex;
  flex-direction: column;
  gap: ${getSpace(2)};
  overflow: auto;
  height: 100%;
`;

DrawerBody.displayName = 'Drawer.Body';
