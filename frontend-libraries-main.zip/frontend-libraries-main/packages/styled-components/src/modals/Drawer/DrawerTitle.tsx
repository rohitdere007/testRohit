import { Flex } from '@/atoms/Flex';
import { SectionTitleProps } from '@/layouts/Section/SectionTitle';
import { UIText } from '@/typography/UIText';

type DrawerTitleProps = SectionTitleProps;

export const DrawerTitle = ({
  icon,
  as,
  title,
  subtitle,
}: DrawerTitleProps) => (
  <Flex gap={2} direction="row" align="center" justify="center">
    {icon}
    <Flex direction="column" gap="0.5" justify="center">
      <UIText size="xl" weight="semi-bold" color="fg" as={as}>
        {title}
      </UIText>
      {subtitle && <UIText color="fgSubtle">{subtitle}</UIText>}
    </Flex>
  </Flex>
);

DrawerTitle.displayName = 'Drawer.Title';
