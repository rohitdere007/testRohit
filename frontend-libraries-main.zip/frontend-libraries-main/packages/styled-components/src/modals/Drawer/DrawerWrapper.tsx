import styled, { css } from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';
import { getColor } from '@/styles/color';
import { getSize } from '@/styles/size';

import {
  DrawerContentProps,
  DrawerSize,
  drawerSizes,
  isDrawerContentProp,
} from './DrawerContent';

export interface DrawerWrapperProps extends DrawerContentProps {
  open?: boolean;
  shadow?: boolean;
  delay?: number;
  border?: boolean;
  zIndex: number;
}

export const isDrawerWrapperProp = (p: string) =>
  isDrawerContentProp(p) ||
  ['zIndex', 'open', 'shadow', 'delay', 'border'].includes(p);

export const DrawerWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => !isDrawerWrapperProp(p),
})<DrawerWrapperProps>`
  flex-shrink: 0;
  flex-grow: 1;
  max-width: 100%;
  display: flex;
  flex-direction: column;
  ${({ shadow = true }) =>
    shadow &&
    css`
      box-shadow: 0px 0px 10px ${getColor('border')};
    `}

  margin: 0;
  padding: 0;
  background: ${getColor('bgPrimary')};
  overflow: hidden;

  position: fixed;
  inset-block: 0;
  z-index: ${({ zIndex }) => zIndex};

  ${({ left }) =>
    left
      ? css`
          left: 0;
        `
      : css`
          right: 0;
        `}

  ${({ open, left }) => {
    if (open) {
      return css`
        transform: none;
      `;
    }
    if (left) {
      return css`
        transform: translateX(-100%);
      `;
    }
    return css`
      transform: translateX(100%);
    `;
  }}

  ${({ delay = 400 }) => css`
    transition: transform ${delay}ms ease-in-out;
  `}

  ${({ left }) =>
    left
      ? css`
          border-right: 1px solid ${getColor('border')};
        `
      : css`
          border-left: 1px solid ${getColor('border')};
        `}
        
  ${({ inline, delay = 300, open, size }) =>
    inline !== undefined &&
    css`
      ${getBreakpoint(inline === true ? 'md' : inline)} {
        z-index: unset;
        box-shadow: none;
        position: relative;
        transform: none;
        width: 0;

        transition: width ${delay}ms ease-in-out;

        @media (prefers-reduced-motion) {
          transition-duration: 0ms;
        }

        ${open &&
        css`
          width: ${getSize(drawerSizes[size as DrawerSize] || size)};
        `}
      }
    `}

  ${({ open, size }) =>
    open &&
    css`
      width: ${getSize(drawerSizes[size as DrawerSize] || size)};
    `}
`;
