import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { MouseEventHandler, ReactEventHandler, useState } from 'react';

import { Button } from '@/buttons/Button';
import { BodyText } from '@/typography/BodyText';

import { Notification } from '../../info/Notification';
import { Confirm } from '../Confirm';

import { DrawerBody } from './DrawerBody';
import { DrawerDialog } from './DrawerDialog';
import { DrawerFooter } from './DrawerFooter';
import { DrawerHeader } from './DrawerHeader';
import { DrawerTitle } from './DrawerTitle';

export default {
  component: DrawerDialog,
  title: 'modals/Drawer.Dialog',
  parameters: {
    docs: {
      description: {
        component:
          '<p>The DrawerDialog component is a screen height dialog element that animates in from the side of the page</p>' +
          '<p>A dialog element is a "Top Level Component" when in modal mode which means it cannot be overriden by z-index</p>' +
          '<p>If you app uses toast notifications, you should probably use the Drawer component instead so then the toasts can be seen</p>' +
          '<p>By default the drawer will open from the right of the page but can open from the left when provided a left prop boolean value</p>',
      },
    },
  },
  args: {
    delay: 500,
    open: false,
    left: false,
    onOverlayClick: action('onOverlayClick'),
    onCloseValue: action('onCloseValue'),
    onClose: action('onClose'),
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the dialog',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    bgColor: {
      control: { type: 'text' },
      description: 'The background color of the drawer',
      table: {
        type: { summary: 'Color' },
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'If the dialog is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    left: {
      control: { type: 'boolean' },
      description: 'Open the dialog on the left instead of the right',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    delay: {
      control: { type: 'number' },
      description: 'The time in miliseconds for the transitions',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '500' },
      },
    },
    width: {
      control: { type: 'text' },
      description: 'The width of the dialog',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '30em' },
      },
    },
    onOverlayClick: {
      action: 'clicked',
      description:
        'The renamed native dialog onClick handler to handle clicking the overlay',
    },
    onCloseValue: {
      action: 'clicked',
      description:
        'a method to retrieve the value passed to the native dialog.close method',
    },
    onClose: {
      description:
        'a method to set the value of the open prop when the dialog is closed',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof DrawerDialog>;

type Story = StoryObj<typeof DrawerDialog>;

export const Demo: Story = {
  render: ({ open, ...props }) => {
    const [, updateArgs] = useArgs();

    const onClose: ReactEventHandler<HTMLDialogElement> = (e) => {
      updateArgs({ open: false });
      props.onClose?.(e);
    };
    const onClick: MouseEventHandler<HTMLDialogElement> = (e) => {
      updateArgs({ open: false });
      props.onOverlayClick?.(e);
    };

    return (
      <>
        <Button onClick={() => updateArgs({ open: !open })}>
          {open ? 'Close' : 'Open'}
        </Button>

        <DrawerDialog
          {...props}
          open={open}
          onClose={onClose}
          onOverlayClick={onClick}
        >
          <DrawerHeader>
            <DrawerTitle title="Modal Title" />
          </DrawerHeader>
          <DrawerBody>
            <BodyText as="p">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Pellentesque magna diam, semper eget lectus vel, lacinia varius
              est. Proin egestas metus eget ex dictum, et fringilla nunc
              dapibus. Donec vel ligula dapibus, convallis arcu ut, scelerisque
              leo. Ut risus ipsum, dictum eu mauris ac, feugiat aliquet nisi.
              Morbi sagittis libero eu diam placerat malesuada. Vestibulum ante
              ipsum primis in faucibus orci luctus et ultrices posuere cubilia
              curae; Nulla facilisi. Nam at tristique erat.
            </BodyText>
          </DrawerBody>
          <DrawerFooter secondary={<Button onClick={close}>Secondary</Button>}>
            <Button onClick={close}>Cancel</Button>
            <Button variant="primary" onClick={close} autoFocus>
              Confirm
            </Button>
          </DrawerFooter>
        </DrawerDialog>
      </>
    );
  },
};

export const NestedDialogs: Story = {
  render: ({ open, ...props }) => {
    const [, updateArgs] = useArgs();

    const onClose: ReactEventHandler<HTMLDialogElement> = (e) => {
      updateArgs({ open: false });
      props.onClose?.(e);
    };
    const onClick: MouseEventHandler<HTMLDialogElement> = (e) => {
      updateArgs({ open: false });
      props.onOverlayClick?.(e);
    };

    const [isDeleteOpen, setIsDeleteOpen] = useState(false);

    return (
      <>
        <Button onClick={() => updateArgs({ open: !open })}>
          {open ? 'Close' : 'Open'}
        </Button>

        <DrawerDialog
          {...props}
          open={open}
          onClose={onClose}
          onOverlayClick={onClick}
        >
          <DrawerHeader>
            <DrawerTitle title="Modal Title" />
          </DrawerHeader>
          <DrawerBody>
            <Notification open title="Success">
              Something was successful
            </Notification>
          </DrawerBody>
          <DrawerFooter
            secondary={
              <Button onClick={() => setIsDeleteOpen(true)}>Secondary</Button>
            }
          >
            <Button onClick={close}>Cancel</Button>
            <Button variant="primary" onClick={close} autoFocus>
              Confirm
            </Button>
          </DrawerFooter>
          <Confirm
            id="confirm"
            open={isDeleteOpen}
            title="Confirm Something"
            onConfirm={() => void 0}
            onClose={() => setIsDeleteOpen(false)}
          />
        </DrawerDialog>
      </>
    );
  },
};
