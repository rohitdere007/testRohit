import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';

import { Drawer } from './Drawer';
import { DrawerBody } from './DrawerBody';

export default {
  component: Drawer.Body,
  title: 'modals/Drawer.Body',
  args: {
    children:
      'Space, the final frontier. These are the voyages of the Starship' +
      'Enterprise. Its five-year mission: to explore strange new worlds, to' +
      'seek out new life and new civilizations, to boldly go where no man has' +
      'gone before. Many say exploration is part of our destiny, but it’s' +
      'actually our duty to future generations and their quest to ensure the' +
      'survival of the human species.',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Drawer.Body` provides padding uniform to the `Drawer.Header` & `Drawer.Footer` between. Most commonly it would be used within a `Drawer`.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof DrawerBody>;

type Story = StoryObj<typeof DrawerBody>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer open={open} onClose={close} onOverlayClick={close}>
          <Drawer.Header>
            <Drawer.Title title="Hello World" />
          </Drawer.Header>
          <Drawer.Body>{props.children}</Drawer.Body>
          <Drawer.Footer>
            <Button variant="primary">Confirm</Button>
            <Button>Cancel</Button>
          </Drawer.Footer>
        </Drawer>
      </>
    );
  },
};
