import { HTMLAttributes, PropsWithChildren } from 'react';
import { styled } from 'styled-components';

import { Header } from '@/atoms/Header';
import { getColor } from '@/styles/color';
import { getSize } from '@/styles/size';
import { getSpacing } from '@/styles/space';

import { DrawerClose } from './DrawerClose';

const DrawerHeaderWrapper = styled(Header)`
  background: ${getColor('bgPrimary')};
  min-height: ${getSize(12)};
  padding: ${getSpacing('3 3 0')};
  flex-wrap: nowrap;
`;

const CloseWrapper = styled.div`
  align-self: flex-start;
`;

export const DrawerHeader = ({
  children,
  ...rest
}: PropsWithChildren<HTMLAttributes<HTMLDivElement>>) => (
  <DrawerHeaderWrapper {...rest}>
    {children}
    <CloseWrapper>
      <DrawerClose />
    </CloseWrapper>
  </DrawerHeaderWrapper>
);

DrawerHeader.displayName = 'Drawer.Header';
