import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';

import { Drawer } from './Drawer';
import { DrawerFooter } from './DrawerFooter';

export default {
  component: DrawerFooter,
  title: 'modals/Drawer.Footer',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Drawer.Footer` provides uniform props with other `Footer` components. It requires a `children` value and takes optional `secondary` prop. The direction of the buttons passed will be vertical on a mobile with the primary actions above and then horizontal on desktop with primary actions on the right.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
      description: 'The main footer buttons',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    secondary: {
      control: undefined,
      description: 'The secondary footer buttons',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof DrawerFooter>;

type Story = StoryObj<typeof DrawerFooter>;

const children =
  'Space, the final frontier. These are the voyages of the Starship' +
  'Enterprise. Its five-year mission: to explore strange new worlds, to' +
  'seek out new life and new civilizations, to boldly go where no man has' +
  'gone before. Many say exploration is part of our destiny, but it’s' +
  'actually our duty to future generations and their quest to ensure the' +
  'survival of the human species.';

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer open={open} onClose={close} onOverlayClick={close}>
          <Drawer.Header {...props}>
            <Drawer.Title title="Hello World" />
          </Drawer.Header>
          <Drawer.Body>{children}</Drawer.Body>
          <DrawerFooter {...props}>
            <Button variant="primary">Confirm</Button>
            <Button>Cancel</Button>
          </DrawerFooter>
        </Drawer>
      </>
    );
  },
};

export const WithSecondary: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer open={open} onClose={close} onOverlayClick={close}>
          <Drawer.Header {...props}>
            <Drawer.Title title="Hello World" />
          </Drawer.Header>
          <Drawer.Body>{children}</Drawer.Body>
          <DrawerFooter
            {...props}
            secondary={<Button variant="critical">Delete</Button>}
          >
            <Button variant="primary">Confirm</Button>
            <Button>Cancel</Button>
          </DrawerFooter>
        </Drawer>
      </>
    );
  },
};
