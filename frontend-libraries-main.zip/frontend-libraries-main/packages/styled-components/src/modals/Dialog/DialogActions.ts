import styled from 'styled-components';

import { Toolbar } from '@/navigation/Toolbar';

export const DialogActions = styled(Toolbar).withConfig({
  displayName: 'DialogActions',
})`
  justify-content: flex-end;
`;
