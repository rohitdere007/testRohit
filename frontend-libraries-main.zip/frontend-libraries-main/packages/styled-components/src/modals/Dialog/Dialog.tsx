import {
  ComponentType,
  DialogHTMLAttributes,
  KeyboardEvent,
  useCallback,
  useLayoutEffect,
  useRef,
  useState,
} from 'react';
import styled, { css } from 'styled-components';

import { ModalCloseContext } from '@/modals/Modal/ModalCloseContext';
import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSpace } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';
import { AsProps } from '@/utils/typescript';

export type DialogProps = Omit<
  DialogHTMLAttributes<HTMLDialogElement>,
  'onClick'
> & {
  inline?: boolean;
  open?: boolean;
  delay?: number;
};

export const isDialogProp = (p: string) =>
  ['inline', 'open', 'delay'].includes(p);

export const DialogElement = styled.dialog.withConfig({
  displayName: 'DialogElement',
  shouldForwardProp: (p) => !isDialogProp(p),
})<DialogProps & { delay: number }>`
  margin: 0;
  padding: ${getSpace(3)};
  border: 1px solid ${getColor('border')};
  background: ${getColor('bgPrimary')};
  border-radius: ${getRadius(2)};

  outline: none;
  ${getBodyTextStyles({ color: 'fg' })};

  ${({ inline, open, delay }) =>
    !inline
      ? css`
          margin: auto;
          position: fixed;
          transform: translateY(${open ? '-50%' : '-100%'});
          opacity: ${open ? 1 : 0};
          transition:
            transform ${delay}ms ease-in-out,
            opacity ${delay}ms ease-in-out;

          @media (prefers-reduced-motion) {
            transition: opacity ${delay}ms ease-in-out;
          }
          &::backdrop {
            background: ${getColor('bgPrimary')};
            opacity: ${open ? 0.4 : 0};
            transition: opacity ${delay}ms ease-in-out;
            overflow: hidden;
          }
        `
      : css`
          clip: rect(auto, auto, 0, auto);
          width: auto;
          height: auto;
          overflow: hidden;
          position: relative;
          max-height: ${open ? '500px' : 0};
          opacity: ${open ? 1 : 0};

          transition:
            max-height ${delay}ms ease-in-out,
            opacity ${delay}ms ease-in-out;
        `}
`;

const DialogContent = styled.div.attrs({
  onClick: (e) => {
    e.stopPropagation();
  },
})`
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
`;

export interface DialogBaseProps extends DialogProps {
  onCloseValue?: (value: unknown) => void;
  onOverlayClick?: (e: React.MouseEvent<HTMLDialogElement>) => void;
}

export type BaseDialogProps<C extends React.ElementType = React.ElementType> =
  DialogBaseProps & AsProps<C>;

export const Dialog = <C extends React.ElementType>({
  open: openProp = false,
  as,
  onClose,
  onCloseValue,
  onOverlayClick,
  inline,
  delay = 500,
  children,
  ...props
}: BaseDialogProps<C>) => {
  const internalRef = useRef<HTMLDialogElement | null>(null);
  const dialog = internalRef.current;
  // so then any dialog can be closed without a setOpen prop being supplied
  const [openState, setOpenState] = useState<boolean>();
  // so then the open/close animation can complete
  const [openDelayed, setOpenDelayed] = useState<boolean>();
  const closeTimeout = useRef<number | NodeJS.Timeout>(0);
  const [closeValue, setCloseValue] = useState<string>();

  const close = useCallback(
    (value?: string) => {
      setOpenState(false);
      setOpenDelayed(false);
      setCloseValue(value);
      closeTimeout.current = setTimeout(() => {
        if (dialog?.open) {
          dialog.close(closeValue);
        }
      }, delay);
    },
    [dialog, delay, closeValue],
  );

  useLayoutEffect(() => {
    // as on first render the ref won't be defined, the first cycle won't open the dialog,
    // if the open prop is true the following state change triggers a rereneder on mount
    setOpenState(openProp);
    if (openProp && closeValue) {
      setCloseValue(undefined);
    }
  }, [openProp, closeValue]);

  useLayoutEffect(() => {
    if (dialog) {
      if (openState && !dialog.open) {
        // It is recommended to use the .show() or .showModal() methods to render dialogs, rather than the open attribute
        // passing open=true to a html dialog element makes it "non-modal"
        // https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog
        if (!inline) {
          dialog.showModal();
        } else {
          dialog.show();
        }
        setOpenDelayed(true);
      } else if (!openState && dialog.open) {
        close(closeValue);
      }
    }
    return () => {
      clearTimeout(closeTimeout.current);
    };
  }, [openState, closeValue, delay, inline, dialog, close]);

  const Element = (as || DialogElement) as ComponentType<DialogProps>;
  return (
    <ModalCloseContext.Provider value={close}>
      <Element
        {...props}
        inline={inline}
        delay={delay}
        ref={internalRef}
        open={Boolean(openDelayed)}
        onKeyDown={(e: KeyboardEvent<HTMLDialogElement>) => {
          if (['Escape'].includes(e.code)) {
            e.preventDefault();
          }
          switch (e.code) {
            case 'Escape':
              close();
              break;
            default:
              break;
          }
          props.onKeyDown?.(e);
        }}
        onClose={(e) => {
          e.stopPropagation();
          onClose?.(e);
          onCloseValue?.(closeValue);
        }}
        onClick={onOverlayClick}
      >
        <DialogContent>{children}</DialogContent>
      </Element>
    </ModalCloseContext.Provider>
  );
};

Dialog.displayName = 'Dialog';
