import { fireEvent, render, screen } from '@testing-library/react';

import { withTheme } from '@/utils/jest';

import { Dialog } from './Dialog';

describe('Dialog', () => {
  it('does not display content in the document on load', () => {
    render(<Dialog open={false}>content</Dialog>, {
      wrapper: withTheme,
    });

    const el = screen.getByRole<HTMLDialogElement>('dialog', { hidden: true });
    expect(el.open).toBeDefined();
    expect(el.open).toBe(false);

    const content = screen.getByText('content');
    expect(content).toBeInTheDocument();
    expect(content).not.toBeVisible();
  });

  it('does display by default if "open" is true', () => {
    render(
      <Dialog open inline={true}>
        content
      </Dialog>,
      { wrapper: withTheme },
    );

    const el = screen.getByRole<HTMLDialogElement>('dialog');
    expect(el.open).toBe(true);
    expect(el.ariaModal).toBe(false);
    expect(el.show).toHaveBeenCalled();
    expect(el.showModal).not.toHaveBeenCalled();

    const content = screen.getByText('content');
    expect(content).toBeVisible();
  });

  it('does open the dialog if the "open" prop changes to true', () => {
    const { rerender } = render(
      <Dialog open={false} inline>
        content
      </Dialog>,

      { wrapper: withTheme },
    );
    rerender(
      <Dialog open inline>
        content
      </Dialog>,
    );

    const el = screen.getByRole<HTMLDialogElement>('dialog');
    expect(el.show).toHaveBeenCalled();
    expect(el.showModal).not.toHaveBeenCalled();
  });

  it("doesn't close the dialog by default when clicked", async () => {
    let clicked = false;

    render(
      <Dialog
        onOverlayClick={() => {
          clicked = true;
        }}
        open
      />,
      { wrapper: withTheme },
    );

    const el = screen.getByRole<HTMLDialogElement>('dialog');
    fireEvent.click(el);
    expect(clicked).toBe(true);
    expect(el.open).toBe(true);
  });

  it('opens the dialog as a modal when inline is false"', async () => {
    render(
      <Dialog open>
        <span>content</span>
      </Dialog>,
      { wrapper: withTheme },
    );

    const el = screen.getByRole<HTMLDialogElement>('dialog');
    expect(el.showModal).toHaveBeenCalledTimes(1);
    expect(el.open).toBe(true);
    expect(el.ariaModal).toBe(true);
  });
});
