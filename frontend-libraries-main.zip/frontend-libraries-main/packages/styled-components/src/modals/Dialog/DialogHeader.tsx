import styled from 'styled-components';

import { getSize } from '@/styles/size';
import { getSpace } from '@/styles/space';

import { ModalClose } from '../Modal/ModalClose';

export type DialogHeaderProps = React.PropsWithChildren<{
  hideCloseButton?: React.ReactNode;
}>;

const DialogHeaderElement = styled.header`
  display: flex;
  min-height: ${getSize(4)};
  gap: ${getSpace(3)};
  align-items: center;
  justify-content: space-between;
`;

export const DialogHeader: React.FC<DialogHeaderProps> = ({
  children,
  hideCloseButton,
}) => (
  <DialogHeaderElement>
    {children}
    {!hideCloseButton && <ModalClose />}
  </DialogHeaderElement>
);
