import {
  SectionTitle,
  SectionTitleProps,
} from '@/layouts/Section/SectionTitle';

export type ModalTitleProps = SectionTitleProps;

export const ModalTitle = (props: ModalTitleProps) => (
  <SectionTitle {...props} />
);

ModalTitle.displayName = 'Modal.Title';
