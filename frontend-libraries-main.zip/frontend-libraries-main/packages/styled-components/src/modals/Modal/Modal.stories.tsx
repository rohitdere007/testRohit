import { mdiAlertCircleCheckOutline } from '@mdi/js';
import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { MouseEvent, useEffect, useState } from 'react';

import { Icon } from '@/atoms/Icon';
import { Button } from '@/buttons/Button';

import { Modal, ModalProps, modalSizes } from '.';

const useDialogStory = (props: ModalProps) => {
  const [, updateArgs] = useArgs();
  const state = useState(!!props.open);
  const [open, setOpen] = state;

  useEffect(() => {
    setOpen(!!props.open);
  }, [props.open]);

  useEffect(() => {
    updateArgs({ open });
  }, [open]);

  const onOverlayClick = (e: MouseEvent<HTMLDialogElement>) => {
    props.onOverlayClick?.(e);
    setOpen(!open);
  };
  return { open, setOpen, onOverlayClick };
};

export default {
  component: Modal,
  args: {
    open: false,
    onOverlayClick: action('onOverlayClick'),
    onCloseValue: action('onCloseValue'),
    onClose: action('onClose'),
    children:
      'Per the HTML Living Standard, “The dialog element represents a part of an application that ' +
      ' a user interacts with to perform a task, for example a dialog box, inspector, or window.”',
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the dialog',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'If the dialog is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    delay: {
      control: { type: 'number' },
      description: 'The time in miliseconds for the transitions',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '500' },
      },
    },
    size: {
      options: Object.keys(modalSizes),
      description: 'The width of the modal for larger breakpoints',
      table: {
        type: {
          summary: [...Object.keys(modalSizes), 'number'].join(' | '),
        },
        defaultValue: { summary: '"sm"' },
      },
      control: {
        type: 'text',
      },
    },
    fullHeight: {
      control: { type: 'boolean' },
      description: 'If the mobile version of the modal should be full height',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onOverlayClick: {
      action: 'clicked',
      description:
        'a method that will trigger when the dialog overlay has been clicked',
    },
    onCloseValue: {
      action: 'clicked',
      description:
        'a method to retrieve the value passed to the native dialog.close method',
    },
    onClose: {
      description:
        'a method that will trigger when the dialog is closed. This is commonly used to set the value of the open prop to false when managing the modal state externally',
    },
  },
} satisfies Meta<typeof Modal>;

type Story = StoryObj<typeof Modal>;

export const Demo: Story = {
  render: ({ children, ...props }) => {
    const { open, setOpen, onOverlayClick } = useDialogStory(props);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Modal</Button>
        <Modal
          {...props}
          open={open}
          onClose={() => setOpen(false)}
          onOverlayClick={onOverlayClick}
        >
          <Modal.Header>
            <Modal.Title title="Modal Title" subtitle="Modal Subtitle" />
          </Modal.Header>
          <Modal.Body>{children}</Modal.Body>
          <Modal.Footer secondary={<Button onClick={close}>Secondary</Button>}>
            <Button variant="primary" onClick={close} autoFocus>
              Confirm
            </Button>
            <Button onClick={close}>Cancel</Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  },
};

export const ModalIcon: Story = {
  render: ({ children, ...props }) => {
    const { open, setOpen, onOverlayClick } = useDialogStory(props);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>{open ? 'Close' : 'Open'}</Button>
        <Modal
          {...props}
          open={open}
          onClose={() => setOpen(false)}
          onOverlayClick={onOverlayClick}
        >
          <Modal.Header>
            <Modal.Title
              title="Modal Title"
              subtitle="Modal Subtitle"
              icon={
                <Icon
                  icon={mdiAlertCircleCheckOutline}
                  size="lg"
                  color="fgSuccess"
                />
              }
            />
          </Modal.Header>
          <Modal.Body>{children}</Modal.Body>
          <Modal.Footer secondary={<Button onClick={close}>Secondary</Button>}>
            <Button variant="primary" onClick={close} autoFocus>
              Confirm
            </Button>
            <Button onClick={close}>Cancel</Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  },
};
