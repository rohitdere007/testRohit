import styled, { css } from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';
import { MaxHeightProps, isMaxHeightProp, maxHeight } from '@/styles/height';
import { getSpacing } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';

export interface ModalBodyProps extends MaxHeightProps {
  scrollable?: boolean;
}

export const ModalBody = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'scrollable' && !isMaxHeightProp(p),
})<ModalBodyProps>`
  padding: ${getSpacing('2 3')};
  ${getBodyTextStyles()};
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  ${getBreakpoint('sm')} {
    ${maxHeight}
  }

  ${({ scrollable }) =>
    scrollable &&
    css`
      overflow: auto;
    `}
`;

ModalBody.displayName = 'Modal.Body';
