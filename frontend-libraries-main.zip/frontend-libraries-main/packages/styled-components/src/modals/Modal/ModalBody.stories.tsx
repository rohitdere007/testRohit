import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';

import { Modal } from './Modal';
import { ModalBody } from './ModalBody';

export default {
  component: Modal.Body,
  title: 'modals/Modal.Body',
  args: {
    children:
      'Space, the final frontier. These are the voyages of the Starship' +
      'Enterprise. Its five-year mission: to explore strange new worlds, to' +
      'seek out new life and new civilizations, to boldly go where no man has' +
      'gone before. Many say exploration is part of our destiny, but it’s' +
      'actually our duty to future generations and their quest to ensure the' +
      'survival of the human species.',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Modal.Body` provides padding uniform to the `Modal.Header` & `Modal.Footer` between. Most commonly it would be used within a `Modal`.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ModalBody>;

type Story = StoryObj<typeof ModalBody>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Modal</Button>
        <Modal open={open} onClose={close} onOverlayClick={close}>
          <Modal.Header>
            <Modal.Title title="Hello World" />
          </Modal.Header>
          <Modal.Body>{props.children}</Modal.Body>
          <Modal.Footer>
            <Button variant="primary">Confirm</Button>
            <Button>Cancel</Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  },
};
