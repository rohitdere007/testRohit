import styled, { css } from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';
import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { Size, getSize } from '@/styles/size';
import { getBodyTextStyles } from '@/styles/typography';

import { Dialog, DialogBaseProps } from '../Dialog';

import { ModalBody } from './ModalBody';
import { ModalClose } from './ModalClose';
import { ModalFooter } from './ModalFooter';
import { ModalHeader } from './ModalHeader';
import { ModalTitle } from './ModalTitle';

export const modalSizes = {
  sm: 120,
  md: 160,
  lg: 240,
};

type ModalSize = keyof typeof modalSizes;

type ModalElementProps = DialogBaseProps & {
  size?: ModalSize | Size;
  fullHeight?: boolean;
};

export const isModalPropName = (propName: string) =>
  ['inline', 'size', 'fullHeight', 'delay', 'open'].includes(propName);

const ModalElement = styled.dialog.withConfig({
  shouldForwardProp: (propName) => !isModalPropName(propName),
})<ModalElementProps>`
  background: ${getColor('bgPrimary')};
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
  ${getBodyTextStyles({ color: 'fg' })};
  outline: none;
  border: none;
  box-shadow: 0px 4px 16px ${getColor('borderStrong')}3a;
  overflow: visible;
  margin: auto;
  position: fixed;
  inset: unset;
  bottom: 0;
  padding: 0;

  ${({ fullHeight }) =>
    fullHeight
      ? css`
          height: 100%;
          max-height: 100%;
        `
      : css`
          border-top-left-radius: ${getRadius(2)};
          border-top-right-radius: ${getRadius(2)};
        `}

  ${({ open, delay = 300, size = 'sm' }) => css`
    transform: translateY(${open ? '0%' : '100%'});
    opacity: ${open ? 1 : 0};
    transition:
      transform ${delay}ms ease-in-out,
      opacity ${delay}ms ease-in-out;

    @media (prefers-reduced-motion) {
      transition: opacity ${delay}ms ease-in-out;
    }

    &::backdrop {
      background: ${getColor('bgPrimary')};
      opacity: ${open ? 0.4 : 0};
      transition: opacity ${delay}ms ease-in-out;
      overflow: hidden;
    }

    ${getBreakpoint('sm')} {
      height: auto;
      bottom: 60%;
      left: 50%;
      border-radius: ${getRadius(2)};
      transform: translate(-50%, ${open ? '50%' : '40%'});
      width: ${getSize(modalSizes[size as ModalSize] || size)};
      max-width: calc(100% - ${getSize(4)});
    }
  `}
`;

export type ModalProps = ModalElementProps;

export const Modal = ({ children, ...props }: ModalProps) => (
  <Dialog {...props} as={ModalElement} inline={false}>
    {children}
  </Dialog>
);

Modal.displayName = 'Modal';

Modal.Title = ModalTitle;
Modal.Close = ModalClose;
Modal.Header = ModalHeader;
Modal.Body = ModalBody;
Modal.Footer = ModalFooter;
