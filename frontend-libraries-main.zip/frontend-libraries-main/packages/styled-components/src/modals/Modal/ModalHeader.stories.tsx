import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';
import { Modal } from '@/modals/Modal';

import { ModalHeader } from './ModalHeader';

export default {
  component: ModalHeader,
  title: 'modals/Modal.Header',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Modal.Header` component is a header element expecting a single child. The `Modal.Header` provides the `Modal.Close` instance. Most commonly it would be used within a `Modal` and have a `Modal.Title` instance as a child.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ModalHeader>;

type Story = StoryObj<typeof ModalHeader>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Modal</Button>
        <Modal open={open} onClose={close} onOverlayClick={close}>
          <Modal.Header {...props}>
            <Modal.Title title="Hello World" />
          </Modal.Header>
          <Modal.Body></Modal.Body>
        </Modal>
      </>
    );
  },
};
