import { ActionsFooter, ActionsFooterProps } from '@/layouts/ActionsFooter';

export const ModalFooter = (props: ActionsFooterProps) => (
  <ActionsFooter {...props} />
);

ModalFooter.displayName = 'Modal.Footer';
