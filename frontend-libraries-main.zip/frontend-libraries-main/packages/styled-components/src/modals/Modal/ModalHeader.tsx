import { HTMLAttributes, PropsWithChildren } from 'react';
import styled from 'styled-components';

import { Header } from '@/atoms/Header';
import { getSpacing } from '@/styles/space';

import { ModalClose } from './ModalClose';

const ModalHeaderWrapper = styled(Header)`
  padding: ${getSpacing('3 3 0')};
  align-items: flex-start;
`;

export const ModalHeader = ({
  children,
  ...rest
}: PropsWithChildren<HTMLAttributes<HTMLDivElement>>) => (
  <ModalHeaderWrapper {...rest}>
    {children}
    <ModalClose />
  </ModalHeaderWrapper>
);

ModalHeader.displayName = 'Modal.Header';
