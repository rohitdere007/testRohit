import { mdiClose } from '@mdi/js';

import { useModalCloseContext } from '@/modals/Modal/ModalCloseContext';

import { PlainIconButton } from '../../buttons/PlainIconButton';

export type ModalCloseProps = React.ButtonHTMLAttributes<HTMLButtonElement>;

export const ModalClose: React.FC<ModalCloseProps> = ({
  children,
  onClick,
  ...props
}) => {
  const close = useModalCloseContext();

  return (
    <>
      <PlainIconButton
        aria-label="Close"
        type="button"
        onClick={(e) => {
          close?.();
          onClick?.(e);
        }}
        icon={mdiClose}
        size="lg"
        {...props}
      />
    </>
  );
};

ModalClose.displayName = 'Modal.Close';
