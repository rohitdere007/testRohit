import { createContext, useContext } from 'react';

export const ModalCloseContext = createContext<(value?: string) => void>(
  () => void 0,
);

export const useModalCloseContext = () => useContext(ModalCloseContext);
