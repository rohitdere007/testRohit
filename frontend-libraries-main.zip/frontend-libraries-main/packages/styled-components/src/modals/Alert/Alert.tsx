import { Button } from '@/buttons/Button';
import { useModalCloseContext } from '@/modals/Modal/ModalCloseContext';

import { Modal, ModalProps, ModalTitleProps } from '../Modal';

const AlertFooter = () => {
  const close = useModalCloseContext();
  return (
    <Modal.Footer>
      <Button type="button" variant="primary" onClick={() => close?.()}>
        OK
      </Button>
    </Modal.Footer>
  );
};

export type AlertProps = Omit<ModalProps, 'size' | 'fullHeight'> &
  ModalTitleProps;

export const Alert = ({ children, ...props }: AlertProps) => (
  <Modal {...props} size="sm">
    <Modal.Header>
      <Modal.Title {...props} />
    </Modal.Header>
    <Modal.Body>{children}</Modal.Body>
    <AlertFooter />
  </Modal>
);
