import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Alert } from './Alert';

export default {
  component: Alert,
  parameters: {
    docs: {
      description: {
        component:
          '<p>Alert allows you to mimic the functionality of `window.alert` using our design of modal</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    open: false,
    onClose: action('onClose'),
    title: 'Modal Title',
    subtitle: 'Modal Subtitle',
    children: 'Are you sure you want to perform this action?',
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the dialog',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'If the dialog is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onClose: {
      description:
        'a callback method that triggers when the Alert dialog is closed',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Alert>;

type Story = StoryObj<typeof Alert>;

export const AlertStory: Story = {
  name: 'Alert',
  render: ({ children, ...props }) => {
    const [, updateArgs] = useArgs();
    const setOpen = (open: boolean) => updateArgs({ open });

    return (
      <>
        <Button onClick={() => setOpen(true)}>
          {props.open ? 'Close' : 'Open'}
        </Button>
        <Alert
          {...props}
          onClose={(e) => {
            setOpen(false);
            props.onClose?.(e);
          }}
        >
          {children}
        </Alert>
      </>
    );
  },
};
