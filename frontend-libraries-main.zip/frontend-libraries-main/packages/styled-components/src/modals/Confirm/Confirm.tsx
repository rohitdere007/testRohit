import { useState } from 'react';

import { Button } from '@/buttons/Button';
import { LoadingButton } from '@/buttons/LoadingButton';
import { useModalCloseContext } from '@/modals/Modal/ModalCloseContext';

import { AlertProps } from '../Alert';
import { Modal, ModalTitleProps } from '../Modal';

interface ConfirmFooterProps {
  onConfirm: () => Promise<void> | void;
}

const ConfirmFooter = ({ onConfirm }: ConfirmFooterProps) => {
  const close = useModalCloseContext();
  const [isLoading, setIsLoading] = useState(false);
  return (
    <Modal.Footer>
      <LoadingButton
        type="button"
        variant="primary"
        onClick={async () => {
          setIsLoading(true);
          try {
            await onConfirm();
            setIsLoading(false);
            close?.('confirmed');
            // eslint-disable-next-line unused-imports/no-unused-vars
          } catch (e) {
            setIsLoading(false);
          }
        }}
        loading={isLoading}
        autoFocus
      >
        Confirm
      </LoadingButton>
      <Button type="button" onClick={() => close?.()}>
        Cancel
      </Button>
    </Modal.Footer>
  );
};

export type ConfirmProps = AlertProps & ModalTitleProps & ConfirmFooterProps;

export const Confirm = ({ onConfirm, children, ...props }: ConfirmProps) => (
  <Modal {...props} size="sm">
    <Modal.Header>
      <Modal.Title {...props} />
    </Modal.Header>
    <Modal.Body>{children}</Modal.Body>
    <ConfirmFooter onConfirm={onConfirm} />
  </Modal>
);
