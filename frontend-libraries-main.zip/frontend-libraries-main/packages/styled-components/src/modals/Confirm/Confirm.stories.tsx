import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Confirm } from './Confirm';

export default {
  component: Confirm,
  parameters: {
    docs: {
      description: {
        component:
          '<p>Confirm allows you to mimic the functionality of `window.confirm` using our design of modal</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    open: false,
    onConfirm: action('onConfirm'),
    onClose: action('onClose'),
    title: 'Modal Title',
    subtitle: 'Modal Subtitle',
    children: 'Are you sure you want to perform this action?',
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the dialog',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'If the dialog is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onConfirm: {
      action: 'clicked',
      description:
        'a callback method that triggers when the confirm button is clicked',
    },
    onClose: {
      description:
        'a callback method that triggers when the confirm dialog is closed',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Confirm>;

type Story = StoryObj<typeof Confirm>;

export const ConfirmStory: Story = {
  name: 'Confirm',
  render: ({ children, ...props }) => {
    const [, updateArgs] = useArgs();
    const setOpen = (open: boolean) => updateArgs({ open });

    return (
      <>
        <Button onClick={() => setOpen(true)}>
          {props.open ? 'Close' : 'Open'}
        </Button>
        <Confirm
          {...props}
          onClose={(e) => {
            setOpen(false);
            props.onClose?.(e);
          }}
        >
          {children}
        </Confirm>
      </>
    );
  },
};

export const ConfirmAwaitPromise: Story = {
  render: ({ children, ...props }) => {
    const [, updateArgs] = useArgs();
    const setOpen = (open: boolean) => updateArgs({ open });
    const promise = () =>
      new Promise<void>((resolve) => {
        setTimeout(() => resolve(void 0), 4000);
      });
    return (
      <>
        <Button onClick={() => setOpen(true)}>
          {props.open ? 'Close' : 'Open'}
        </Button>
        <Confirm
          {...props}
          onClose={(e) => {
            setOpen(false);
            props.onClose?.(e);
          }}
          onConfirm={promise}
        >
          {children}
        </Confirm>
      </>
    );
  },
};
