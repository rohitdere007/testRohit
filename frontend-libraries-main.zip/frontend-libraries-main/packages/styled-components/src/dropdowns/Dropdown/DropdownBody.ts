import styled from 'styled-components';

import { getSpace } from '@/styles/space';

export const DropdownBody = styled.div`
  padding: ${getSpace(2)};
  box-sizing: border-box;
  width: 100%;
`;

DropdownBody.displayName = 'Dropdown.Body';
