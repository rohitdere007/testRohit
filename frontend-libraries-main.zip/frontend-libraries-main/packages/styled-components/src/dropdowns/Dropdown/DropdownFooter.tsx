import styled from 'styled-components';

import { Footer } from '@/atoms/Footer';
import {
  ActionsFooter,
  type ActionsFooterProps,
} from '@/layouts/ActionsFooter';
import { getSpace } from '@/styles/space';

const FooterWrapper = styled.div`
  ${Footer} {
    padding: ${getSpace(2)};
  }
`;

export const DropdownFooter = (props: ActionsFooterProps) => (
  <FooterWrapper>
    <ActionsFooter {...props} />
  </FooterWrapper>
);

DropdownFooter.displayName = 'Dropdown.Footer';
