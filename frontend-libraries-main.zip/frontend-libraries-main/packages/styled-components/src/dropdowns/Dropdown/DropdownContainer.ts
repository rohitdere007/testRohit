import styled, { css } from 'styled-components';

import { getSpace } from '@/styles/space';

export type DropdownPosition = 'left' | 'right' | 'top' | 'bottom';

type ContainerProps = {
  position?: DropdownPosition;
};

export const DropdownContainer = styled.div.withConfig({
  shouldForwardProp: (p) => !['position', 'size'].includes(p),
})<ContainerProps>`
  ${({ position = 'bottom' }) => {
    switch (position) {
      case 'top':
        return css`
          padding-bottom: ${getSpace()};
        `;
      case 'bottom':
        return css`
          padding-top: ${getSpace()};
        `;
      case 'left':
        return css`
          padding-right: ${getSpace()};
        `;
      case 'right':
        return css`
          padding-left: ${getSpace()};
        `;
      default:
        return;
    }
  }}
`;
