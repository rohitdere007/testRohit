import { mdiChevronRight } from '@mdi/js';
import { ButtonHTMLAttributes, ReactNode } from 'react';
import styled from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { TextEllipsis } from '@/atoms/TextEllipsis';
import { Button, ButtonCustomProps } from '@/buttons/Button';
import { getFontWeight } from '@/styles/fontWeight';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';
import { getSpace, getSpacing } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';
import { AsProps } from '@/utils/typescript';

export type DropdownItemProps<C extends React.ElementType> =
  ButtonHTMLAttributes<HTMLButtonElement> &
    ButtonCustomProps & {
      icon?: ReactNode;
      chevron?: boolean;
    } & AsProps<C>;

const ActionButton = styled(Button)`
  font-weight: ${getFontWeight('regular')};
  display: flex;
  justify-content: flex-start;
  align-items: center;
  gap: ${getSpace(2)};
  width: 100%;
  box-sizing: border-box;
  min-height: ${getSize(8)};
  padding: ${getSpacing('1 2')};
  border-radius: ${getRadius(1.5)};

  &:focus-visible {
    outline: 0;
  }
`;

const ActionText = styled(TextEllipsis)`
  flex-grow: 1;
  ${getUITextStyles()};
`;

export const DropdownItem = <C extends React.ElementType>({
  children,
  icon,
  chevron,
  ...props
}: DropdownItemProps<C>) => (
  <ActionButton {...props} ghost>
    {icon && <Icon icon={icon} />}
    <ActionText>{children}</ActionText>
    {chevron && <Icon icon={mdiChevronRight} />}
  </ActionButton>
);
