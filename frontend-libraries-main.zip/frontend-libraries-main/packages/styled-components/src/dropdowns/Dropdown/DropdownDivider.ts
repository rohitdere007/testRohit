import styled from 'styled-components';

import { Divider } from '@/atoms/Divider';
import { getSpace } from '@/styles/space';

export const DropdownDivider = styled(Divider)`
  margin: ${getSpace('0.5')} 0;
`;

DropdownDivider.displayName = 'Dropdown.Divider';
