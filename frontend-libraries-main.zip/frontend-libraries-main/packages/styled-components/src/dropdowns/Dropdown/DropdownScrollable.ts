import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';

import { DropdownBody } from './DropdownBody';

export const dropdownScrollStyles = css`
  overflow-y: auto;

  --scrollbar-foreground: ${getColor('border')};
  --scrollbar-background: transparent;

  scrollbar-color: var(--scrollbar-foreground) var(--scrollbar-background);

  &::-webkit-scrollbar-thumb {
    background: var(--scrollbar-foreground);
  }

  &::-webkit-scrollbar-track {
    background: var(--scrollbar-background);
  }
`;

export const DropdownScrollable = styled(DropdownBody)`
  ${dropdownScrollStyles};
`;

DropdownScrollable.displayName = 'Dropdown.Scrollable';
