import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { Size, getSize } from '@/styles/size';

export const dropdownSizes = {
  sm: 40,
  md: 48,
  lg: 60,
  xl: 64,
};

export type DropdownSize = keyof typeof dropdownSizes;

export type DropdownWrapperProps = {
  size?: DropdownSize | Size;
  zIndex?: number;
};

export const DropdownWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => !['zIndex', 'size'].includes(p),
})<DropdownWrapperProps>`
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  border-radius: ${getRadius(3)};
  border: 1px solid ${getColor('border')};
  background: ${getColor('bgPrimary')};
  box-shadow: 0px 4px 16px 0px ${getColor('borderStrong')}3a;
  overflow: hidden;
  min-width: ${getSize(40)};

  &:focus-visible {
    outline: none;
  }

  ${({ size = 'md' }) => css`
    width: ${getSize(dropdownSizes[size as DropdownSize] || size)};
  `}

  ${({ zIndex }) =>
    zIndex &&
    css`
      z-index: ${zIndex};
    `}
`;
