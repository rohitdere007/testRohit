import styled from 'styled-components';

export const Relative = styled.div`
  position: relative;
`;

Relative.displayName = 'Relative';
