import styled from 'styled-components';

export const Spacer = styled.div.withConfig({ displayName: 'Spacer' })`
  flex: 1;
`;
