import styled from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';

import { BreakpointProps, breakpointConfig } from './config';

export const ShowAt = styled.div.withConfig(breakpointConfig)<BreakpointProps>`
  display: none;
  ${({ breakpoint = 'sm', theme }) => getBreakpoint(breakpoint)({ theme })} {
    display: block;
  }
`;

ShowAt.displayName = 'ShowAt';
