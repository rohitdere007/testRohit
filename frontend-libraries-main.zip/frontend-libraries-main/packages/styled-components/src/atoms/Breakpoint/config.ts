import { BreakPoint } from '@/styles/breakpoint';

export interface BreakpointProps {
  breakpoint: BreakPoint;
}

export const breakpointConfig = {
  shouldForwardProp: (p: string) => !['breakpoint'].includes(p),
};
