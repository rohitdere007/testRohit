import styled from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';

import { BreakpointProps, breakpointConfig } from './config';

export const HideAt = styled.div.withConfig(breakpointConfig)<BreakpointProps>`
  display: block;
  ${({ breakpoint = 'sm', theme }) => getBreakpoint(breakpoint)({ theme })} {
    display: none;
  }
`;

HideAt.displayName = 'HideAt';
