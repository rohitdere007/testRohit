import { Property } from 'csstype';
import styled, { css } from 'styled-components';

import { BreakPoint, getBreakpoint } from '@/styles/breakpoint';

export interface GridCellProps {
  children?: React.ReactNode;
  span?: number | number[];
  alignSelf?: Property.AlignSelf;
}

export const breakpoints = ['', 'sm', 'md', 'lg', 'xl'];

export const GridCell = styled.div.withConfig({
  shouldForwardProp: (p) => !['span', 'alignSelf'].includes(p),
  displayName: 'Grid.Cell',
})<GridCellProps>`
  ${({ span = 1 }) => {
    const spans = typeof span !== 'number' ? span : [span];
    return css`
      ${spans.map((s, i) => {
        const columns = css`
          grid-column: auto / span ${s};
        `;
        if (i === 0) {
          return columns;
        }
        if (!breakpoints[i]) {
          return;
        }
        return css`
          ${getBreakpoint(breakpoints[i] as BreakPoint)} {
            ${columns}
          }
        `;
      })}
    `;
  }}
  ${({ alignSelf }) =>
    alignSelf &&
    css`
      align-self: ${alignSelf};
    `};
`;
