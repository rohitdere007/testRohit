import { Property } from 'csstype';
import React, { HTMLAttributes } from 'react';
import styled from 'styled-components';

import { Space, getSpace } from '@/styles/space';
import { AsProps } from '@/utils/typescript';

import { GridCell } from './GridCell';

export interface GridProps {
  rowGap?: Space;
  columnGap?: Space;
  children?: React.ReactNode;
  columns?: number;
  align?: Property.AlignItems;
}

const GridWrapper = styled.div.withConfig({
  shouldForwardProp: (p) =>
    !['rowGap', 'columnGap', 'columns', 'start'].includes(p),
})<GridProps>`
  display: grid;
  box-sizing: border-box;
  grid-template-columns: repeat(${({ columns = 12 }) => columns}, 1fr);
  column-gap: ${({ theme, columnGap = 3 }) => getSpace(columnGap)({ theme })};
  row-gap: ${({ theme, rowGap = 3 }) => getSpace(rowGap)({ theme })};
  align-items: ${({ align = 'flex-start' }) => align};
`;

export const Grid = <C extends React.ElementType>(
  props: HTMLAttributes<HTMLElement> & GridProps & AsProps<C>,
) => <GridWrapper {...props} />;

Grid.displayName = 'Grid';
Grid.Cell = GridCell;
