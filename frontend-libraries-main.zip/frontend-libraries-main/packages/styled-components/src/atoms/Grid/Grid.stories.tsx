import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Grid } from './Grid';
import { GridCell } from './GridCell';

const position = ['center', 'end', 'flex-end', 'flex-start', 'start'];
const alignOptions = ['stretch', 'baseline', 'normal', ...position];

export default {
  component: Grid,
  title: 'atoms/Grid',
  parameters: {
    docs: {
      description: {
        component:
          'The Grid component is a styled component that offers props for css grid values.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
      description: 'The contents of the Grid',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    rowGap: {
      control: { type: 'number' },
      description: 'the row gap value of the Grid',
      table: {
        type: { summary: 'Space' },
        defaultValue: { summary: '2' },
      },
    },
    columnGap: {
      control: { type: 'number' },
      description: 'the column gap value of the Grid',
      table: {
        type: { summary: 'Space' },
        defaultValue: { summary: '2' },
      },
    },
    columns: {
      control: { type: 'number' },
      description: 'the number of columns in the Grid',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '12' },
      },
    },
    align: {
      options: alignOptions,
      description: 'the `align-items` value of the grid',
      table: {
        type: {
          summary: 'Property.AlignItems',
        },
        defaultValue: { summary: 'flex-start' },
      },
      control: {
        type: 'select',
      },
    },
  },
} satisfies Meta<typeof Grid>;

type Story = StoryObj<typeof Grid>;

export const Demo: Story = {
  render: ({ children, ...props }) => (
    <Grid {...props}>
      <GridCell span={6}>
        <Button>One</Button>
      </GridCell>
      <GridCell span={6}>
        <Button>Two</Button>
      </GridCell>
    </Grid>
  ),
};
