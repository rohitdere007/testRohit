import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Grid } from './Grid';
import { GridCell } from './GridCell';

const position = ['center', 'end', 'flex-end', 'flex-start', 'start'];

export default {
  component: GridCell,
  title: 'atoms/Grid.Cell',
  parameters: {
    docs: {
      description: {
        component:
          'The Grid.Cell component is a styled component that offers props for css grid cell values.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
      description: 'The contents of the Grid',
      table: {
        type: { summary: 'React.ReactNode' },
      },
    },
    span: {
      control: { type: 'number' },
      description: 'the number of columns of the grid the cell should span',
      table: {
        type: { summary: 'number | number[]' },
        defaultValue: { summary: '1' },
      },
    },
    alignSelf: {
      options: position,
      description: 'the `align-self` value:',
      table: {
        type: {
          summary: 'Property.AlignSelf',
        },
        defaultValue: { summary: 'flex-start' },
      },
      control: {
        type: 'select',
      },
    },
  },
} satisfies Meta<typeof GridCell>;

type Story = StoryObj<typeof GridCell>;

export const Demo: Story = {
  args: {
    span: 6,
  },
  render: ({ children, ...props }) => (
    <Grid>
      <GridCell span={6}>
        <Button>One</Button>
      </GridCell>
      <GridCell span={6} {...props}>
        <Button>Two</Button>
      </GridCell>
    </Grid>
  ),
};

export const Span: Story = {
  args: {
    span: [12, 6, 4],
  },
  render: ({ children, ...props }) => (
    <Grid>
      <GridCell {...props}>
        <Button>One</Button>
      </GridCell>
      <GridCell {...props}>
        <Button>Two</Button>
      </GridCell>
      <GridCell {...props}>
        <Button>Two</Button>
      </GridCell>
    </Grid>
  ),
};
