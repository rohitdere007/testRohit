import { Meta, StoryObj } from '@storybook/react';

import { List } from '.';

type Story = StoryObj<typeof List>;

export default {
  component: List,
  args: {
    children: (
      <>
        <List.Item>Item 1</List.Item>
        <List.Item>Item 2</List.Item>
        <List.Item>Item 3</List.Item>
        <List.Item>Item 4</List.Item>
      </>
    ),
  },
} satisfies Meta<typeof List>;

export const Default: Story = {};

export const WithNestedChildren: Story = {
  args: {
    children: (
      <>
        <List.Item>
          Item 1
          <List>
            <List.Item>Subitem A</List.Item>
            <List.Item>Subitem B</List.Item>
            <List.Item>Subitem C</List.Item>
          </List>
        </List.Item>
        <List.Item>
          Item 2
          <List>
            <List.Item>Subitem A</List.Item>
            <List.Item>Subitem B</List.Item>
            <List.Item>Subitem C</List.Item>
          </List>
        </List.Item>
        <List.Item>
          Item 3
          <List>
            <List.Item>Subitem A</List.Item>
            <List.Item>Subitem B</List.Item>
            <List.Item>Subitem C</List.Item>
          </List>
        </List.Item>
      </>
    ),
  },
};

export const DoubleNested: Story = {
  args: {
    children: (
      <>
        <List.Item>
          Item 1
          <List>
            <List.Item>Subitem A</List.Item>
            <List.Item>Subitem B</List.Item>
            <List.Item>
              Subitem C
              <List>
                <List.Item>Sub-subitem A</List.Item>
                <List.Item>Sub-subitem B</List.Item>
                <List.Item>Sub-subitem C</List.Item>
              </List>
            </List.Item>
          </List>
        </List.Item>
      </>
    ),
  },
};

export const CustomIndentationLevel: Story = {
  args: {
    ...DoubleNested.args,
    indentSpacing: 8,
  },
};

export const CustomGap: Story = {
  args: {
    ...DoubleNested.args,
    gap: 4,
  },
};

export const CustomMargin: Story = {
  args: {
    ...DoubleNested.args,
    m: '2 4 6 8',
  },
};
