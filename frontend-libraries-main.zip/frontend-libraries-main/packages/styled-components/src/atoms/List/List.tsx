import { ComponentPropsWithoutRef } from 'react';
import styled, { css } from 'styled-components';

import { type Space, Spacing, getSpace, getSpacing } from '@/styles/space';
import { WidthProps, isWidthProp, width } from '@/styles/width';

type ListProps = ComponentPropsWithoutRef<'ul'> & {
  gap?: Space;
  indentSpacing?: Space;
  m?: Spacing;
};

const ListInner = styled.ul.withConfig({
  shouldForwardProp: (prop) => !['indentSpacing', 'gap', 'm'].includes(prop),
})<ListProps>`
  ${(props) =>
    props.indentSpacing
      ? css`
          --indent-spacing: ${getSpace(props.indentSpacing)};
        `
      : ''};

  ${(props) =>
    props.gap
      ? css`
          --list-gap: ${getSpace(props.gap)};
        `
      : ''}

  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--list-gap);
  ${(props) =>
    props.m !== undefined &&
    css`
      margin: ${getSpacing(props.m ?? '')};
    `}
`;
ListInner.displayName = 'List.Inner';

export function List(props: ListProps) {
  return <ListInner {...props} />;
}

const ListItem = styled.li.withConfig({
  shouldForwardProp: (p) => !isWidthProp(p),
})<WidthProps>`
  box-sizing: border-box;
  ${width};
  ${ListInner} {
    margin-top: var(--list-gap, 0);
    margin-left: var(--indent-spacing, ${getSpace(2)});
  }
`;
ListItem.displayName = 'List.Item';

List.Item = ListItem;
