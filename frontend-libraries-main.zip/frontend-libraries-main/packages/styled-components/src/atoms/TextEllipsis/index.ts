import styled from 'styled-components';

import { textEllipsisStyles } from '@/styles/typography';

export const TextEllipsis = styled.span`
  ${textEllipsisStyles};
`;
