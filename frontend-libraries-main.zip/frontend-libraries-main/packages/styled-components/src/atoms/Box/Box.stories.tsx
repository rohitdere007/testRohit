import { Meta, StoryObj } from '@storybook/react';
import React from 'react';

import { SquareButton } from '@/buttons/SquareButton';

import { Box } from '.';

export default {
  component: Box,
  title: 'atoms/Box',
  parameters: {
    docs: {
      description: {
        component:
          'the Box component is a styled component that offers props for margin & padding only. This is intended as a base component to create new components that require the margin & padding props.',
      },
    },
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the box',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    margin: {
      control: { type: 'text' },
      description: 'the margin value of the box',
      table: {
        type: { summary: 'string' },
      },
    },
    m: {
      control: { type: 'text' },
      description: 'the short name margin value of the box',
      table: {
        type: { summary: 'string' },
      },
    },
    padding: {
      control: { type: 'text' },
      description: 'the padding value of the box',
      table: {
        type: { summary: 'string' },
      },
    },
    p: {
      control: { type: 'text' },
      description: 'the short name padding value of the box',
      table: {
        type: { summary: 'string' },
      },
    },
  },
} satisfies Meta<typeof Box>;

type Story = StoryObj<typeof Box>;

export const ShortNames: Story = {
  args: {
    m: '0 0 0 0',
    p: '0 0 0 0',
  },
  parameters: {
    controls: {
      exclude: ['margin', 'padding'],
    },
  },
  render: (props) => (
    <Box {...props}>{props.children || <SquareButton>1</SquareButton>}</Box>
  ),
};

export const FullNames: Story = {
  args: {
    margin: '0 0 0 0',
    padding: '0 0 0 0',
  },
  parameters: {
    controls: {
      exclude: ['m', 'p'],
    },
  },
  render: (props) => (
    <Box {...props}>{props.children || <SquareButton>1</SquareButton>}</Box>
  ),
};
