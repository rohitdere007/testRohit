import styled, { css } from 'styled-components';

import { MarginProps, isMarginPropName, margin } from '@/styles/margin';
import { PaddingProps, isPaddingPropName, padding } from '@/styles/padding';

export type BoxProps = MarginProps & PaddingProps;

export const isBoxPropName = (propName: string) =>
  isMarginPropName(propName) || isPaddingPropName(propName);

export const boxStyles = css<BoxProps>`
  ${margin}
  ${padding}
`;

export const Box = styled.div.withConfig({
  shouldForwardProp: (propName) => !isBoxPropName(propName),
})<MarginProps & PaddingProps>`
  ${margin}
  ${padding}
`;

Box.displayName = 'Box';
