import React from 'react';
import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { MarginProps } from '@/styles/margin';

type DividerProps = MarginProps & React.HTMLAttributes<HTMLHRElement>;

export const Divider = styled.hr<DividerProps>`
  background-color: ${getColor('border')};

  height: 1px;
  width: 100%;

  border: none;
  display: block;
  padding: 0;
  margin: 0;
`;
