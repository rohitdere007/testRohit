import styled, { css } from 'styled-components';

import { getSpace } from '@/styles/space';

export const headerStyles = css`
  padding: ${getSpace(3)};
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: ${getSpace(2)};
`;

export const Header = styled.header`
  ${headerStyles}
`;

Header.displayName = 'Header';
