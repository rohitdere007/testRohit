import { Meta, StoryObj } from '@storybook/react';

import { Modal } from '@/modals/Modal';

import { Header } from './Header';

export default {
  component: Header,
  args: {
    children: undefined,
  },
  parameters: {
    docs: {
      description: {
        component:
          'The Header component is a header element expecting two children separated with space between. This is utilized as a base component for multiple component headers.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Header>;

type Story = StoryObj<typeof Header>;

export const Demo: Story = {
  render: (props) => (
    <Header {...props}>
      <Modal.Title title="Hello" />
      <Modal.Close />
    </Header>
  ),
};
