import styled from 'styled-components';

import { FlexParams, flex, isFlexParam } from '@/styles/flex';
import { WidthProps, isWidthProp, width } from '@/styles/width';

import { Box, BoxProps, boxStyles } from '../Box';

export type FlexProps = BoxProps & WidthProps & FlexParams;

export const isFlexPropName = (p: string) => isFlexParam(p) || isWidthProp(p);

export const Flex = styled(Box).withConfig({
  shouldForwardProp: (propName) => !isFlexPropName(propName),
})<FlexProps>`
  ${flex};
  ${boxStyles};
  ${width};
`;

Flex.displayName = 'Flex';
