import { Meta, StoryObj } from '@storybook/react';

import { SquareButton } from '@/buttons/SquareButton';

import { Flex } from './Flex';

const position = ['center', 'end', 'flex-end', 'flex-start', 'start'];
const alignOptions = ['stretch', 'baseline', 'normal', ...position];
const distribution = [
  'space-around',
  'space-between',
  'space-evenly',
  'stretch',
];

const directionOptions = ['column', 'column-reverse', 'row', 'row-reverse'];

const justifyOptions = [
  ...position,
  ...distribution,
  'left',
  'normal',
  'right',
];

export default {
  component: Flex,
  title: 'atoms/Flex (Box)',
  parameters: {
    docs: {
      description: {
        component:
          'the Flex component is a styled component that provides props for the most commonly used flex-box rules; `flex-direction`, `justify-content`, `align-items` & `gap`.',
      },
    },
  },
  args: {
    justify: 'flex-start',
    align: 'flex-start',
    direction: 'row',
    gap: 1,
  },
  argTypes: {
    direction: {
      options: directionOptions,
      description: 'the `flex-direction` value:',
      table: {
        type: {
          summary: 'Property.FlexDirection',
        },
        defaultValue: { summary: 'row' },
      },
      control: {
        type: 'select',
      },
    },
    align: {
      options: alignOptions,
      description: 'the `align-items` value:',
      table: {
        type: {
          summary: 'Property.AlignItems',
        },
        defaultValue: { summary: 'flex-start' },
      },
      control: {
        type: 'select',
      },
    },
    justify: {
      options: justifyOptions,
      description: 'the `justify-content` value:',
      table: {
        type: {
          summary: 'Property.JustifyContent',
        },
        defaultValue: { summary: 'flex-start' },
      },
      control: {
        type: 'select',
      },
    },
    gap: {
      description: 'the `gap` value passed to the `getSpace` method',
      table: {
        defaultValue: { summary: '0' },
      },
      control: {
        type: 'number',
      },
    },
    margin: {
      control: { type: 'text' },
      description: 'the margin value of the component',
      table: {
        type: { summary: 'string' },
      },
    },
    padding: {
      control: { type: 'text' },
      description: 'the padding value of the component',
      table: {
        type: { summary: 'string' },
      },
    },
  },
} satisfies Meta<typeof Flex>;

type Story = StoryObj<typeof Flex>;

export const Demo: Story = {
  parameters: {
    controls: {
      exclude: ['m', 'p'],
    },
  },
  render: (props) => (
    <Flex {...props}>
      <SquareButton>1</SquareButton>
      <SquareButton>2</SquareButton>
      <SquareButton>3</SquareButton>
    </Flex>
  ),
};
