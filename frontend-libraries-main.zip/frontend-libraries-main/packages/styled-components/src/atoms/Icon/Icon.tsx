import MdiIcon from '@mdi/react';
import { IconProps as MdiProps } from '@mdi/react/dist/IconProps';
import { ReactNode } from 'react';
import styled, { css } from 'styled-components';

import { Box } from '@/atoms/Box';
import { Color, getColor } from '@/styles/color';
import { pixelate } from '@/styles/pixelate';

export const iconSizes = {
  xs: 12,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 32,
};

export type IconSize = keyof typeof iconSizes;

interface IconWrapperProps {
  size?: IconSize;
  color?: Color;
}

export interface IconProps
  extends Omit<MdiProps, 'size' | 'color' | 'path'>,
    Omit<IconWrapperProps, 'theme'> {
  inset?: number;
  icon: ReactNode;
  className?: string;
}

// figma icons have less padding than mdi code icons
export const IconWrapper = styled(Box).withConfig({
  shouldForwardProp: (propName) => !['color', 'size'].includes(propName),
})<IconWrapperProps>`
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;

  ${({ size = 'md', color }) => css`
    color: ${color ? getColor(color) : 'inherit'};

    height: ${pixelate(iconSizes[size])};
    width: ${pixelate(iconSizes[size])};
  `};
`;

export const Icon = ({
  size = 'md',
  color,
  inset = 0,
  icon,
  ...props
}: IconProps) => {
  const sizePx = pixelate(iconSizes[size] + inset * 2);
  return (
    <IconWrapper size={size} color={color}>
      {typeof icon === 'string' ? (
        <MdiIcon
          {...props}
          path={icon}
          size={sizePx}
          style={{
            maxWidth: sizePx,
            flex: 'none',
            ...props.style,
          }}
        />
      ) : (
        icon
      )}
    </IconWrapper>
  );
};

Icon.displayName = 'Icon';
