import { SVGProps } from 'react';

export const MoonIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={20}
    height={20}
    viewBox="0 0 20 20"
    fill="none"
    {...props}
  >
    <path
      fill="currentColor"
      d="M9.193 2.522a7.503 7.503 0 0 0 .825 14.959 7.508 7.508 0 0 0 7.458-6.667.836.836 0 0 0-1.283-.792A4.502 4.502 0 0 1 9.268 6.23c0-.883.258-1.716.7-2.408a.838.838 0 0 0-.775-1.3Z"
    />
  </svg>
);
