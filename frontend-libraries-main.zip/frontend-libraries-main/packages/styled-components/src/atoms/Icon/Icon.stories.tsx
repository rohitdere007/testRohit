import * as mdiIcons from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { Icon } from '.';

type Story = StoryObj<typeof Icon>;

export default {
  component: Icon,
  args: {
    icon: 'mdiMagnifyMinusOutline',
    inset: 0,
  },
  argTypes: {
    inset: {
      control: {
        type: 'number',
      },
    },
    size: {
      control: {
        type: 'select',
      },
      options: ['xs', 'sm', 'md', 'lg', 'xl'],
    },
    icon: {
      control: {
        type: 'select',
      },
      options: Object.keys(mdiIcons),
      mapping: mdiIcons,
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Icon component that matches the figma sizes.',
      },
    },
  },
} satisfies Meta<typeof Icon>;

export const Demo: Story = {};
