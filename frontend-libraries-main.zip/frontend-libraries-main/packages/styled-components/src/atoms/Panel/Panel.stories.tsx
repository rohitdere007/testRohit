import { Meta, StoryObj } from '@storybook/react';

import { Panel } from './Panel';

export default {
  component: Panel,
  args: {
    children: 'Panel content',
    padding: '3',
    width: '100%',
  },
  parameters: {
    docs: {
      description: {
        component:
          'A styled component with the fundamental styles to create a "raised" surface that provides props for padding & width.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Panel>;

type Story = StoryObj<typeof Panel>;

export const Demo: Story = {};
