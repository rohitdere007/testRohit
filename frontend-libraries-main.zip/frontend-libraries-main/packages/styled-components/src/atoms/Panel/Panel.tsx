import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { MarginProps, isMarginPropName, margin } from '@/styles/margin';
import { PaddingProps, isPaddingPropName, padding } from '@/styles/padding';
import { getRadius } from '@/styles/radius';
import { getBodyTextStyles } from '@/styles/typography';
import { WidthProps, isWidthProp, width } from '@/styles/width';

export type PanelProps = PaddingProps & WidthProps & MarginProps;

export const Panel = styled.div.withConfig({
  shouldForwardProp: (p) =>
    !isWidthProp(p) && !isPaddingPropName(p) && !isMarginPropName(p),
})<PanelProps>`
  ${getBodyTextStyles({ color: 'fg' })};
  ${width};
  ${padding};
  ${margin};

  border: solid 1px ${getColor('border')};
  border-radius: ${getRadius(2)};
  background: ${getColor('bgPrimary')};
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-sizing: border-box;
`;
