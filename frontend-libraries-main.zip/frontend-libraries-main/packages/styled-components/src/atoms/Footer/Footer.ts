import { PropsWithChildren } from 'react';
import styled from 'styled-components';

import { getBreakpoint } from '@/styles/breakpoint';
import { getColor } from '@/styles/color';
import { getSpace } from '@/styles/space';

export type FooterProps = PropsWithChildren;

export const Footer = styled.footer`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
  gap: ${getSpace(2)};
  padding: ${getSpace(3)};
  border-top: 1px solid ${getColor('border')};
  ${getBreakpoint('sm')} {
    flex-direction: row-reverse;
  }
`;

Footer.displayName = 'Footer';
