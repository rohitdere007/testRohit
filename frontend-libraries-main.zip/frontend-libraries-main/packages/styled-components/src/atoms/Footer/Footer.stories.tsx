import { Meta, StoryObj } from '@storybook/react';
import React from 'react';

import { Button } from '@/buttons/Button';

import { Footer } from './Footer';

export default {
  component: Footer,
  args: {
    children: undefined,
  },
  parameters: {
    docs: {
      description: {
        component:
          'The Footer component is a Footer element expecting one or two children which are separated with space between & the direction being row reversed so then the primary item is on the right hand side. This is utilized as a base component for multiple component Footers.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Footer>;

type Story = StoryObj<typeof Footer>;

export const Demo: Story = {
  render: (props) => (
    <Footer {...props}>
      <Button variant="primary">Confirm</Button>
    </Footer>
  ),
};
