import styled from 'styled-components';

import { getColor } from '@/styles/color';

export const Separator = styled.div.attrs({
  role: 'separator',
})`
  flex: 0 0 1px;
  background: ${getColor('border')};
`;

Separator.displayName = 'Separator';
