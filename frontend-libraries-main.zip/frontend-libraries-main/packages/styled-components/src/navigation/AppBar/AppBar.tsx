import { mdiMenu } from '@mdi/js';
import { HTMLAttributes, ReactNode } from 'react';
import styled from 'styled-components';

import { IconButton } from '@/buttons/IconButton';
import { getColor } from '@/styles/color';
import { getSize } from '@/styles/size';
import { getSpace, getSpacing } from '@/styles/space';
import { NationalGridLogo } from '@/svgs';

import { useMainNavContext } from '../MainNav/MainNavContext';

const AppBarNav = styled.nav`
  padding: ${getSpacing('2')};
  background: ${getColor('bgPrimary')};
  border-bottom: 1px solid ${getColor('border')};
  box-sizing: border-box;
  height: ${getSize(14)};
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const AppBarLogo = styled.div`
  color: ${getColor('fgBrand')};
  padding-left: ${getSpace(1.5)};
  svg {
    max-height: ${getSize(12)};
  }
`;

const AppBarButtons = styled.div`
  display: flex;
  gap: ${getSpace()};
`;

const AppBarStart = styled.div`
  display: flex;
  align-items: center;
  gap: ${getSpace()};
`;

export interface AppBarProps extends HTMLAttributes<HTMLElement> {
  menu?: boolean;
  logo?: ReactNode;
  children?: ReactNode;
}

const FallbackLogoWrapper = styled.div`
  svg {
    height: ${getSize(6)};
  }
`;

export const AppBar = ({
  children,
  logo,
  menu = true,
  'aria-label': label,
  ...props
}: AppBarProps) => {
  const { open, toggleMenu } = useMainNavContext();
  return (
    <AppBarNav aria-label={label || 'App Bar'} {...props}>
      <AppBarStart>
        {menu && (
          <IconButton
            aria-expanded={open}
            icon={mdiMenu}
            aria-label={open ? 'Close Menu' : 'Open Menu'}
            onClick={toggleMenu}
            ghost
            size="xl"
          />
        )}
        <AppBarLogo>
          {logo || (
            <FallbackLogoWrapper>
              <NationalGridLogo />
            </FallbackLogoWrapper>
          )}
        </AppBarLogo>
      </AppBarStart>
      {children && <AppBarButtons>{children}</AppBarButtons>}
    </AppBarNav>
  );
};

AppBar.displayName = 'AppBar';
