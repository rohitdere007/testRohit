import { mdiAccountCircle, mdiMagnify, mdiViewDashboard } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { ShowAt } from '@/atoms/Breakpoint';
import { MoonIcon } from '@/atoms/Icon';
import { IconButton } from '@/buttons/IconButton';

import { MainNavProvider } from '../MainNav/MainNavProvider';

import { AppBar } from './AppBar';

type Story = StoryObj<typeof AppBar>;

export default {
  component: AppBar,
  parameters: {
    controls: {},
    docs: {
      description: {
        component:
          "The `AppBar` component is intended to be always be displayed at the top off the page so then the main menu and app actions are available to the user. It expects to be passed instances of `Button` or `IconButton` as it's children.\n It accepts optional `menu` & `logo` props to hide the main menu button and/or provide a custom logo.",
      },
    },
  },
  args: {},
  argTypes: {
    logo: {
      control: false,
      description: 'Replace the AppBar logo',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    children: {
      control: false,
      description: 'the buttons to be displayed on the right of the AppBar',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    menu: {
      control: { type: 'boolean' },
      defaultValue: true,
      description: 'If the menu button should be rendered',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'true' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof AppBar>;

export const Demo: Story = {
  render(props) {
    return (
      <MainNavProvider>
        <AppBar {...props}>
          <IconButton size="xl" ghost icon={mdiMagnify} aria-label="Search" />
          <ShowAt breakpoint="sm">
            <IconButton
              size="xl"
              ghost
              icon={mdiAccountCircle}
              aria-label="Account"
            />
          </ShowAt>
          <IconButton
            size="xl"
            ghost
            icon={<MoonIcon />}
            aria-label="Change Theme"
          />
          <ShowAt breakpoint="sm">
            <IconButton
              size="xl"
              ghost
              icon={mdiViewDashboard}
              aria-label="Dashboard"
            />
          </ShowAt>
        </AppBar>
      </MainNavProvider>
    );
  },
};
