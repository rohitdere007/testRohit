import { Meta, StoryObj } from '@storybook/react';

import { Breadcrumbs } from './Breadcrumbs';
import { BreadcrumbCurrent } from './BreadcrumbsCurrent';
import { BreadcrumbItem } from './BreadcrumbsItem';

type Story = StoryObj<typeof BreadcrumbCurrent>;

export default {
  component: BreadcrumbCurrent,
  title: 'navigation/Breadcrumbs.Current',
  parameters: {
    docs: {
      description: {
        component:
          'The `Breadcrumbs.Current` is a `li` that should receive the current page title text as children. It is expected to be used as a child component of `Breadcrumbs`',
      },
    },
  },
  args: {
    children: 'Current Page',
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the button',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof BreadcrumbCurrent>;

export const Demo: Story = {
  render: () => (
    <Breadcrumbs>
      <BreadcrumbItem
        as="a"
        title="National Grid"
        href="https://nationalgrid.com"
        target="_blank"
      >
        National Grid
      </BreadcrumbItem>
      <BreadcrumbCurrent>Current Page</BreadcrumbCurrent>
    </Breadcrumbs>
  ),
};
