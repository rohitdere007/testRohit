import styled from 'styled-components';

import { getColor } from '@/styles/color';

export const BreadcrumbCurrent = styled.li`
  line-height: 1;
  color: ${getColor('fg')};
`;

BreadcrumbCurrent.displayName = 'Breadcrumbs.Current';
