import { ButtonHTMLAttributes } from 'react';
import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getSpace } from '@/styles/space';
import { AsProps } from '@/utils/typescript';

import { LinkButton } from '../../buttons/LinkButton';

const BreadcrumbListItem = styled.li`
  line-height: 1;

  &:after {
    content: '/';
    color: ${getColor('fgSubtle')};
    margin-left: ${getSpace(2)};
    text-decoration: none;
  }

  ${LinkButton} {
    line-height: 1;
  }
`;

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement>;

export const BreadcrumbItem = <C extends React.ElementType>(
  props: ButtonProps & AsProps<C>,
) => (
  <BreadcrumbListItem>
    <LinkButton {...props} />
  </BreadcrumbListItem>
);

BreadcrumbItem.displayName = 'Breadcrumbs.Item';
