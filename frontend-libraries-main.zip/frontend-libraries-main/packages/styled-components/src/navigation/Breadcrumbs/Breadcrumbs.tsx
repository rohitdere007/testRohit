import { HTMLAttributes } from 'react';
import styled from 'styled-components';

import { getSpace } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

import { BreadcrumbCurrent } from './BreadcrumbsCurrent';
import { BreadcrumbItem } from './BreadcrumbsItem';

const BreadcrumbList = styled.ol`
  display: flex;
  gap: ${getSpace(2)};
  flex-wrap: wrap;
  list-style: none;
  ${getUITextStyles({ size: 'md' })};
`;

export const Breadcrumbs = ({
  children,
  ...props
}: Omit<HTMLAttributes<HTMLElement>, 'title'>) => (
  <nav {...props} aria-label={props['aria-label'] || 'Breadcrumbs'}>
    <BreadcrumbList>{children}</BreadcrumbList>
  </nav>
);

Breadcrumbs.displayName = 'Breadcrumbs';

Breadcrumbs.Item = BreadcrumbItem;
Breadcrumbs.Current = BreadcrumbCurrent;
