import { Meta, StoryObj } from '@storybook/react';

import { Breadcrumbs } from './Breadcrumbs';
import { BreadcrumbCurrent } from './BreadcrumbsCurrent';
import { BreadcrumbItem } from './BreadcrumbsItem';

export default {
  component: Breadcrumbs,
  args: { children: 'Breadcrumb Text' },
  parameters: {
    docs: {
      description: {
        component:
          "The `Breadcrumbs` component is intended to be the parent `nav` element that expects to have `Breadcrumbs.Item` & `Breadcrumbs.Current` as it's children.",
      },
    },
  },
} satisfies Meta<typeof Breadcrumbs>;

type Story = StoryObj<typeof Breadcrumbs>;

export const Demo: Story = {
  render({ children, ...props }) {
    return (
      <Breadcrumbs {...props}>
        <BreadcrumbItem as="a" href="/" title="Link Title">
          {children}
        </BreadcrumbItem>
        <BreadcrumbCurrent>{children}</BreadcrumbCurrent>
      </Breadcrumbs>
    );
  },
};
