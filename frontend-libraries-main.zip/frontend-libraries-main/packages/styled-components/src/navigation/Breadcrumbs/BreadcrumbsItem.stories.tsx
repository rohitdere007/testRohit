import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';

import { Breadcrumbs } from './Breadcrumbs';
import { BreadcrumbItem } from './BreadcrumbsItem';

type Story = StoryObj<typeof BreadcrumbItem>;

export default {
  component: BreadcrumbItem,
  title: 'navigation/Breadcrumbs.Item',
  parameters: {
    docs: {
      controls: {
        exclude: ['onClick'],
      },
      description: {
        component:
          'The `Breadcrumbs.Item` is a `LinkButton` instance wrapped in an `li` element intended to be used as a child of `Breadcrumbs`. As the `Breadcrumbs.Item` is a polymorphic button, you can pass react-router or NextJs\'s `Link` component in place of the `"a"`',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    children: 'Button Content',
    onClick: action('onClick'),
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the button',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof BreadcrumbItem>;

export const Demo: Story = {
  render: () => (
    <Breadcrumbs>
      <Breadcrumbs.Item
        as="a"
        title="National Grid"
        href="https://nationalgrid.com"
        target="_blank"
      >
        National Grid
      </Breadcrumbs.Item>
      <Breadcrumbs.Current>Current Page</Breadcrumbs.Current>
    </Breadcrumbs>
  ),
};

// export const AsRouterLink: Story = {
//   parameters: {
//     reactRouter: reactRouterParameters({
//       location: {
//         pathParams: { link: 'router-link-1' },
//       },
//       routing: {
//         path: '/buttons/:link',
//         useStoryElement: true,
//       },
//     }),
//   },
//   decorators: [withRouter],
//   render: () => (
//     <>
//       <LocationOutlet />
//       <Breadcrumbs>
//         <Breadcrumbs.Item
//           as={Link}
//           to="/buttons/router-link-1"
//           aria-label="Link 1"
//         >
//           Router Link 1
//         </Breadcrumbs.Item>
//         <Breadcrumbs.Item as={Link} to="/buttons/router-link-2">
//           Router Link 2
//         </Breadcrumbs.Item>
//         <Breadcrumbs.Item as={Link} to="/buttons/router-link-3">
//           Router Link 3
//         </Breadcrumbs.Item>
//         <Breadcrumbs.Current>Current Page</Breadcrumbs.Current>
//       </Breadcrumbs>
//     </>
//   ),
// };
