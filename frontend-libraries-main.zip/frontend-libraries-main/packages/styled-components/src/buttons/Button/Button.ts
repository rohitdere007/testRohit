import styled from 'styled-components';

import { getFontWeight } from '@/styles/fontWeight';
import { MarginProps, isMarginPropName, margin } from '@/styles/margin';
import { getSpace } from '@/styles/space';

import { PlainButton } from '../PlainButton';

import { buttonGhostVariants } from './buttonGhostVariants';
import { ButtonSize, buttonSizes } from './buttonSizes';
import { ButtonVariant, buttonVariants } from './buttonVariants';

export interface ButtonCustomProps {
  variant?: ButtonVariant;
  size?: ButtonSize;
  ghost?: boolean;
}

const shouldForwardProp = (propName: string) =>
  !['variant', 'size', 'ghost'].includes(propName) &&
  !isMarginPropName(propName);

export const Button = styled(PlainButton).withConfig({
  shouldForwardProp,
})<ButtonCustomProps & MarginProps>`
  display: inline-flex;
  justify-content: center;
  align-items: center;
  gap: ${getSpace()};
  flex-shrink: 0;
  background-color: inherit;
  ${({ size }) => buttonSizes[size || 'md']};
  ${({ variant, ghost }) =>
    (ghost ? buttonGhostVariants : buttonVariants)[variant || 'base']};
  font-weight: ${getFontWeight('semi-bold')};
  ${margin}

  line-height: 1;
`;

Button.displayName = 'Button';
