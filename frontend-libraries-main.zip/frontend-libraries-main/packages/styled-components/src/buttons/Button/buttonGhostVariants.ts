import { RuleSet, css } from 'styled-components';

import { getColor } from '@/styles/color';

import { ButtonVariant, IsSelectedSelector } from './buttonVariants';

const base = css`
  color: ${getColor('fg')};

  &:not(:disabled) {
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgPressed')};
    }
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgHover')};
    }
  }
`;

const primary = css`
  color: ${getColor('fgInfo')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgInfoSubtlestHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgInfoSubtlestPressed')};
    }
  }
`;

const success = css`
  color: ${getColor('fgSuccess')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgSuccessSubtlestHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgSuccessSubtlestPressed')};
    }
  }
`;

const critical = css`
  color: ${getColor('fgCritical')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgCriticalSubtlestHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgCriticalSubtlestPressed')};
    }
  }
`;

const warning = css`
  color: ${getColor('fgWarning')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgWarningSubtlestHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgWarningSubtlestPressed')};
    }
  }
`;

const discovery = css`
  color: ${getColor('fgDiscovery')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgDiscoverySubtlestHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgDiscoverySubtlestPressed')};
    }
  }
`;

export const buttonGhostVariants: Record<ButtonVariant, RuleSet<object>> = {
  base,
  primary,
  success,
  critical,
  warning,
  discovery,
};
