import { render, screen } from '@testing-library/react';

import { getColor } from '@/styles/color';
import { darkMode as dm, lightMode } from '@/theme/modes';
import { withTheme } from '@/utils/jest';

import { Button } from './Button';

const darkMode = dm as unknown as typeof lightMode;
const params = { wrapper: withTheme };

describe('Button', () => {
  describe('Variant', () => {
    it('should use the correct color for default text', () => {
      render(<Button>Button</Button>, params);
      const component = screen.getByText('Button');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fg')({ theme: darkMode }),
      );
    });
    it('should use the correct color for primary text', () => {
      render(<Button variant="primary">Button</Button>, params);
      const component = screen.getByText('Button');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnDark')({ theme: darkMode }),
      );
    });
    it('should use the correct color for warning text', () => {
      render(<Button variant="warning">Button</Button>, params);
      const component = screen.getByText('Button');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnLight')({ theme: darkMode }),
      );
    });
    it('should use the correct color for critical text', () => {
      render(<Button variant="critical">Button</Button>, params);
      const component = screen.getByText('Button');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnDark')({ theme: darkMode }),
      );
    });
    it('should use the correct color for success text', () => {
      render(<Button variant="success">Button</Button>, params);
      const component = screen.getByText('Button');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnDark')({ theme: darkMode }),
      );
    });
  });
  describe('Size', () => {
    describe('padding & font-size', () => {
      it('xs', () => {
        render(<Button size="xs">Button</Button>, params);
        const component = screen.getByText('Button');
        expect(component).toHaveStyleRule('font-size', '12px');
      });
      it('lg', () => {
        render(<Button size="lg">Button</Button>, params);
        const component = screen.getByText('Button');
        expect(component).toHaveStyleRule('font-size', '16px');
      });
    });
  });
  describe('when disabled', () => {
    it("should set the opacity to visually show the button's state", () => {
      render(<Button disabled>Button</Button>, params);
      const component = screen.getByText('Button');
      expect(component).toBeDisabled();
    });
  });
});
