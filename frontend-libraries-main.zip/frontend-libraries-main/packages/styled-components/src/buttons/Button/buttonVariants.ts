import { css } from 'styled-components';
import { Interpolation } from 'styled-components/dist/types';

import { getColor } from '@/styles/color';

export const IsSelectedSelector = `
  &[aria-checked='true'],
  &[aria-current]:not([aria-current='false']),
  &[aria-pressed='true'],
  &[aria-selected='true']
`;

export const buttonActiveStyles = (styles: Interpolation<object>) => css`
  &:active,
  ${IsSelectedSelector} {
    ${styles}
  }
`;

const base = css`
  color: ${getColor('fg')};
  background-color: ${getColor('bg')};
  border: 1px solid ${getColor('border')};

  &:not(:disabled) {
    &:active,
    ${IsSelectedSelector} {
      border-color: ${getColor('borderPressed')};
      background-color: ${getColor('bgPressed')};
    }
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderHover')};
      background-color: ${getColor('bgHover')};
    }
  }
`;

const primary = css`
  color: ${getColor('fgOnDark')};
  background-color: ${getColor('bgInfo')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgInfoHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgInfoPressed')};
    }
  }
`;

const success = css`
  color: ${getColor('fgOnDark')};
  background-color: ${getColor('bgSuccess')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgSuccessHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgSuccessPressed')};
    }
  }
`;

const critical = css`
  color: ${getColor('fgOnDark')};
  background-color: ${getColor('bgCritical')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgCriticalHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgCriticalPressed')};
    }
  }
`;

const warning = css`
  color: ${getColor('fgOnLight')};
  background-color: ${getColor('bgWarning')};

  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgWarningHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgWarningPressed')};
    }
  }
`;

const discovery = css`
  color: ${getColor('fgOnDark')};
  background-color: ${getColor('bgDiscovery')};
  &:not(:disabled) {
    &:hover,
    &:focus-visible {
      background-color: ${getColor('bgDiscoveryHover')};
    }
    &:active,
    ${IsSelectedSelector} {
      background-color: ${getColor('bgDiscoveryPressed')};
    }
  }
`;

export const buttonVariants = {
  base,
  primary,
  success,
  critical,
  warning,
  discovery,
};

export type ButtonVariant = keyof typeof buttonVariants;
