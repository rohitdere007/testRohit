import { css } from 'styled-components';

import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';
import { getSpace } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

export const buttonSizes = {
  xs: css`
    height: ${getSize(6)};
    min-width: ${getSize(12)};
    padding: 0 ${getSpace(2)};
    border-radius: ${getRadius()};
    ${getUITextStyles({ size: 'sm' })}
  `,
  sm: css`
    height: ${getSize(7)};
    min-width: ${getSize(12)};
    padding: ${getSpace(1.5)} ${getSpace(2)};
    border-radius: ${getRadius()};
    ${getUITextStyles({ size: 'md' })}
  `,
  md: css`
    height: ${getSize(8)};
    min-width: ${getSize(16)};
    padding: ${getSpace(1.5)} ${getSpace(3)};
    border-radius: ${getRadius(1.5)};
    ${getUITextStyles({ size: 'md' })}
  `,
  lg: css`
    height: ${getSize(9)};
    min-width: ${getSize(16)};
    padding: ${getSpace(2)} ${getSpace(3)};
    border-radius: ${getRadius(1.5)};
    ${getUITextStyles({ size: 'lg' })}
  `,
  xl: css`
    height: ${getSize(10)};
    min-width: ${getSize(16)};
    padding: ${getSpace(2)} ${getSpace(3)};
    border-radius: ${getRadius(1.5)};
    ${getUITextStyles({ size: 'lg' })}
  `,
};

export type ButtonSize = keyof typeof buttonSizes;
