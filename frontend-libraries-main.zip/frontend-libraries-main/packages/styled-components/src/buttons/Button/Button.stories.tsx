import { mdiFilter } from '@mdi/js';
import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { ButtonHTMLAttributes, MouseEvent, useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import {
  reactRouterParameters,
  withRouter,
} from 'storybook-addon-remix-react-router';

import { Icon } from '@/atoms/Icon';
import { Toolbar } from '@/navigation/Toolbar';
import { LocationOutlet } from '@/storybook/LocationOutlet';

import { Button, ButtonCustomProps } from './Button';
import { buttonSizes } from './buttonSizes';
import { buttonVariants } from './buttonVariants';

type ButtonType = React.ComponentType<
  ButtonHTMLAttributes<HTMLButtonElement> & ButtonCustomProps
>;

type Story = StoryObj<ButtonType>;

const buttonVariantOptions = Object.keys(buttonVariants);
const buttonSizeOptions = Object.keys(
  buttonSizes,
) as ButtonCustomProps['size'][];

const meta: Meta<ButtonType> = {
  component: Button,
  parameters: {
    controls: {
      exclude: ['onClick'],
    },
    docs: {
      description: {
        component:
          '<p>The `Button` component accepts the native props expected of the html button component ' +
          'along with some additional props to control the `variant` and `size` of the button<p>' +
          '<p>It extends the `PlainButton` component which controls the transitions associated with the interactions</p>' +
          '<p>When using keyboard navigation to tab to the button an outline will be displayed to assist the user</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    disabled: false,
    children: 'Button',
    onClick: action('onClick'),
    'aria-pressed': false,
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the button',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    variant: {
      options: buttonVariantOptions,
      description: 'The semanic style of the button',
      table: {
        type: {
          summary: buttonVariantOptions.join(' | '),
        },
        defaultValue: { summary: '"base"' },
      },
      control: {
        type: 'select',
      },
    },
    ghost: {
      control: { type: 'boolean' },
      description: 'The "ghost" version of the variant',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    size: {
      options: buttonSizeOptions,
      table: {
        type: {
          summary: buttonSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
      control: {
        type: 'select',
      },
      description: 'The preset size of the button',
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
};

export default meta;

export const ButtonChildren: Story = {
  name: 'Button',
  parameters: {
    docs: {
      name: 'Button',
      description: {
        story:
          '<p>The Button component has 5 display states which are; `default`, `hover`, `focus-visible`, `active` & `disabled`.</p>' +
          "<p>The Button's active state can be triggered by setting the `aria-checked` " +
          'or `aria-pressed` property to `true` or the `aria-current` property to  anything other than `false`.</p>',
      },
    },
  },
  render: ({ children, onClick, ...props }) => {
    const [, updateArgs] = useArgs();
    const [selected, setSelected] = useState<boolean>(!!props['aria-pressed']);
    useEffect(() => {
      if (selected !== !!props['aria-pressed']) {
        setSelected(!!props['aria-pressed']);
      }
    }, [props['aria-pressed']]);

    const iconSize =
      props.size && ['xs', 'sm'].includes(props.size) ? 'sm' : 'md';
    return (
      <Toolbar>
        <Button
          {...props}
          aria-pressed={selected}
          onClick={(event: React.MouseEvent) => {
            updateArgs({ 'aria-pressed': !selected });
            setSelected((previous) => !previous);
            onClick?.(event as never);
          }}
        >
          {children}
        </Button>
        <Button
          {...props}
          aria-pressed={selected}
          onClick={(event: React.MouseEvent) => {
            updateArgs({ 'aria-pressed': !selected });
            setSelected((previous) => !previous);
            onClick?.(event as never);
          }}
        >
          <Icon icon={mdiFilter} size={iconSize} />
          {children}
        </Button>
        <Button
          {...props}
          aria-pressed={selected}
          onClick={(event: React.MouseEvent) => {
            updateArgs({ 'aria-pressed': !selected });
            setSelected((previous) => !previous);
            onClick?.(event as never);
          }}
        >
          {children}
          <Icon icon={mdiFilter} size={iconSize} />
        </Button>
      </Toolbar>
    );
  },
};

export const ButtonVariants: Story = {
  parameters: {
    controls: {
      exclude: ['variant', 'children'],
    },
    docs: {
      description: {
        story:
          '<p>The Button takes a variant prop which takes the semantic names of our variants which are;  </p>' +
          '<p>`primary`, `success`, `critical`, `warning` & `discovery`</p>',
      },
    },
  },
  render({ children, variant, disabled, onClick: onClickProp, ...props }) {
    const [selected, setSelected] = useState<string>();
    const onClick = (event: MouseEvent<HTMLButtonElement>, value: string) => {
      setSelected((prev) => (prev !== value ? value : undefined));
      onClickProp?.(event);
    };
    return (
      <Toolbar>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'primary')}
          aria-pressed={selected === 'primary'}
          variant="primary"
        >
          primary
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'success')}
          aria-pressed={selected === 'success'}
          variant="success"
        >
          success
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'warning')}
          aria-pressed={selected === 'warning'}
          variant="warning"
        >
          warning
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'critical')}
          aria-pressed={selected === 'critical'}
          variant="critical"
        >
          critical
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'discovery')}
          aria-pressed={selected === 'discovery'}
          variant="discovery"
        >
          discovery
        </Button>
      </Toolbar>
    );
  },
};

export const ButtonGhostVariants: Story = {
  args: {
    ghost: true,
  },
  parameters: {
    controls: {
      exclude: ['variant', 'children'],
    },
    docs: {
      description: {
        story:
          '<p>In addition to the varient prop, there is a ghost version for each variant color</p>' +
          '<p>`primary`, `success`, `critical`, `warning` & `discovery`</p>',
      },
    },
  },
  render({ children, variant, disabled, onClick: onClickProp, ...props }) {
    const [selected, setSelected] = useState<string>();
    const onClick = (event: MouseEvent<HTMLButtonElement>, value: string) => {
      setSelected((prev) => (prev !== value ? value : undefined));
      onClickProp?.(event);
    };
    return (
      <Toolbar>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'primary')}
          aria-pressed={selected === 'primary'}
          variant="primary"
        >
          primary
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'success')}
          aria-pressed={selected === 'success'}
          variant="success"
        >
          success
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'warning')}
          aria-pressed={selected === 'warning'}
          variant="warning"
        >
          warning
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'critical')}
          aria-pressed={selected === 'critical'}
          variant="critical"
        >
          critical
        </Button>
        <Button
          {...props}
          onClick={(e) => onClick(e, 'discovery')}
          aria-pressed={selected === 'discovery'}
          variant="discovery"
        >
          discovery
        </Button>
      </Toolbar>
    );
  },
};

export const ButtonSizes: Story = {
  parameters: {
    controls: {
      exclude: ['size'],
    },
    docs: {
      description: {
        story:
          "The Buttons default size is set to the `md` value. The Button component has a fixed height for each size but is still dynamic to the width of it's content with a minimum width of 100px.",
      },
    },
  },
  render: ({ children, ...props }) => (
    <Toolbar>
      {buttonSizeOptions.map((size) => (
        <Button {...props} size={size} key={size}>
          {size}
        </Button>
      ))}
    </Toolbar>
  ),
};

export const AsAnchorTag: Story = {
  parameters: {
    controls: {
      include: ['variant', 'size'],
    },
    docs: {
      description: {
        story: 'Button used as an anchor element',
      },
    },
  },
  render: ({ variant, size }) => (
    <Button
      variant={variant}
      size={size}
      as="a"
      href="https://nationalgrid.com"
      target="_blank"
      title="National Grid"
    >
      National Grid
    </Button>
  ),
};
export const AsRouterLink: Story = {
  parameters: {
    controls: {
      include: ['variant', 'size'],
    },
    docs: {
      description: {
        story:
          'Button used as an react-router / NextJS Link component by passing the Link to the as prop',
      },
    },
    reactRouter: reactRouterParameters({
      location: {
        pathParams: { link: 'router-link-1' },
      },
      routing: {
        path: '/buttons/:link',
        useStoryElement: true,
      },
    }),
  },
  decorators: [withRouter],
  render: ({ variant, size }) => (
    <>
      <LocationOutlet />
      <Toolbar>
        <Button
          variant={variant}
          size={size}
          as={Link}
          to="/buttons/router-link-1"
          title="Router Link 1"
        >
          Router Link 1
        </Button>
        <Button
          variant={variant}
          size={size}
          as={Link}
          to="/buttons/router-link-2"
          title="Router Link 2"
        >
          Router Link 2
        </Button>
        <Button
          variant={variant}
          size={size}
          as={Link}
          to="/buttons/router-link-3"
          title="Router Link 3"
        >
          Router Link 3
        </Button>
      </Toolbar>
    </>
  ),
};

export const AsRouterNavLink: Story = {
  parameters: {
    controls: {
      include: ['variant', 'size'],
    },
    docs: {
      description: {
        story: 'Button used as an react-router / NextJS NavLink component',
      },
    },
    reactRouter: reactRouterParameters({
      location: {
        pathParams: { link: 'router-link-1' },
      },
      routing: {
        path: '/buttons/:link',
        useStoryElement: true,
      },
    }),
  },
  decorators: [withRouter],
  render: ({ variant, size }) => (
    <>
      <LocationOutlet />
      <Toolbar>
        <Button
          variant={variant}
          size={size}
          as={NavLink}
          to="/buttons/router-link-1"
          title="Router Link 1"
        >
          Router Nav Link 1
        </Button>
        <Button
          variant={variant}
          size={size}
          as={NavLink}
          to="/buttons/router-link-2"
          title="Router Link 2"
        >
          Router Nav Link 2
        </Button>
        <Button
          variant={variant}
          size={size}
          as={NavLink}
          to="/buttons/router-link-3"
          title="Router Link 3"
        >
          Router Nav Link 3
        </Button>
      </Toolbar>
    </>
  ),
};
