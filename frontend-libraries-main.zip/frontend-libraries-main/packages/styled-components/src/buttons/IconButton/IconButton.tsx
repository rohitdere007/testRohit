import { ButtonHTMLAttributes, FC, ReactNode } from 'react';
import { DefaultTheme } from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { ButtonCustomProps } from '@/buttons/Button';
import { SquareButton } from '@/buttons/SquareButton';
import { AsProps, forwardRefGeneric } from '@/utils/typescript';

type ButtonProps = Omit<
  ButtonHTMLAttributes<HTMLButtonElement>,
  'children' | 'size'
>;

export type IconButtonProps<C extends React.ElementType> = ButtonProps &
  ButtonCustomProps & {
    icon: ReactNode;
    theme?: DefaultTheme;
  } & AsProps<C>;

const IconButtonInner = <C extends React.ElementType>(
  { icon, ...props }: IconButtonProps<C>,
  ref: React.ForwardedRef<HTMLButtonElement>,
) => (
  <SquareButton {...props} theme={props.theme as DefaultTheme} ref={ref}>
    <Icon
      icon={icon}
      size={props.size && ['xs', 'sm'].includes(props.size) ? 'sm' : 'md'}
    />
  </SquareButton>
);

export const IconButton = forwardRefGeneric(IconButtonInner);

(IconButton as FC).displayName = 'IconButton';
