import { mdiAbacus, mdiAccessPointNetworkOff } from '@mdi/js';
import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { Link } from 'react-router-dom';
import {
  reactRouterParameters,
  withRouter,
} from 'storybook-addon-remix-react-router';

import { buttonVariants } from '@/buttons/Button/buttonVariants';
import { Toolbar } from '@/navigation/Toolbar';
import { LocationOutlet } from '@/storybook/LocationOutlet';

import { squareButtonSizes } from '../SquareButton/squareButtonSizes';

import { IconButton } from './IconButton';

type Story = StoryObj<typeof IconButton>;

const buttonVariantOptions = Object.keys(buttonVariants);
const buttonSizeOptions = Object.keys(squareButtonSizes);

export default {
  component: IconButton,
  parameters: {
    docs: {
      controls: {
        exclude: ['onClick', 'children'],
      },
      description: {
        component:
          '<p>The `IconButton` nests an instance of `Icon` from `@mdi/react` within an instance of `SquareButton` which extends the `Button` component</p>' +
          '<p>As the button will only contain an icon, a value for `aria-label` is required</p>' +
          '<p>Rather than taking children as a prop like `SquareButton` it accepts a path prop like the `Icon` component does</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    disabled: false,
    onClick: action('onClick'),
    'aria-pressed': false,
  },
  argTypes: {
    icon: {
      options: ['mdiAbacus', 'mdiAccessPointNetworkOff'],
      mapping: { mdiAbacus, mdiAccessPointNetworkOff },
      control: {
        type: 'select',
      },
      table: {
        type: { summary: 'string' },
      },
      description: 'The @mdi/js path or a icon svg',
    },
    'aria-label': {
      control: { type: 'text' },
      description: 'The label for screen readers',
      table: {
        type: { summary: 'string' },
      },
    },
    variant: {
      options: buttonVariantOptions,
      description: 'The semanic style of the button',
      defaultValue: 'base',
      table: {
        type: {
          summary: buttonVariantOptions.join(' | '),
        },
        defaultValue: { summary: '"base"' },
      },
      control: {
        type: 'select',
      },
    },
    size: {
      options: buttonSizeOptions,
      table: {
        type: {
          summary: buttonSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
      control: {
        type: 'select',
      },
      description: 'The preset size of the button',
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof IconButton>;

export const IconButtonStory: Story = {
  name: 'IconButton',
  parameters: {
    controls: {
      exclude: ['children'],
    },
  },
  args: {
    icon: mdiAbacus,
    children: undefined,
  },
};

export const AsLink: Story = {
  parameters: {
    controls: {
      include: ['size', 'variant'],
    },
  },
  render: ({ variant, size }) => (
    <IconButton
      variant={variant}
      size={size}
      as="a"
      href="https://nationalgrid.com"
      target="_blank"
      title="National Grid"
      icon={mdiAbacus}
    />
  ),
};

export const AsRouterLink: Story = {
  parameters: {
    controls: {
      include: ['size', 'variant'],
    },
    reactRouter: reactRouterParameters({
      location: {
        pathParams: { link: 'router-link-1' },
      },
      routing: {
        path: '/buttons/:link',
        useStoryElement: true,
      },
    }),
  },
  decorators: [withRouter],
  render: ({ variant, size }) => (
    <>
      <LocationOutlet />
      <Toolbar>
        <IconButton
          variant={variant}
          size={size}
          as={Link}
          to="/buttons/router-link-1"
          title="Link 1"
          icon={mdiAbacus}
        />
        <IconButton
          variant={variant}
          size={size}
          as={Link}
          to="/buttons/router-link-2"
          title="Link 2"
          icon={mdiAbacus}
        />
        <IconButton
          variant={variant}
          size={size}
          as={Link}
          to="/buttons/router-link-3"
          title="Link 3"
          icon={mdiAbacus}
        />
      </Toolbar>
    </>
  ),
};
