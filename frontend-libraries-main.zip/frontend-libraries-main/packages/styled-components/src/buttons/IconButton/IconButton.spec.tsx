import { mdiAccessPoint } from '@mdi/js';
import { render, screen } from '@testing-library/react';

import { getColor } from '@/styles/color';
import { darkMode as dm, lightMode } from '@/theme/modes';
import { withTheme } from '@/utils/jest';

import { IconButton } from './IconButton';

const darkMode = dm as unknown as typeof lightMode;
const params = { wrapper: withTheme };

describe('IconButton', () => {
  it('should use the correct color for default text', () => {
    render(<IconButton aria-label="label" icon={mdiAccessPoint} />, params);
    const component = screen.getByLabelText('label');
    expect(component).toHaveStyleRule(
      'color',
      getColor('fg')({ theme: darkMode }),
    );
  });
  it('should use the correct color for primary content', () => {
    render(
      <IconButton variant="primary" aria-label="label" icon={mdiAccessPoint} />,
      params,
    );
    const component = screen.getByLabelText('label');
    expect(component).toHaveStyleRule(
      'color',
      getColor('fgOnDark')({ theme: darkMode }),
    );
  });
  it('should pass the supplied icon to the Icon component', () => {
    render(<IconButton aria-label="label" icon={mdiAccessPoint} />, params);
    const component = screen.getByRole('presentation');
    expect(component.querySelector('path')).toHaveAttribute(
      'd',
      mdiAccessPoint,
    );
  });
});
