import { mdiAbacus, mdiAccessPointNetworkOff } from '@mdi/js';
import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { Link } from 'react-router-dom';
import {
  reactRouterParameters,
  withRouter,
} from 'storybook-addon-remix-react-router';

import { Toolbar } from '@/navigation/Toolbar';
import { LocationOutlet } from '@/storybook/LocationOutlet';

import { PlainIconButton } from './PlainIconButton';

type Story = StoryObj<typeof PlainIconButton>;

export default {
  component: PlainIconButton,
  parameters: {
    docs: {
      controls: {
        exclude: ['children', 'onClick'],
      },
      description: {
        component:
          '<p>The PlainIconButton nests an instance of `Icon` from `@mdi/react` within an instance of `PlainButton`/p>' +
          '<p>As the button will only contain an icon, a value for `aria-label` should be provided if used as a button and not a link</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    disabled: false,
    children: 'Button Text',
    onClick: action('onClick'),
    'aria-pressed': false,
  },
  argTypes: {
    icon: {
      options: ['mdiAbacus', 'mdiAccessPointNetworkOff'],
      mapping: { mdiAbacus, mdiAccessPointNetworkOff },
      control: {
        type: 'select',
      },
      table: {
        type: { summary: 'string' },
      },
      description: 'The @mdi/js path or an icon svg',
    },
    'aria-label': {
      control: { type: 'text' },
      description: 'The label for screen readers',
      table: {
        type: { summary: 'string' },
      },
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PlainIconButton>;

export const PlainIconButtonStory: Story = {
  name: 'PlainIconButton',
  parameters: {
    controls: {
      exclude: ['size', 'variant', 'children'],
    },
  },
  args: {
    icon: mdiAbacus,
    children: undefined,
  },
};

export const AsLink: Story = {
  render: () => (
    <PlainIconButton
      as="a"
      href="https://nationalgrid.com"
      target="_blank"
      title="National Grid"
      icon={mdiAbacus}
    />
  ),
};

export const AsRouterLink: Story = {
  parameters: {
    reactRouter: reactRouterParameters({
      location: {
        pathParams: { link: 'router-link-1' },
      },
      routing: {
        path: '/buttons/:link',
        useStoryElement: true,
      },
    }),
  },
  decorators: [withRouter],
  render: () => (
    <>
      <LocationOutlet />
      <Toolbar>
        <PlainIconButton
          as={Link}
          to="/buttons/router-link-1"
          title="Link 1"
          icon={mdiAbacus}
        />
        <PlainIconButton
          as={Link}
          to="/buttons/router-link-2"
          title="Link 2"
          icon={mdiAbacus}
        />
        <PlainIconButton
          as={Link}
          to="/buttons/router-link-3"
          title="Link 3"
          icon={mdiAbacus}
        />
      </Toolbar>
    </>
  ),
};
