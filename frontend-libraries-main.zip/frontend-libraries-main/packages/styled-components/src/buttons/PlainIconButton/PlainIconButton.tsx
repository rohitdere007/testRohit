import { ButtonHTMLAttributes, FC } from 'react';
import styled from 'styled-components';

import { Icon, IconSize } from '@/atoms/Icon';
import { IsSelectedSelector } from '@/buttons/Button/buttonVariants';
import { getColor } from '@/styles/color';
import { AsProps, forwardRefGeneric } from '@/utils/typescript';

import { PlainButton } from '../PlainButton';

const StyledIconButton = styled(PlainButton).withConfig({
  shouldForwardProp: (p) => p !== 'title',
})<{ title?: string }>`
  background: transparent;
  color: ${getColor('fgSubtle')};

  &:hover {
    color: ${getColor('fg')};
  }

  &:active,
  ${IsSelectedSelector} {
    color: ${getColor('fg')};
  }
`;

type ButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'>;

export type PlainIconButtonProps<C extends React.ElementType> = ButtonProps & {
  icon: string;
  title?: string;
  size?: IconSize;
  inset?: number;
} & AsProps<C>;

export const PlainIconButtonInner = <C extends React.ElementType = 'button'>(
  { icon, inset, ...props }: PlainIconButtonProps<C>,
  ref: React.ForwardedRef<HTMLButtonElement>,
) => (
  <StyledIconButton {...props} ref={ref}>
    <Icon icon={icon} size={props.size || 'md'} inset={inset} />
  </StyledIconButton>
);
export const PlainIconButton = forwardRefGeneric(PlainIconButtonInner);

(PlainIconButton as FC).displayName = 'PlainIconButton';
