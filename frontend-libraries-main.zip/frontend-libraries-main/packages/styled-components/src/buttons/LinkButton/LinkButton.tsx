import styled from 'styled-components';

import { getColor } from '@/styles/color';
import {
  FontWeightProps,
  fontWeight,
  isFontWeightProp,
} from '@/styles/fontWeight';
import { getRadius } from '@/styles/radius';

import { PlainButton } from '../PlainButton';

export const LinkButton = styled(PlainButton).withConfig({
  shouldForwardProp: (p) => !isFontWeightProp(p),
})<FontWeightProps>`
  color: ${getColor('fgInfo')};
  font-size: inherit;
  font-weight: inherit;
  line-height: inherit;
  text-align: start;
  text-decoration: underline;

  &:focus-visible {
    border-radius: ${getRadius(0.5)};
    outline-offset: 2px;
  }
  ${fontWeight};
`;

LinkButton.displayName = 'LinkButton';
