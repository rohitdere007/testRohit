import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { Link } from 'react-router-dom';
import {
  reactRouterParameters,
  withRouter,
} from 'storybook-addon-remix-react-router';

import { Toolbar } from '@/navigation/Toolbar';
import { LocationOutlet } from '@/storybook/LocationOutlet';

import { LinkButton } from './LinkButton';

type Story = StoryObj<typeof LinkButton>;

export default {
  component: LinkButton,
  parameters: {
    docs: {
      controls: {
        exclude: ['onClick'],
      },
      description: {
        component:
          '<p>The `LinkButton` extends the `PlainButton` but is styled as if it were a link</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    children: 'Button Content',
    onClick: action('onClick'),
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the button',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof LinkButton>;

export const LinkButtonStory: Story = {
  parameters: {
    controls: {
      exclude: ['size', 'variant'],
    },
  },
  render: () => (
    <LinkButton
      as="a"
      title="National Grid"
      href="https://nationalgrid.com"
      target="_blank"
    >
      National Grid
    </LinkButton>
  ),
};

export const AsRouterLink: Story = {
  parameters: {
    reactRouter: reactRouterParameters({
      location: {
        pathParams: { link: 'router-link-1' },
      },
      routing: {
        path: '/buttons/:link',
        useStoryElement: true,
      },
    }),
  },
  decorators: [withRouter],
  render: () => (
    <>
      <LocationOutlet />
      <Toolbar>
        <LinkButton as={Link} to="/buttons/router-link-1" aria-label="Link 1">
          Router Link 1
        </LinkButton>
        <LinkButton as={Link} to="/buttons/router-link-2">
          Router Link 2
        </LinkButton>
        <LinkButton as={Link} to="/buttons/router-link-3">
          Router Link 3
        </LinkButton>
      </Toolbar>
    </>
  ),
};
