import { ButtonHTMLAttributes, FC } from 'react';
import { DefaultTheme } from 'styled-components';

import { LoadingSpinner } from '@/info/LoadingSpinner';
import { AsProps, forwardRefGeneric } from '@/utils/typescript';

import { Button, ButtonCustomProps } from '../Button';

type ButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'size'>;

export type LoadingButtonProps<C extends React.ElementType> = ButtonProps &
  ButtonCustomProps & {
    loading: boolean | undefined;
    loadingText?: string;
  } & AsProps<C>;

export const LoadingButtonInner = <C extends React.ElementType>(
  { children, loading, loadingText, disabled, ...props }: LoadingButtonProps<C>,
  ref: React.ForwardedRef<HTMLButtonElement>,
) => (
  <Button
    {...props}
    disabled={loading || disabled}
    autoFocus
    ref={ref}
    theme={props.theme as DefaultTheme}
  >
    {loading ? (
      <>
        <LoadingSpinner size="xs" variant={props.variant} />
        {loadingText || 'Processing...'}
      </>
    ) : (
      children
    )}
  </Button>
);

export const LoadingButton = forwardRefGeneric(LoadingButtonInner);

(LoadingButton as FC).displayName = 'LoadingButton';
