import * as mdiIcons from '@mdi/js';
import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { Link } from 'react-router-dom';
import { withRouter } from 'storybook-addon-remix-react-router';

import { Toolbar } from '@/navigation/Toolbar';

import { Tag, tagVariants } from './Tag';

export default {
  component: Tag,
  parameters: {
    docs: {
      description: {
        component: 'The Tag component is intended for taxonomies & statuses',
      },
    },
    actions: {
      handles: ['onRemove', 'onClick'],
    },
  },
  args: {
    label: '{label-text}',
    variant: undefined,
    as: 'button',
    disabled: false,
    icon: 'mdiMagnifyMinusOutline',
    onRemove: action('onRemove'),
    onClick: action('onClick'),
  },
  argTypes: {
    label: {
      control: { type: 'text' },
      defaultValue: 'Button',
      description: 'The contents of the button',
      table: {
        type: { summary: 'string' },
      },
    },
    icon: {
      control: {
        type: 'select',
      },
      options: Object.keys(mdiIcons),
      mapping: mdiIcons,
      table: {
        type: { summary: 'string' },
      },
      description: 'The @mdi/js path of an icon',
    },
    variant: {
      description: 'The semanic style of the button',
      table: {
        type: {
          summary: Object.keys(tagVariants).join(' | '),
        },
        defaultValue: { summary: '"tag"' },
      },

      control: {
        type: 'select',
      },
      options: Object.keys(tagVariants),
    },
    as: {
      control: {
        type: 'select',
      },
      description: 'Convert button to a different element type',
      options: ['span', 'button', 'a', 'Link'],
      mapping: {
        span: 'span',
        button: 'button',
        a: 'a',
        Link: Link,
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    onRemove: {
      control: false,
      action: 'clicked',
      description: 'Optional remove handler',
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },

  decorators: [withRouter],
  tags: ['autodocs'],
} satisfies Meta<typeof Tag>;

type Story = StoryObj<typeof Tag>;

export const TagStory: Story = {
  name: 'Tag',
  args: {
    'aria-pressed': false,
    onRemove: undefined,
  },
  render: (props) => (
    <Toolbar>
      <Tag {...props} />
      <Tag {...props} variant="critical" />
      <Tag {...props} variant="risk" />
      <Tag {...props} variant="warning" />
      <Tag {...props} variant="success" />
      <Tag {...props} variant="info" />
      <Tag {...props} variant="discovery" />
    </Toolbar>
  ),
};

export const Removable: Story = {
  args: {
    'aria-pressed': false,
  },
  render: (props) => (
    <Toolbar>
      <Tag {...props} />
      <Tag {...props} variant="critical" />
      <Tag {...props} variant="risk" />
      <Tag {...props} variant="warning" />
      <Tag {...props} variant="success" />
      <Tag {...props} variant="info" />
      <Tag {...props} variant="discovery" />
    </Toolbar>
  ),
};
