import { mdiClose } from '@mdi/js';
import { ButtonHTMLAttributes } from 'react';
import styled, { Interpolation, css } from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { TextEllipsis } from '@/atoms/TextEllipsis';
import { PlainButton } from '@/buttons/PlainButton';
import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';
import { getSpace, getSpacing } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';
import { AsProps } from '@/utils/typescript';

import { PlainIconButton } from '../PlainIconButton';

export const tagActiveStyles = (styles: Interpolation<object>) => css`
  &:has(
      :active,
      [aria-checked='true'],
      [aria-current]:not([aria-current='false']),
      [aria-pressed='true'],
      [aria-selected='true']
    ) {
    ${styles}
  }
`;

const tag = css`
  border-color: ${getColor('border')};
  background: ${getColor('bg')};

  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderPressed')};
      background-color: ${getColor('bgPressed')};
    `)}
    &:hover,
      &:focus-visible {
      border-color: ${getColor('borderHover')};
      background-color: ${getColor('bgHover')};
    }
  }
`;

const risk = css`
  border-color: ${getColor('borderRiskSubtle')};
  background: ${getColor('bgRiskSubtlest')};
  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderRiskSubtlePressed')};
      background-color: ${getColor('bgRiskSubtlestPressed')};
    `)}
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderRiskSubtleHover')};
      background-color: ${getColor('bgRiskSubtlestHover')};
    }
  }
`;

const critical = css`
  border-color: ${getColor('borderCriticalSubtle')};
  background: ${getColor('bgCriticalSubtlest')};
  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderCriticalSubtlePressed')};
      background-color: ${getColor('bgCriticalSubtlestPressed')};
    `)}
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderCriticalSubtleHover')};
      background-color: ${getColor('bgCriticalSubtlestHover')};
    }
  }
`;

const discovery = css`
  border-color: ${getColor('borderDiscoverySubtle')};
  background: ${getColor('bgDiscoverySubtlest')};
  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderDiscoverySubtlePressed')};
      background-color: ${getColor('bgDiscoverySubtlestPressed')};
    `)}
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderDiscoverySubtleHover')};
      background-color: ${getColor('bgDiscoverySubtlestHover')};
    }
  }
`;

const info = css`
  border-color: ${getColor('borderInfoSubtle')};
  background: ${getColor('bgInfoSubtlest')};
  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderInfoSubtlePressed')};
      background-color: ${getColor('bgInfoSubtlestPressed')};
    `)}
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderInfoSubtleHover')};
      background-color: ${getColor('bgInfoSubtlestHover')};
    }
  }
`;

const success = css`
  border-color: ${getColor('borderSuccessSubtle')};
  background: ${getColor('bgSuccessSubtlest')};
  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderSuccessSubtlePressed')};
      background-color: ${getColor('bgSuccessSubtlestPressed')};
    `)}
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderSuccessSubtleHover')};
      background-color: ${getColor('bgSuccessSubtlestHover')};
    }
  }
`;

const warning = css`
  border-color: ${getColor('borderWarningSubtle')};
  background: ${getColor('bgWarningSubtlest')};
  &:has(button:not(:disabled):first-child),
  &:has(a) {
    ${tagActiveStyles(css`
      border-color: ${getColor('borderWarningSubtlePressed')};
      background-color: ${getColor('bgWarningSubtlestPressed')};
    `)};
    &:hover,
    &:focus-visible {
      border-color: ${getColor('borderWarningSubtleHover')};
      background-color: ${getColor('bgWarningSubtlestHover')};
    }
  }
`;

export const tagVariants = {
  tag,
  risk,
  critical,
  discovery,
  info,
  success,
  warning,
};

type TagVariants = keyof typeof tagVariants;

export interface TagWrapperProps {
  variant?: TagVariants;
}

const TagWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'variant',
})<TagWrapperProps>`
  display: inline-flex;
  flex-direction: row;
  flex: none;
  flex-grow: 0;
  border-radius: ${getRadius()};
  border: 1px solid;
  padding: ${getSpacing('1 2')};
  gap: ${getSpace()};
  ${getUITextStyles({ size: 'md' })};

  max-width: ${getSize(50)};

  ${PlainButton}:first-child {
    color: ${getColor('fgSubtle')};
    &:focus-visible {
      outline: 0;
    }
    display: flex;
    flex-direction: row;
    align-items: center;
    overflow: hidden;
    gap: ${getSpacing('1')};
  }

  &:has(:first-child:focus-visible) {
    outline: solid 2px ${getColor('borderInfo')};
    outline-offset: 2px;
    border-radius: ${getRadius(0.5)};
  }

  span:first-child {
    cursor: initial;
  }

  a {
    text-decoration: underline;
  }

  ${({ variant }) => tagVariants[variant || 'tag']};
`;

type ButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'>;

type TagProps<C extends React.ElementType> = ButtonProps &
  AsProps<C> &
  TagWrapperProps & {
    label: string;
    icon?: string;
    onRemove?: () => void;
  };

export const Tag = <C extends React.ElementType = 'span'>({
  label,
  onRemove,
  variant,
  icon,
  as = 'span' as C,
  ...props
}: TagProps<C>) => (
  <TagWrapper variant={variant}>
    <PlainButton {...props} as={as}>
      {icon && <Icon icon={icon} size="sm" />}
      <TextEllipsis>{label}</TextEllipsis>
    </PlainButton>
    {onRemove && (
      <PlainIconButton
        icon={mdiClose}
        onClick={onRemove}
        disabled={props.disabled}
        size="sm"
        aria-label={`Remove "${label}"`}
      />
    )}
  </TagWrapper>
);

Tag.displayName = 'Tag';
