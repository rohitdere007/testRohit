import { css } from 'styled-components';

import { getSize } from '@/styles/size';

export const squareButtonSizes = {
  xs: css`
    height: ${getSize(6)};
    width: ${getSize(6)};
    min-width: ${getSize(6)};
  `,
  sm: css`
    height: ${getSize(7)};
    width: ${getSize(7)};
    min-width: ${getSize(7)};
  `,
  md: css`
    height: ${getSize(8)};
    width: ${getSize(8)};
    min-width: ${getSize(8)};
  `,
  lg: css`
    height: ${getSize(9)};
    width: ${getSize(9)};
    min-width: ${getSize(9)};
  `,
  xl: css`
    height: ${getSize(10)};
    width: ${getSize(10)};
    min-width: ${getSize(10)};
  `,
};

export type SquareButtonSize = keyof typeof squareButtonSizes;
