import styled from 'styled-components';

import { Button, ButtonCustomProps } from '../Button';

import { squareButtonSizes } from './squareButtonSizes';

export const SquareButton = styled(Button)<ButtonCustomProps>`
  flex: none;
  padding: 0;
  ${({ size }) => squareButtonSizes[size || 'md']};
`;

SquareButton.displayName = 'SquareButton';
