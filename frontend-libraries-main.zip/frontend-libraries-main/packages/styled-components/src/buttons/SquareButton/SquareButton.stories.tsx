import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { ButtonHTMLAttributes } from 'react';

import { Toolbar } from '@/navigation/Toolbar';

import { ButtonCustomProps, buttonVariants } from '../Button';

import { SquareButton } from './SquareButton';
import { squareButtonSizes } from './squareButtonSizes';

type ButtonType = React.ComponentType<
  ButtonHTMLAttributes<HTMLButtonElement> & ButtonCustomProps
>;

type Story = StoryObj<ButtonType>;

const buttonVariantOptions = Object.keys(buttonVariants);
const buttonSizeOptions = Object.keys(squareButtonSizes);

const meta: Meta<ButtonType> = {
  component: SquareButton,
  parameters: {
    controls: {
      exclude: ['onClick'],
    },
    docs: {
      description: {
        component:
          '<p>The `SquareButton` extends the `Button` component so also accepts the native props expected of the html button component ' +
          'along with some additional props to control the `variant` and `size` of the button<p>' +
          '<p>When using keyboard navigation to tab to the button an outline will be displayed to assist the user</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    disabled: false,
    children: '1',
    onClick: action('onClick'),
    'aria-pressed': false,
  },
  argTypes: {
    variant: {
      options: buttonVariantOptions,
      description: 'The semanic style of the button',
      table: {
        type: {
          summary: buttonVariantOptions.join(' | '),
        },
        defaultValue: { summary: '"base"' },
      },
      control: {
        type: 'select',
      },
    },
    size: {
      options: buttonSizeOptions,
      table: {
        type: {
          summary: buttonSizeOptions.join(' | '),
        },
        defaultValue: { summary: 'md' },
      },
      control: {
        type: 'select',
      },
      description: 'The preset size of the button',
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },

    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    children: {
      control: { type: 'text' },
      defaultValue: 'Button',
      description: 'The contents of the button',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  tags: ['autodocs'],
};

export const SquareButtonStory: Story = {
  name: 'SquareButton',
  parameters: {
    docs: {
      description: {
        story:
          '<p>If you require a square button, the `SquareButton` component is available which extends the styles & functionality of the `Button` component</p>',
      },
    },
  },
  render: (props) => (
    <Toolbar>
      <SquareButton {...props}>1</SquareButton>
      <SquareButton {...props}>2</SquareButton>
      <SquareButton {...props}>3</SquareButton>
    </Toolbar>
  ),
};

export default meta;
