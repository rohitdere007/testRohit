import { render, screen } from '@testing-library/react';

import { getColor } from '@/styles/color';
import { darkMode as dm, lightMode } from '@/theme/modes';
import { withTheme } from '@/utils/jest';

import { SquareButton } from './SquareButton';

const params = { wrapper: withTheme };

const darkMode = dm as unknown as typeof lightMode;

describe('SquareButton', () => {
  describe('Variant', () => {
    it('should use the correct color for default content', () => {
      render(<SquareButton aria-label="label" />, params);
      const component = screen.getByLabelText('label');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fg')({ theme: darkMode }),
      );
    });
    it('should use the correct color for primary content', () => {
      render(<SquareButton aria-label="label" variant="primary" />, params);
      const component = screen.getByLabelText('label');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnDark')({ theme: darkMode }),
      );
    });
    it('should use the correct color for warning content', () => {
      render(<SquareButton aria-label="label" variant="warning" />, params);
      const component = screen.getByLabelText('label');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnLight')({ theme: darkMode }),
      );
    });
    it('should use the correct color for critical content', () => {
      render(<SquareButton aria-label="label" variant="critical" />, params);
      const component = screen.getByLabelText('label');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnDark')({ theme: darkMode }),
      );
    });
    it('should use the correct color for success content', () => {
      render(<SquareButton aria-label="label" variant="success" />, params);
      const component = screen.getByLabelText('label');
      expect(component).toHaveStyleRule(
        'color',
        getColor('fgOnDark')({ theme: darkMode }),
      );
    });
  });
  describe('Size', () => {
    describe('padding & font-size', () => {
      it('xs', () => {
        render(<SquareButton aria-label="label" size="xs" />, params);
        const component = screen.getByLabelText('label');
        expect(component).toHaveStyleRule('padding', '0');
      });
      it('sm', () => {
        render(<SquareButton aria-label="label" size="sm" />, params);
        const component = screen.getByLabelText('label');
        expect(component).toHaveStyleRule('padding', '0');
      });
      it('md', () => {
        render(<SquareButton aria-label="label" size="md" />, params);
        const component = screen.getByLabelText('label');
        expect(component).toHaveStyleRule('padding', '0');
      });
      it('lg', () => {
        render(<SquareButton aria-label="label" size="lg" />, params);
        const component = screen.getByLabelText('label');
        expect(component).toHaveStyleRule('padding', '0');
      });
      it('xl', () => {
        render(<SquareButton aria-label="label" size="xl" />, params);
        const component = screen.getByLabelText('label');
        expect(component).toHaveStyleRule('padding', '0');
      });
    });
  });
  describe('when disabled', () => {
    it("should set the opacity to visually show the SquareButton's state", () => {
      render(<SquareButton aria-label="label" disabled />, params);
      const component = screen.getByLabelText('label');
      expect(component).toBeDisabled();
    });
  });
});
