import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { Link } from 'react-router-dom';
import {
  reactRouterParameters,
  withRouter,
} from 'storybook-addon-remix-react-router';

import { Toolbar } from '@/navigation/Toolbar';
import { LocationOutlet } from '@/storybook/LocationOutlet';

import { PlainButton } from './PlainButton';

type Story = StoryObj<typeof PlainButton>;

export default {
  component: PlainButton,
  parameters: {
    docs: {
      controls: {
        exclude: ['onClick'],
      },
      description: {
        component:
          '<p>The PlainButton is the "base" component for the Button derivatives, it handles the transitions for colours and opacity</p>',
      },
    },
    actions: {
      handles: ['click'],
    },
  },
  args: {
    children: 'Button Content',
    onClick: action('onClick'),
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      defaultValue: 'Button',
      description: 'The contents of the button',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the button is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-pressed': {
      control: { type: 'boolean' },
      description: 'If the button is pressed',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },

    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PlainButton>;

export const PlainButtonStory: Story = {
  name: 'PlainButton',
  parameters: {
    controls: {
      exclude: ['size', 'variant'],
    },
  },
};

export const AsLink: Story = {
  render: () => (
    <PlainButton
      title="National Grid"
      as="a"
      href="https://nationalgrid.com"
      target="_blank"
    >
      National Grid
    </PlainButton>
  ),
};

export const AsRouterLink: Story = {
  parameters: {
    reactRouter: reactRouterParameters({
      location: {
        pathParams: { link: 'router-link-1' },
      },
      routing: {
        path: '/buttons/:link',
        useStoryElement: true,
      },
    }),
  },
  decorators: [withRouter],
  render: () => (
    <>
      <LocationOutlet />
      <Toolbar>
        <PlainButton as={Link} to="/buttons/router-link-1" aria-label="Link 1">
          Router Link 1
        </PlainButton>
        <PlainButton as={Link} to="/buttons/router-link-2">
          Router Link 2
        </PlainButton>
        <PlainButton as={Link} to="/buttons/router-link-3">
          Router Link 3
        </PlainButton>
      </Toolbar>
    </>
  ),
};
