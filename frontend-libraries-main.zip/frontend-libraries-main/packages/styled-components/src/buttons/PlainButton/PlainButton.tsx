import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';

export const PlainButton = styled.button`
  box-sizing: border-box;
  outline: 0;
  border: 0;
  margin: 0;
  padding: 0;
  cursor: pointer;
  text-decoration: none;
  background-color: transparent;

  &:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  &:focus-visible {
    outline: solid 2px ${getColor('borderInfo')};
    outline-offset: 2px;
    border-radius: ${getRadius(2)};
    // Force a new stacking context so this outline renders on top of anything else
    isolation: isolate;
  }
`;

PlainButton.displayName = 'PlainButton';
