import React, { MouseEventHandler } from 'react';
import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getFontWeight } from '@/styles/fontWeight';
import { Radii, getRadius } from '@/styles/radius';
import { Size, getSize } from '@/styles/size';

import { IsSelectedSelector, buttonSizes } from '../Button';
import { PlainButton } from '../PlainButton';

export const segmentedControlSizes = {
  xs: {
    size: 6,
    innerRadius: 0.5,
    outerRadius: 1,
  },
  sm: {
    size: 7,
    innerRadius: 0.5,
    outerRadius: 1,
  },
  md: {
    size: 8,
    innerRadius: 1,
    outerRadius: 1.5,
  },
  lg: {
    size: 9,
    innerRadius: 1,
    outerRadius: 1.5,
  },
} satisfies Record<
  string,
  {
    size: Size;
    innerRadius: Radii;
    outerRadius: Radii;
  }
>;

type SegmentedControlSize = keyof typeof segmentedControlSizes;

type SegmentedControlWrapperProps = {
  size: SegmentedControlSize;
};

const SegmentedControlWrapper = styled.div.withConfig({
  shouldForwardProp: (prop) => !['size'].includes(prop),
})<SegmentedControlWrapperProps>`
  ${({ size: sizeProp }) => {
    const { outerRadius, innerRadius, size } = segmentedControlSizes[sizeProp];

    /**
     * Takes an #rrggbb hex code and an alpha 0-1 and returns
     * an #rrggbbaa hex code
     */
    const addAlpha = (hex: string, alpha: number) => {
      const alphaHex = (alpha * 255).toString(16);

      return hex + alphaHex;
    };

    return css`
      display: inline-flex;
      gap: 1px;
      border-radius: ${getRadius(outerRadius)};

      // Style for if _every_ button is disabled;
      // uses the bg color but with 40% opacity
      background-color: ${(props) =>
        addAlpha(getColor('bgSecondary')(props), 0.4)};
      // If we have a single enabled button, override that
      // translucent background with a solid one
      &:has(:enabled) {
        background-color: ${getColor('bgSecondary')};
      }

      // Hard code the height to match design specs
      height: ${getSize(size)};
      // Add in padding
      padding: ${getSize(0.5)};
      // Ensure the padding doesn't make us taller
      box-sizing: border-box;

      ${SegmentedControlButton} {
        // Inherit button styles for this size
        ${buttonSizes[sizeProp]}
        padding-top: 0;
        padding-bottom: 0;
        height: 100%;
        // but override the height so we fill the container
        border-radius: ${getRadius(innerRadius)};
      }
    `;
  }}
`;

type SegmentedControlProps = {
  size?: SegmentedControlSize;
  children?: React.ReactNode;
};

export const SegmentedControl = ({
  size = 'md',
  children,
}: SegmentedControlProps) => (
  <SegmentedControlWrapper size={size}>{children}</SegmentedControlWrapper>
);

type SegmentedControlButtonProps = {
  active?: boolean;
  children?: React.ReactNode;
  onClick?: MouseEventHandler<HTMLButtonElement>;
  disabled?: boolean;
};

const activeStyles = css`
  color: ${getColor('fg')};
  font-weight: ${getFontWeight('semi-bold')} !important;
  border: 1px solid ${getColor('border')};
  background-color: ${getColor('bgPrimary')} !important;
`;

const SegmentedControlButton = styled(PlainButton).withConfig({
  shouldForwardProp: (prop) => prop !== 'active',
})<SegmentedControlButtonProps>`
  color: ${getColor('fgSubtle')};

  &:not(:disabled) {
    &:hover {
      background-color: ${getColor('bgSecondaryHover')};
    }
    &:active {
      background-color: ${getColor('bgSecondaryPressed')} !important;
    }
  }
  & {
    ${IsSelectedSelector} {
      ${activeStyles}
    }
    ${({ active }) => active && activeStyles}
  }
`;

SegmentedControl.Button = SegmentedControlButton;
