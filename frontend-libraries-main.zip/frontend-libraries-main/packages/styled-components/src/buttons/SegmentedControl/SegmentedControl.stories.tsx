import { Meta, StoryObj } from '@storybook/react';
import { MouseEvent, useState } from 'react';

import { Flex } from '@/atoms/Flex';
import { Toolbar } from '@/navigation/Toolbar';

import { SegmentedControl, segmentedControlSizes } from './SegmentedControl';

const sizeOptions = Object.keys(segmentedControlSizes);

export default {
  component: SegmentedControl,
  parameters: {
    docs: {
      description: {
        component: 'The SegmentedControl component is ...',
      },
    },
  },
  args: {
    children: (
      <>
        <SegmentedControl.Button active>Label</SegmentedControl.Button>
        <SegmentedControl.Button>Label</SegmentedControl.Button>
        <SegmentedControl.Button>Label</SegmentedControl.Button>
        <SegmentedControl.Button>Label</SegmentedControl.Button>
      </>
    ),
  },
  argTypes: {
    children: {
      control: false,
      description: 'The buttons within the SegmentedControl',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    size: {
      options: sizeOptions,
      table: {
        type: {
          summary: sizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
      control: {
        type: 'select',
      },
      description: 'The preset size of the button',
    },
  },
} satisfies Meta<typeof SegmentedControl>;

type Story = StoryObj<typeof SegmentedControl>;

export const Default: Story = {
  name: 'SegmentedControl',
  args: {
    size: 'md',
  },
};

export const SegmentedControlSizes: Story = {
  parameters: {
    controls: {
      exclude: ['size'],
    },
    docs: {
      description: {
        story:
          "The SegmentedControls default size is set to the `md` value. The SegmentedControl has a fixed height for each size but is still dynamic to the width of it's content." +
          '<br>' +
          'This story controls its own state, so is fully interactive.',
      },
    },
  },
  render: () => {
    const [selected, setSelected] = useState<'a' | 'b' | 'c'>('a');

    const handleClick = (
      e: MouseEvent<HTMLButtonElement>,
      value: typeof selected,
    ) => {
      e.preventDefault();
      setSelected(value);
    };

    const sizes = ['xs', 'sm', 'md', 'lg'] as const;

    return (
      <Toolbar>
        <Flex direction="column" gap={2}>
          {sizes.map((size) => (
            <SegmentedControl size={size} key={size}>
              <SegmentedControl.Button
                active={selected === 'a'}
                onClick={(e) => handleClick(e, 'a')}
              >
                Button 1
              </SegmentedControl.Button>
              <SegmentedControl.Button
                active={selected === 'b'}
                onClick={(e) => handleClick(e, 'b')}
              >
                Button 2
              </SegmentedControl.Button>
              <SegmentedControl.Button
                active={selected === 'c'}
                onClick={(e) => handleClick(e, 'c')}
              >
                Button 3
              </SegmentedControl.Button>
            </SegmentedControl>
          ))}
        </Flex>
      </Toolbar>
    );
  },
};

export const ExtraSmall: Story = {
  ...Default,
  args: { size: 'xs' },
};

export const Small: Story = {
  ...Default,
  args: { size: 'sm' },
};

export const Medium: Story = {
  ...Default,
  args: { size: 'md' },
};

export const Large: Story = {
  ...Default,
  args: { size: 'lg' },
};

export const SingleDisabled: Story = {
  ...Default,
  parameters: {
    docs: {
      description: {
        story:
          'You can disable individual buttons by specifying the `disabled` prop on each `SegmentedControl.Button` component',
      },
    },
  },
  args: {
    children: (
      <>
        <SegmentedControl.Button active>Label</SegmentedControl.Button>
        <SegmentedControl.Button>Label</SegmentedControl.Button>
        <SegmentedControl.Button disabled>Label</SegmentedControl.Button>
      </>
    ),
  },
};

export const AllDisabled: Story = {
  ...Default,
  parameters: {
    docs: {
      description: {
        story:
          'If _all_ buttons are disabled, the `SegmentedControl` will appear greyed out.',
      },
    },
  },
  args: {
    children: (
      <>
        <SegmentedControl.Button active disabled>
          Label
        </SegmentedControl.Button>
        <SegmentedControl.Button disabled>Label</SegmentedControl.Button>
        <SegmentedControl.Button disabled>Label</SegmentedControl.Button>
      </>
    ),
  },
};
