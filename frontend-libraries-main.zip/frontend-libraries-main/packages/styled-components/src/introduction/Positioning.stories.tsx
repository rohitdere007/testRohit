import { composeStories } from '@storybook/react';

import * as BoxStories from '../atoms/Box/Box.stories';
import * as FlexStories from '../atoms/Flex/Flex.stories';
import * as GridStories from '../atoms/Grid/Grid.stories';

const meta = {
  ...BoxStories.default,
  title: 'introduction/Positioning',
  tags: [],
};
export default meta;

const { FullNames } = composeStories(BoxStories);
const { Demo } = composeStories(FlexStories);
const { Demo: GridDemo } = composeStories(GridStories);

export const Box = FullNames;
export const Flex = Demo;
export const Grid = GridDemo;
