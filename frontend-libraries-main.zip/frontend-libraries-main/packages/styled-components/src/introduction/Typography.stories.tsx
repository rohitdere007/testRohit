import { composeStories } from '@storybook/react';

import * as BodyTextStories from '../typography/BodyText/BodyText.stories';
import * as DisplayTextStories from '../typography/DisplayText/DisplayText.stories';
import * as HeadingTextStories from '../typography/HeadingText/HeadingText.stories';
import * as TextStories from '../typography/Text/Text.stories';
import * as UITextStories from '../typography/UIText/UIText.stories';

const meta = {
  ...UITextStories.default,
  title: 'introduction/Typography',
  tags: [],
};
export default meta;

const { Demo: UITextStory } = composeStories(UITextStories);
const { Demo: BodyTextStory } = composeStories(BodyTextStories);
const { Demo: HeadingTextStory } = composeStories(HeadingTextStories);
const { Demo: DisplayTextStory } = composeStories(DisplayTextStories);
const { Demo: TextStory } = composeStories(TextStories);

export const UIText = UITextStory;
export const BodyText = BodyTextStory;
export const HeadingText = HeadingTextStory;
export const DisplayText = DisplayTextStory;
export const Text = TextStory;
