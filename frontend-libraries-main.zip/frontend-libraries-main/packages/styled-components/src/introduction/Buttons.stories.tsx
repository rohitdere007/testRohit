import { composeStories } from '@storybook/react';

import * as ButtonStories from '../buttons/Button/Button.stories';
import * as IconButtonStories from '../buttons/IconButton/IconButton.stories';
import * as LinkButtonStories from '../buttons/LinkButton/LinkButton.stories';
import * as PlainButtonStories from '../buttons/PlainButton/PlainButton.stories';
import * as PlainIconButtonStories from '../buttons/PlainIconButton/PlainIconButton.stories';
import * as SquareButtonStories from '../buttons/SquareButton/SquareButton.stories';
import * as TagStories from '../buttons/Tag/Tag.stories';

const meta = {
  ...ButtonStories.default,
  title: 'introduction/Buttons',
  tags: [],
};
export default meta;

const { ButtonChildren } = composeStories(ButtonStories);
const { SquareButtonStory } = composeStories(SquareButtonStories);
const { IconButtonStory } = composeStories(IconButtonStories);
const { PlainButtonStory } = composeStories(PlainButtonStories);
const { PlainIconButtonStory } = composeStories(PlainIconButtonStories);
const { LinkButtonStory } = composeStories(LinkButtonStories);
const { TagStory } = composeStories(TagStories);

export const Button = ButtonChildren;
export const SquareButton = SquareButtonStory;
export const IconButton = IconButtonStory;
export const PlainButton = PlainButtonStory;
export const PlainIconButton = PlainIconButtonStory;
export const LinkButton = LinkButtonStory;
export const Tag = TagStory;
