import { composeStories } from '@storybook/react';

import * as FieldsetStories from '../inputs/Fieldset/Fieldset.stories';
import * as InputStories from '../inputs/Input/Input.stories';
import * as InputCheckboxStories from '../inputs/InputCheckbox/InputCheckbox.stories';
import * as InputRadioStories from '../inputs/InputRadio/InputRadio.stories';
import * as InputRangeStories from '../inputs/InputRange/InputRange.stories';
import * as InputToggleStories from '../inputs/InputToggle/InputToggle.stories';
import * as SelectStories from '../inputs/Select/Select.stories';
import * as SupportTextStories from '../inputs/SupportText/SupportText.stories';
import * as TextAreaStories from '../inputs/TextArea/TextArea.stories';

const meta = {
  ...InputStories.default,
  title: 'introduction/Inputs',
  tags: [],
};
export default meta;

const { InputStory } = composeStories(InputStories);
const { SupportTextStory } = composeStories(SupportTextStories);
const { SelectStory } = composeStories(SelectStories);
const { TextAreaStory } = composeStories(TextAreaStories);
const { InputToggleStory } = composeStories(InputToggleStories);

const { InputRangeStory } = composeStories(InputRangeStories);

const { InputCheckboxStory } = composeStories(InputCheckboxStories);
const { InputRadioStory } = composeStories(InputRadioStories);
const { Radios, Checkboxes } = composeStories(FieldsetStories);

export const Input = InputStory;
export const SupportText = SupportTextStory;
export const Select = SelectStory;
export const TextArea = TextAreaStory;
export const FieldsetRadios = Radios;
export const FieldsetCheckboxes = Checkboxes;
export const InputCheckbox = InputCheckboxStory;
export const InputRadio = InputRadioStory;
export const InputRange = InputRangeStory;
export const InputToggle = InputToggleStory;
