import { ReactNode, useId } from 'react';

import { AccordionItemWrapper } from '../Accordion/AccordionItem';
import { AccordionPanel } from '../Accordion/AccordionPanel';

import {
  AccordionTabbedHeader,
  AccordionTabbedHeaderProps,
} from './AccordionTabbedHeader';

export interface AccordionTabbedItemProps
  extends Omit<AccordionTabbedHeaderProps, 'aria-controls'> {
  children: ReactNode;
}

export const AccordionTabbedItem = ({
  selectedIndex,
  children,
  index,
  ...props
}: AccordionTabbedItemProps) => {
  const id = useId();

  return (
    <AccordionItemWrapper>
      <AccordionTabbedHeader
        {...props}
        aria-controls={id}
        selectedIndex={selectedIndex}
        index={index}
      />
      <AccordionPanel
        role="tabpanel"
        id={id}
        aria-hidden={selectedIndex !== index}
      >
        {children}
      </AccordionPanel>
    </AccordionItemWrapper>
  );
};

AccordionTabbedItem.displayName = 'AccordionTabbedItem';
