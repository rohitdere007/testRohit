import { ReactNode, useState } from 'react';

import { Accordion, AccordionProps } from '../Accordion';

import { AccordionTabbedItem } from './AccordionTabbedItem';

export interface AccordionTabbedContent {
  title: string;
  subtitle?: string;
  content?: ReactNode;
}

export interface AccordionTabbedProps extends AccordionProps {
  selectedIndex?: number;
  contents: AccordionTabbedContent[];
}

export const AccordionTabbed = ({
  contents,
  selectedIndex,
  ...props
}: AccordionTabbedProps) => {
  const [selected, setSelected] = useState(selectedIndex);
  const totalCount = contents.length;
  return (
    <Accordion {...props} role="tablist">
      {contents.map(({ content, ...data }, index) => (
        <AccordionTabbedItem
          {...data}
          key={data.title + index}
          index={index}
          selectedIndex={selected}
          setSelectedIndex={setSelected}
          totalCount={totalCount}
        >
          {content}
        </AccordionTabbedItem>
      ))}
    </Accordion>
  );
};

AccordionTabbed.displayName = 'AccordionTabbed';
