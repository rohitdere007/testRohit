import { MouseEvent, useCallback, useEffect, useRef } from 'react';

import { isNumber } from '@/utils/typescript';

import {
  AccordionHeaderButton,
  AccordionHeaderButtonProps,
} from '../Accordion/AccordionHeaderButton';
import { TabKeyUpProps, getTabKeyUpHandler } from '../TabPanels';

export interface AccordionTabbedHeaderProps
  extends AccordionHeaderButtonProps,
    TabKeyUpProps {
  index: number;
}

export const AccordionTabbedHeader = ({
  selectedIndex,
  setSelectedIndex,
  title,
  subtitle,
  totalCount,
  index,
  'aria-controls': contentId,
  onClick,
}: AccordionTabbedHeaderProps) => {
  const ref = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (isNumber(selectedIndex) && selectedIndex === index) {
      if (ref.current && ref.current !== document?.activeElement) {
        ref.current.focus();
      }
    }
  }, [selectedIndex, index]);

  const onHeaderClick = useCallback(
    (e: MouseEvent<HTMLButtonElement>) => {
      setSelectedIndex(selectedIndex !== index ? index : undefined);
      onClick?.(e);
    },
    [onClick, index, selectedIndex],
  );

  return (
    <AccordionHeaderButton
      aria-controls={contentId}
      title={title}
      subtitle={subtitle}
      role="tab"
      aria-setsize={totalCount}
      aria-posinset={index + 1}
      aria-selected={selectedIndex === index}
      tabIndex={selectedIndex === index ? 0 : -1}
      ref={ref}
      onClick={onHeaderClick}
      onKeyUp={getTabKeyUpHandler({
        selectedIndex,
        setSelectedIndex,
        totalCount,
      })}
    />
  );
};
