import { ReactNode } from 'react';
import styled from 'styled-components';

import { Footer, FooterProps } from '@/atoms/Footer';
import { getBreakpoint } from '@/styles/breakpoint';
import { getSpace } from '@/styles/space';

const FooterContent = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  gap: ${getSpace(2)};
  ${getBreakpoint('sm')} {
    flex-direction: row-reverse;
    width: auto;
  }
`;

export interface ActionsFooterProps extends FooterProps {
  secondary?: ReactNode;
}

export const ActionsFooter = ({ children, secondary }: ActionsFooterProps) => (
  <Footer>
    <FooterContent>{children}</FooterContent>
    <FooterContent>{secondary}</FooterContent>
  </Footer>
);
