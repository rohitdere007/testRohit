import { createContext, useContext } from 'react';

export interface ExpandableProps {
  expanded?: boolean;
  id: string;
}

export interface ExpandableState extends ExpandableProps {
  toggleExpanded?: () => void;
}

export const ExpandableContext = createContext<ExpandableState>({ id: '' });

export const useExpandableContext = () => useContext(ExpandableContext);
