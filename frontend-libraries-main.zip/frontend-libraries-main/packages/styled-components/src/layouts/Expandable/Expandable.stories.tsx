import { Meta, StoryObj } from '@storybook/react';
import React from 'react';

import { Button } from '@/buttons/Button';

import { Section } from '../Section';

import { Expandable } from './Expandable';

export default {
  component: Expandable,
  args: {
    expanded: false,
    id: 'expandable-demo',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Expandable` component expects to be use along with `Expandable.Button` & `Expandable.Body` to create an expandable/collapsible item.',
      },
    },
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the Expandable',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    expanded: {
      control: { type: 'boolean' },
      description: 'If the body is expanded by default',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    id: {
      control: { type: 'text' },
      description: 'The unique id of the expandable element',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
  },
} satisfies Meta<typeof Expandable>;

type Story = StoryObj<typeof Expandable>;

const children =
  'Space, the final frontier. These are the voyages of the Starship' +
  'Enterprise. Its five-year mission: to explore strange new worlds, to' +
  'seek out new life and new civilizations, to boldly go where no man has' +
  'gone before. Many say exploration is part of our destiny, but it’s' +
  'actually our duty to future generations and their quest to ensure the' +
  'survival of the human species.';

export const Demo: Story = {
  render: (props) => (
    <Section>
      <Expandable {...props}>
        <Expandable.Button>
          <Section.Title title="Expandable Demo" />
        </Expandable.Button>
        <Expandable.Body maxHeight={60}>
          <Section.Body>{children}</Section.Body>
          <Section.Footer>
            <Button>Create</Button>
          </Section.Footer>
        </Expandable.Body>
      </Expandable>
    </Section>
  ),
};
