import { PropsWithChildren, useEffect, useMemo, useState } from 'react';

import { ExpandableBody } from './ExpandableBody';
import { ExpandableButton } from './ExpandableButton';
import {
  ExpandableContext,
  ExpandableProps,
  ExpandableState,
} from './ExpandableContext';

export const Expandable = ({
  id,
  children,
  expanded: expandedProp,
}: PropsWithChildren<ExpandableProps>) => {
  const [expanded, setExpanded] = useState(Boolean(expandedProp));
  useEffect(() => {
    setExpanded(!!expandedProp);
  }, [expandedProp]);

  const state = useMemo<ExpandableState>(
    () => ({
      id,
      expanded,
      toggleExpanded: () => setExpanded((prev) => !prev),
    }),
    [id, expanded],
  );
  return (
    <ExpandableContext.Provider value={state}>
      {children}
    </ExpandableContext.Provider>
  );
};

Expandable.Body = ExpandableBody;
Expandable.Button = ExpandableButton;
