import { HTMLAttributes } from 'react';
import styled, { css } from 'styled-components';

import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { MaxHeightProps, isMaxHeightProp, maxHeight } from '@/styles/height';
import { PaddingProps, isPaddingPropName } from '@/styles/padding';

import { useExpandableContext } from './ExpandableContext';

export const ContentWrapper = styled.div`
  box-sizing: content-box;
`;

export type ExpandableWrapperProps = Omit<HTMLAttributes<HTMLElement>, 'id'> &
  MaxHeightProps &
  PaddingProps;

const ExpandableWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => !isMaxHeightProp(p) && !isPaddingPropName(p),
})<ExpandableWrapperProps>`
  max-height: 100%;
  transition: max-height 300ms ease-in-out;
  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }
  overflow: hidden;
  outline: none;
  ${maxHeight}
  box-sizing: border-box;
  flex-shrink: 0;

  ${({ 'aria-hidden': hidden }) =>
    hidden &&
    css`
      max-height: 0;
    `}
`;

export const ExpandableBody = ({
  children,
  ...props
}: ExpandableWrapperProps) => {
  const { id, expanded } = useExpandableContext();
  const delayedExpanded = useDebouncedValue(expanded, !expanded ? 400 : 0);
  return (
    <ExpandableWrapper
      tabIndex={expanded ? 0 : -1}
      aria-hidden={!expanded}
      id={id}
      {...props}
    >
      <ContentWrapper>{delayedExpanded && children}</ContentWrapper>
    </ExpandableWrapper>
  );
};

ExpandableBody.displayName = 'Expandable.Body';
