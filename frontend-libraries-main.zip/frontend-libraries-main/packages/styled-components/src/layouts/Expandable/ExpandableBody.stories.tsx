import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Section } from '../Section';

import { Expandable } from './Expandable';
import { ExpandableBody } from './ExpandableBody';

export default {
  component: ExpandableBody,
  title: 'layouts/Expandable.Body',
  args: {
    maxHeight: '60',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Expandable.Body` is intended to be used within the `Expandable` component which provides context that handles the expanded state of the content. It can receive value for `maxHeight` & `padding`. Providing a `maxHeight` value will improve the transition.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
      description: 'The contents of the Expandable',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    maxHeight: {
      control: { type: 'text' },
      description: 'The max height value of the body when expanded',
      table: {
        type: { summary: 'Size | Property.MaxHeight' },
        defaultValue: { summary: '100%' },
      },
    },
    padding: {
      control: { type: 'text' },
      description: 'The padding value of the body when expanded',
      table: {
        type: { summary: 'Spacing | Property.Padding' },
        defaultValue: { summary: '3' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ExpandableBody>;

type Story = StoryObj<typeof ExpandableBody>;

const children =
  'Space, the final frontier. These are the voyages of the Starship' +
  'Enterprise. Its five-year mission: to explore strange new worlds, to' +
  'seek out new life and new civilizations, to boldly go where no man has' +
  'gone before. Many say exploration is part of our destiny, but it’s' +
  'actually our duty to future generations and their quest to ensure the' +
  'survival of the human species.';

export const Demo: Story = {
  render: (props) => (
    <Section>
      <Expandable id="expandable-demo">
        <Expandable.Button>
          <Section.Title title="Expandable Demo" />
        </Expandable.Button>
        <Expandable.Body {...props}>
          <Section.Body>{children}</Section.Body>
          <Section.Footer>
            <Button variant="primary">Create</Button>
          </Section.Footer>
        </Expandable.Body>
      </Expandable>
    </Section>
  ),
};
