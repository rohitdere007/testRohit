import { mdiChevronDown } from '@mdi/js';
import { ButtonHTMLAttributes, forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { headerStyles } from '@/atoms/Header';
import { Icon } from '@/atoms/Icon';
import { PlainButton } from '@/buttons/PlainButton';
import { getColor } from '@/styles/color';
import { getFontWeight } from '@/styles/fontWeight';
import { PaddingProps, isPaddingPropName, padding } from '@/styles/padding';
import { getSize } from '@/styles/size';

import { useExpandableContext } from './ExpandableContext';

const AccordionChevron = styled.span`
  display: flex;
  align-items: center;
  color: ${getColor('fgSubtle')};
  transition: transform 200ms ease-in-out;
  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }
`;

const ButtonContent = styled.div`
  display: flex;
  align-items: flex-start;
  flex-grow: 1;
  justify-content: center;
  flex-direction: column;
  color: ${getColor('fg')};
  font-weight: ${getFontWeight('semi-bold')};
`;

const HeaderButton = styled(PlainButton).withConfig({
  shouldForwardProp: (p) => !isPaddingPropName(p),
})<PaddingProps>`
  ${headerStyles};
  ${padding};
  min-height: ${getSize(14)};
  width: 100%;
  box-sizing: border-box;

  &:focus-visible {
    outline-offset: ${getSize(-1)};
  }

  &:hover {
    background: ${getColor('bg')};
  }

  ${({ 'aria-expanded': expanded }) =>
    expanded &&
    css`
      ${AccordionChevron} {
        transform: rotate(180deg);
      }
    `};
`;

export const ExpandableButton = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> & PaddingProps
>(({ children, ...props }, ref) => {
  const { id, expanded, toggleExpanded } = useExpandableContext();
  return (
    <HeaderButton
      {...props}
      ref={ref}
      aria-controls={id}
      aria-expanded={expanded}
      onClick={(e) => {
        toggleExpanded?.();
        props.onClick?.(e);
      }}
      type="button"
    >
      <ButtonContent>{children}</ButtonContent>
      <AccordionChevron>
        <Icon icon={mdiChevronDown} size="lg" />
      </AccordionChevron>
    </HeaderButton>
  );
});

ExpandableButton.displayName = 'Expandable.Button';
