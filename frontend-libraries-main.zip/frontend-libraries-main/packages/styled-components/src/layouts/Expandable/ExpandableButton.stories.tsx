import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Section } from '../Section';

import { Expandable } from './Expandable';
import { ExpandableButton } from './ExpandableButton';

export default {
  component: ExpandableButton,
  title: 'layouts/Expandable.Button',
  args: {
    padding: '3',
  },
  parameters: {
    docs: {
      description: {
        component:
          "The `Expandable.Button` is intended to be used within the `Expandable` component which provides context that handles the expanded state of the button & body. `Expandable.Button` component takes an optional `padding` prop so then you can match up the button's padding to the content",
      },
    },
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the Expandable',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    padding: {
      control: { type: 'text' },
      description: 'The padding value of the body when expanded',
      table: {
        type: { summary: 'Spacing | Property.Padding' },
        defaultValue: { summary: '0' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ExpandableButton>;

type Story = StoryObj<typeof ExpandableButton>;

const children =
  'Space, the final frontier. These are the voyages of the Starship' +
  'Enterprise. Its five-year mission: to explore strange new worlds, to' +
  'seek out new life and new civilizations, to boldly go where no man has' +
  'gone before. Many say exploration is part of our destiny, but it’s' +
  'actually our duty to future generations and their quest to ensure the' +
  'survival of the human species.';

export const Demo: Story = {
  render: (props) => (
    <Section>
      <Expandable id="expandable-demo">
        <Expandable.Button {...props}>
          <Section.Title title="Expandable Demo" />
        </Expandable.Button>
        <Expandable.Body>
          <Section.Body>{children}</Section.Body>
          <Section.Footer>
            <Button variant="primary">Create</Button>
          </Section.Footer>
        </Expandable.Body>
      </Expandable>
    </Section>
  ),
};
