import { ReactNode } from 'react';

import { Flex } from '@/atoms/Flex';
import { UIText } from '@/typography/UIText';

export interface SectionTitleProps {
  title: string;
  as?: string;
  icon?: ReactNode;
  subtitle?: string;
}

export const SectionTitle = ({
  icon,
  title,
  subtitle,
  as,
}: SectionTitleProps) => (
  <Flex gap={2} direction="row" align="center" justify="center">
    {icon}
    <Flex direction="column">
      <UIText size="lg" weight="semi-bold" color="fg" as={as}>
        {title}
      </UIText>
      {subtitle && <UIText color="fgSubtle">{subtitle}</UIText>}
    </Flex>
  </Flex>
);

SectionTitle.displayName = 'Section.Title';
