import { PropsWithChildren } from 'react';
import { KnownTarget } from 'styled-components/dist/types';

import { Panel, PanelProps } from '@/atoms/Panel';
import { PaddingProps } from '@/styles/padding';

import { SectionBody } from './SectionBody';
import { SectionFooter } from './SectionFooter';
import { SectionHeader } from './SectionHeader';
import { SectionTitle } from './SectionTitle';

export interface SectionProps
  extends Omit<PanelProps, keyof PaddingProps>,
    PropsWithChildren {
  as?: KnownTarget;
}

export const Section = ({
  m,
  margin,
  children,
  as = 'section',
  ...props
}: SectionProps) => (
  <Panel as={as} {...props}>
    {children}
  </Panel>
);

Section.Title = SectionTitle;
Section.Header = SectionHeader;
Section.Body = SectionBody;
Section.Footer = SectionFooter;
