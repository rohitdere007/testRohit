import styled from 'styled-components';

import { Header } from '@/atoms/Header';

export const SectionHeader = styled(Header)``;

SectionHeader.displayName = 'Section.Header';
