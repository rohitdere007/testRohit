import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getSpace } from '@/styles/space';

export interface SectionBodyProps {
  border?: boolean;
}

export const SectionBody = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'border',
})<SectionBodyProps>`
  padding: ${getSpace(3)};
  ${({ border = true }) =>
    border &&
    css`
      border-top: 1px solid ${getColor('border')};
    `}
`;

SectionBody.displayName = 'Section.Body';
