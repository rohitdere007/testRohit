import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Expandable } from '../Expandable';

import { Section } from '.';

export default {
  component: Section,
  args: {
    width: '100%',
    margin: '3',
  },
  parameters: {
    docs: {
      description: {
        component: 'Section',
      },
    },
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The contents of the Section',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
} satisfies Meta<typeof Section>;

type Story = StoryObj<typeof Section>;

const children =
  'Space, the final frontier. These are the voyages of the Starship' +
  'Enterprise. Its five-year mission: to explore strange new worlds, to' +
  'seek out new life and new civilizations, to boldly go where no man has' +
  'gone before. Many say exploration is part of our destiny, but it’s' +
  'actually our duty to future generations and their quest to ensure the' +
  'survival of the human species.';

export const Demo: Story = {
  render: (props) => (
    <Section {...props}>
      <Section.Header>
        <Section.Title title="Section Title" subtitle="Section Subtitle" />
      </Section.Header>
      <Section.Body>{children}</Section.Body>
      <Section.Footer>
        <Button variant="primary">Create</Button>
      </Section.Footer>
    </Section>
  ),
};

export const ExpandableSection: Story = {
  name: 'Expandable',
  render: (props) => (
    <Section {...props}>
      <Expandable id="expandable-demo">
        <Expandable.Button>
          <Section.Title title="Expandable Demo" />
        </Expandable.Button>
        <Expandable.Body maxHeight={60}>
          <Section.Body>{children}</Section.Body>
          <Section.Footer>
            <Button variant="primary">Create</Button>
          </Section.Footer>
        </Expandable.Body>
      </Expandable>
    </Section>
  ),
};
