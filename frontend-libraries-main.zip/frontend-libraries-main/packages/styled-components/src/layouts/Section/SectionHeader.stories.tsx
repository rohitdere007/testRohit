import { mdiFileEdit, mdiMenu } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { Flex } from '@/atoms/Flex';
import { IconButton } from '@/buttons/IconButton';

import { Section } from './Section';
import { SectionHeader } from './SectionHeader';
import { SectionTitle } from './SectionTitle';

export default {
  component: SectionHeader,
  title: 'layouts/Section.Header',
  args: {
    children: undefined,
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Section.Header` component is a header element expecting two children separated with space between. Most commonly it would be used within a `Section` and have a `Section.Title` instance as a child.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof SectionHeader>;

type Story = StoryObj<typeof SectionHeader>;

export const Demo: Story = {
  render: (props) => (
    <Section>
      <SectionHeader {...props}>
        <SectionTitle title="Hello World" subtitle="Section Subtitle" />
      </SectionHeader>
    </Section>
  ),
};

export const WithButtons: Story = {
  render: (props) => (
    <Section>
      <SectionHeader {...props}>
        <SectionTitle title="Hello World" subtitle="Section Subtitle" />
        <Flex gap="2">
          <IconButton icon={mdiMenu} />
          <IconButton icon={mdiFileEdit} />
        </Flex>
      </SectionHeader>
    </Section>
  ),
};
