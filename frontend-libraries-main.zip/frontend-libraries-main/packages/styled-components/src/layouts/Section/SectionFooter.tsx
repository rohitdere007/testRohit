import { ActionsFooter, ActionsFooterProps } from '../ActionsFooter';

export const SectionFooter = (props: ActionsFooterProps) => (
  <ActionsFooter {...props} />
);

SectionFooter.displayName = 'Section.Footer';
