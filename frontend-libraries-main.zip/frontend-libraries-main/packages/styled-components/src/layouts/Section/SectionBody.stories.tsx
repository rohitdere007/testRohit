import { Meta, StoryObj } from '@storybook/react';

import { Section } from './Section';
import { SectionBody } from './SectionBody';
import { SectionHeader } from './SectionHeader';
import { SectionTitle } from './SectionTitle';

export default {
  component: SectionBody,
  title: 'layouts/Section.Body',
  args: {
    children:
      'Space, the final frontier. These are the voyages of the Starship' +
      'Enterprise. Its five-year mission: to explore strange new worlds, to' +
      'seek out new life and new civilizations, to boldly go where no man has' +
      'gone before. Many say exploration is part of our destiny, but it’s' +
      'actually our duty to future generations and their quest to ensure the' +
      'survival of the human species.',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Section.Body` provides padding uniform to the `Section.Header` & `Section.Footer` between. Most commonly it would be used within a `Section`.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
    border: {
      control: {
        type: 'boolean',
      },
      description: 'If the body has a border-top',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'true' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof SectionBody>;

type Story = StoryObj<typeof SectionBody>;

export const Demo: Story = {
  render: (props) => (
    <Section>
      <SectionHeader>
        <SectionTitle title="Hello World" subtitle="Section Subtitle" />
      </SectionHeader>
      <SectionBody {...props} />
    </Section>
  ),
};

export const Border: Story = {
  args: {
    border: false,
  },
  render: (props) => (
    <Section>
      <SectionHeader>
        <SectionTitle title="Hello World" subtitle="Section Subtitle" />
      </SectionHeader>
      <SectionBody {...props} />
    </Section>
  ),
};
