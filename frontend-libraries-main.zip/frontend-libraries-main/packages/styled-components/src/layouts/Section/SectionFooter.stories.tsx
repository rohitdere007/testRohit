import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';

import { Section } from './Section';
import { SectionBody } from './SectionBody';
import { SectionFooter } from './SectionFooter';

export default {
  component: SectionFooter,
  title: 'layouts/Section.Footer',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Section.Footer` provides uniform props with other `Footer` components. It requires a `children` value and takes optional `secondary` prop. The direction of the buttons passed will be vertical on a mobile with the primary actions above and then horizontal on desktop with primary actions on the right.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
      description: 'The main footer buttons',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    secondary: {
      control: undefined,
      description: 'The secondary footer buttons',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof SectionFooter>;

type Story = StoryObj<typeof SectionFooter>;

const children =
  'Space, the final frontier. These are the voyages of the Starship' +
  'Enterprise. Its five-year mission: to explore strange new worlds, to' +
  'seek out new life and new civilizations, to boldly go where no man has' +
  'gone before. Many say exploration is part of our destiny, but it’s' +
  'actually our duty to future generations and their quest to ensure the' +
  'survival of the human species.';

export const Demo: Story = {
  render: (props) => (
    <Section>
      <SectionBody border={false}>{children}</SectionBody>
      <SectionFooter {...props}>
        <Button variant="primary">Confirm</Button>
        <Button>Cancel</Button>
      </SectionFooter>
    </Section>
  ),
};

export const WithSecondary: Story = {
  render: (props) => (
    <Section>
      <SectionBody border={false}>{children}</SectionBody>
      <SectionFooter
        {...props}
        secondary={<Button variant="critical">Delete</Button>}
      >
        <Button variant="primary">Confirm</Button>
        <Button>Cancel</Button>
      </SectionFooter>
    </Section>
  ),
};
