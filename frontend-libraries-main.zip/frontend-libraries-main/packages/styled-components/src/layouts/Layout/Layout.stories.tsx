import { mdiAccountCircle, mdiTrendingUp, mdiViewDashboard } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';
import React from 'react';

import { MoonIcon } from '@/atoms/Icon';
import { Spacer } from '@/atoms/Spacer';
import { IconButton } from '@/buttons/IconButton';
import { AppBar } from '@/navigation/AppBar';
import { MainNav } from '@/navigation/MainNav';
import { NationalGridLogo } from '@/svgs';

import { Page } from '../Page/Page';
import { Section } from '../Section';

import { Layout } from './Layout';

export default {
  component: Layout,
  args: {},
  argTypes: {
    children: {
      control: false,
      description: 'The children of the main layout.',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Layout` component is intended to be the wrapper of the application layout.',
      },
    },
  },
} satisfies Meta<typeof Layout>;

type Story = StoryObj<typeof Layout>;

export const Demo: Story = {
  render: () => {
    const sidebar = (
      <MainNav logo={<NationalGridLogo />} inline>
        <MainNav.Item
          as="a"
          icon={mdiViewDashboard}
          title="Dashboard"
          href="/"
        />
        <MainNav.Item
          icon={mdiTrendingUp}
          title="Reports"
          as="a"
          href="/reports"
        />
        <Spacer />
        <MainNav.Item
          icon={mdiAccountCircle}
          title="Profile"
          as="a"
          href="/profile"
        />
      </MainNav>
    );

    const appbar = (
      <AppBar>
        <IconButton
          size="xl"
          ghost
          icon={<MoonIcon />}
          aria-label="Change Theme"
        />
      </AppBar>
    );

    return (
      <Layout>
        <MainNav.Provider open>
          {appbar}
          <Layout.Columns>
            {sidebar}
            <Layout.Main>
              <Page.Header>
                <Page.Title title="Page Title" subtitle="Page Subtitle" />
              </Page.Header>
              <Page.Body>
                <Section aria-label="Section Title">
                  <Section.Header>
                    <Section.Title title="Section Title" as="h2" />
                  </Section.Header>
                  <Section.Body>Main Content</Section.Body>
                </Section>
              </Page.Body>
            </Layout.Main>
          </Layout.Columns>
        </MainNav.Provider>
      </Layout>
    );
  },
};
