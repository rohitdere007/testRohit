import { Meta, StoryObj } from '@storybook/react';

import { Page } from '../Page';
import { Section } from '../Section';

import { Layout } from './Layout';
import { LayoutMain } from './LayoutMain';

export default {
  component: LayoutMain,
  title: 'layouts/Layout.Main',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Layout.Main` provides the page\'s "main" element and is intended to be used as a child of `Layout`',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof LayoutMain>;

type Story = StoryObj<typeof LayoutMain>;

export const Demo: Story = {
  render: (props) => (
    <Layout>
      <Layout.Main {...props}>
        <Page.Body>
          <Section aria-label="Section One">
            <Section.Header>
              <Section.Title title="Section One" />
            </Section.Header>
            <Section.Body>Main Content</Section.Body>
          </Section>
          <Section aria-label="Section Two">
            <Section.Header>
              <Section.Title title="Section Two" />
            </Section.Header>
            <Section.Body>Main Content</Section.Body>
          </Section>
        </Page.Body>
      </Layout.Main>
    </Layout>
  ),
};
