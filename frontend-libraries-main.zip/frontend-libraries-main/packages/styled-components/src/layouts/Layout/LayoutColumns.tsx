import styled from 'styled-components';

export const LayoutColumns = styled.div`
  display: flex;
  flex-direction: row;
  height: 100%;
  overflow: hidden;
`;

LayoutColumns.displayName = 'Layout.Columns';
