import { Property } from 'csstype';
import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';

export interface LayoutMainProps {
  overflow?: Property.Overflow;
  overflowY?: Property.OverflowY;
  overflowX?: Property.OverflowX;
}

export const LayoutMain = styled.main.withConfig({
  displayName: 'Layout.Main',
  shouldForwardProp: (p) => !p.startsWith('overflow'),
})<LayoutMainProps>`
  display: flex;
  flex-direction: column;
  background: ${getColor('bg')};
  overflow: auto;
  width: 100%;
  height: 100%;
  flex-grow: 1;

  ${({ overflow }) =>
    overflow &&
    css`
      overflow: ${overflow};
    `};
  ${({ overflowY }) =>
    overflowY &&
    css`
      overflow-y: ${overflowY};
    `};
  ${({ overflowX }) =>
    overflowX &&
    css`
      overflow-x: ${overflowX};
    `};
`;
