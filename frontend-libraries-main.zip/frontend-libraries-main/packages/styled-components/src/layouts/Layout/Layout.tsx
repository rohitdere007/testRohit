import { HTMLAttributes } from 'react';
import { styled } from 'styled-components';

import { LayoutColumns } from './LayoutColumns';
import { LayoutMain } from './LayoutMain';

const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 100dvh;
  overflow: hidden;
  width: 100%;
`;

export const Layout = ({ ...props }: HTMLAttributes<HTMLElement>) => (
  <MainContainer {...props} />
);

Layout.Columns = LayoutColumns;
Layout.Main = LayoutMain;
