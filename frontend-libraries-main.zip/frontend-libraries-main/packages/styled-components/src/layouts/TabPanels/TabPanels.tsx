import {
  Dispatch,
  ReactNode,
  SetStateAction,
  useEffect,
  useRef,
  useState,
} from 'react';
import styled, { css } from 'styled-components';

import { TabNav, TabNavProps } from '@/navigation/TabNav';
import {
  TabNavButton,
  TabNavButtonProps,
} from '@/navigation/TabNav/TabNavButton';
import { getBodyTextStyles } from '@/styles/typography';

const config = {
  shouldForwardProp: (p: string) => p !== 'vertical',
};
const TabPanelsWrapper = styled.div.withConfig(config)<{ vertical?: boolean }>`
  display: flex;
  flex-direction: ${({ vertical }) => (vertical ? 'row' : 'column')};
`;

const TabList = styled(TabNav).attrs({
  role: 'tablist',
})``;

const TabPanel = styled.div.attrs({
  role: 'tabpanel',
})`
  display: flex;
  flex-direction: column;
  ${getBodyTextStyles()};

  ${({ 'aria-hidden': hidden }) =>
    hidden &&
    css`
      display: none;
    `}
`;

const PanelGroup = styled.div`
  display: flex;
`;
export interface TabContent {
  id: string;
  title: ReactNode;
  content: ReactNode;
}

type Props = TabNavButtonProps & TabNavProps;
export interface TabPanelsProps extends Props {
  contents: TabContent[];
  selectedIndex?: number;
}

export interface TabKeyUpProps {
  selectedIndex: number | undefined;
  setSelectedIndex: Dispatch<SetStateAction<number | undefined>>;
  totalCount: number;
}

export const getTabKeyUpHandler =
  ({ selectedIndex, setSelectedIndex, totalCount }: TabKeyUpProps) =>
  (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (
      [
        'ArrowRight',
        'ArrowLeft',
        'ArrowUp',
        'ArrowDown',
        'PageUp',
        'PageDown',
      ].includes(e.code)
    ) {
      e.preventDefault();
    }

    switch (e.code) {
      case 'PageDown':
      case 'ArrowDown':
      case 'ArrowRight':
        if (selectedIndex === undefined) {
          break;
        }
        if (selectedIndex < totalCount - 1) {
          setSelectedIndex(selectedIndex + 1);
        } else {
          setSelectedIndex(0);
        }
        break;
      case 'PageUp':
      case 'ArrowUp':
      case 'ArrowLeft':
        if (selectedIndex === undefined) {
          break;
        }
        if (selectedIndex > 0) {
          setSelectedIndex(selectedIndex - 1);
        } else {
          setSelectedIndex(totalCount - 1);
        }
        break;

      default:
        break;
    }
  };

export const TabPanels = ({
  contents,
  selectedIndex = 0,
  fluid,
  vertical,
  ...props
}: TabPanelsProps) => {
  const [selected, setSelected] = useState<number | undefined>(selectedIndex);
  const tabsRef = useRef<(HTMLButtonElement | null)[]>([]);
  useEffect(() => {
    const selectedTab =
      selected !== undefined ? tabsRef.current[selected] : undefined;
    if (selectedTab && selectedTab !== document.activeElement) {
      selectedTab.focus();
    }
  }, [selected]);

  const onKeyUp = getTabKeyUpHandler({
    selectedIndex: selected,
    setSelectedIndex: setSelected,
    totalCount: contents.length,
  });

  return (
    <TabPanelsWrapper vertical={vertical}>
      <TabList fluid={fluid} vertical={vertical}>
        {contents.map(({ title, id }, index) => (
          <TabNavButton
            {...props}
            role="tab"
            key={id}
            ref={(el) => (tabsRef.current[index] = el)}
            aria-controls={id}
            aria-selected={selected === index}
            tabIndex={selected === index ? 0 : -1}
            onClick={() => setSelected(index)}
            onKeyUp={onKeyUp}
          >
            {title}
          </TabNavButton>
        ))}
      </TabList>
      <PanelGroup>
        {contents.map(({ content, id }, index) => (
          <TabPanel id={id} key={id} aria-hidden={selected !== index}>
            {content}
          </TabPanel>
        ))}
      </PanelGroup>
    </TabPanelsWrapper>
  );
};

TabPanels.displayName = 'TabPanels';
