import { mdiFileEdit, mdiMenu } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { IconButton } from '@/buttons/IconButton';

import { Page } from './Page';
import { PageActions } from './PageActions';

export default {
  component: PageActions,
  title: 'layouts/Page.Actions',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Page.Actions` provides uniform spacing between buttons passed as children. It is intended to be used as a child of `Page.Header`',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PageActions>;

type Story = StoryObj<typeof PageActions>;

export const Demo: Story = {
  render: (props) => (
    <Page.Header>
      <Page.Actions {...props}>
        <IconButton icon={mdiMenu} />
        <IconButton icon={mdiFileEdit} />
      </Page.Actions>
    </Page.Header>
  ),
};
