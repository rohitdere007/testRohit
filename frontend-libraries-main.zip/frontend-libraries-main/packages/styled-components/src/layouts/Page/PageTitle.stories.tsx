import { mdiChevronLeft, mdiDotsVertical } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { IconButton } from '@/buttons/IconButton';
import {
  BreadcrumbCurrent,
  BreadcrumbItem,
  Breadcrumbs,
} from '@/navigation/Breadcrumbs';

import { PageActions } from './PageActions';
import { PageHeader } from './PageHeader';
import { PageTitle } from './PageTitle';

type Story = StoryObj<typeof PageTitle>;

export default {
  component: PageTitle,
  title: 'layouts/Page.Title',
  parameters: {
    controls: {},
    docs: {
      description: {
        component:
          'The `Page.Title` provides uniform props with other `Title` components. It requires a `title` value and takes optional `subtitle` & `icon` props. As this is expected to be the page title, the `as` prop value defaults to `h1`.',
      },
    },
  },
  args: {
    title: 'Title',
    subtitle: 'This is additional information regarding the page',
  },
  argTypes: {
    title: {
      control: { type: 'text' },
      description: 'The page title text',
      table: {
        type: { summary: 'string' },
      },
    },
    subtitle: {
      control: { type: 'text' },
      description: 'Optional additional description text',
      table: {
        type: { summary: 'string' },
      },
    },
    as: {
      control: {
        type: 'select',
      },
      description: 'the html element the title text should be contained within',
      defaultValue: 'span',
      table: {
        type: {
          summary: ['span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].join(
            ' | ',
          ),
        },
        defaultValue: { summary: 'h1' },
      },
      options: ['span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
    },
    breadcrumbs: {
      control: false,
      description: 'Optional breadcrumbs ReactNode',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    icon: {
      control: false,
      description:
        'Optional icon that can be used to add a back button ReactNode',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PageTitle>;

export const Demo: Story = {
  render: (props) => (
    <PageHeader>
      <PageTitle {...props} />
    </PageHeader>
  ),
};

export const WithBreadcrumbs: Story = {
  render: (props) => (
    <PageHeader>
      <PageTitle
        {...props}
        breadcrumbs={
          <Breadcrumbs {...props}>
            <BreadcrumbItem as="a" href="/" title="Link Title">
              Home
            </BreadcrumbItem>
            <BreadcrumbCurrent>Current Page</BreadcrumbCurrent>
          </Breadcrumbs>
        }
      />
      <PageActions>
        <IconButton icon={mdiDotsVertical} />
      </PageActions>
    </PageHeader>
  ),
};

export const WithBackButton: Story = {
  render: (props) => (
    <PageHeader>
      <PageTitle
        {...props}
        icon={<IconButton icon={mdiChevronLeft} onClick={() => {}} ghost />}
      />
      <PageActions>
        <IconButton icon={mdiDotsVertical} />
      </PageActions>
    </PageHeader>
  ),
};
