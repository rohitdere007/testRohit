import { PropsWithChildren } from 'react';

import { PageActions } from './PageActions';
import { PageBody } from './PageBody';
import { PageHeader } from './PageHeader';
import { PageScrollable } from './PageScrollable';
import { PageTitle } from './PageTitle';

export const Page = ({ children }: PropsWithChildren) => <>{children}</>;

Page.Header = PageHeader;
Page.Title = PageTitle;
Page.Actions = PageActions;
Page.Body = PageBody;
Page.Scrollable = PageScrollable;
