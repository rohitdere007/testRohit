import { styled } from 'styled-components';

import { Header } from '@/atoms/Header';
import { getColor } from '@/styles/color';

export interface PageHeaderProps {
  raised?: boolean;
}

export const PageHeader = styled(Header).withConfig({
  shouldForwardProp: (p) => p !== 'raised',
})<PageHeaderProps>`
  background: ${({ raised, theme }) =>
    getColor(raised ? 'bgPrimary' : 'bg')({ theme })};
  align-items: flex-start;
  border-bottom: 1px solid ${getColor('border')};
`;

PageHeader.displayName = 'Page.Header';
