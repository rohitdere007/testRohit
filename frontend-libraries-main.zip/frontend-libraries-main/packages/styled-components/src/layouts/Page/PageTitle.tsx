import { ReactNode } from 'react';
import styled from 'styled-components';
import { KnownTarget } from 'styled-components/dist/types';

import { getSpace } from '@/styles/space';
import { HeadingText } from '@/typography/HeadingText';
import { UIText } from '@/typography/UIText';

const TitleContainer = styled.div``;

export interface PageTitleProps {
  title: ReactNode;
  subtitle?: ReactNode;
  icon?: ReactNode;
  breadcrumbs?: ReactNode;
  as?: KnownTarget;
}

const HeaderStart = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  gap: ${getSpace(1.5)};
  flex-grow: 1;
`;

const PageHeading = styled.div`
  display: flex;
  flex-direction: column-reverse;
  gap: ${getSpace(1.5)};
  justify-content: flex-end;
`;

export const PageTitle = ({
  title,
  subtitle,
  icon,
  breadcrumbs,
  as,
}: PageTitleProps) => (
  <HeaderStart>
    {icon}
    <PageHeading>
      <TitleContainer>
        {typeof title === 'string' ? (
          <HeadingText as={as || 'h1'} weight="semi-bold" size="md">
            {title}
          </HeadingText>
        ) : (
          title
        )}
        {subtitle && <UIText color="fgSubtle">{subtitle}</UIText>}
      </TitleContainer>
      {breadcrumbs}
    </PageHeading>
  </HeaderStart>
);

PageTitle.displayName = 'Page.Title';
