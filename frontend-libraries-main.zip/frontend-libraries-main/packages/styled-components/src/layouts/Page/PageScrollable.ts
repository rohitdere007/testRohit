import { styled } from 'styled-components';

import { getSpace } from '@/styles/space';

export interface PageHeaderProps {
  raised?: boolean;
}

export const PageScrollable = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${getSpace(3)};
  overflow: auto;
`;

PageScrollable.displayName = 'Page.Scrollable';
