import { Meta, StoryObj } from '@storybook/react';

import { Section } from '../Section';

import { Page } from './Page';
import { PageBody } from './PageBody';

export default {
  component: PageBody,
  title: 'layouts/Page.Body',
  args: {},
  parameters: {
    docs: {
      description: {
        component:
          'The `Page.Body` provides uniform margin and gap between children elements. It is intended to be used as a child of `Page`',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PageBody>;

type Story = StoryObj<typeof PageBody>;

export const Demo: Story = {
  render: (props) => (
    <Page>
      <Page.Body {...props}>
        <Section aria-label="Section One">
          <Section.Header>
            <Section.Title title="Section One" />
          </Section.Header>
          <Section.Body>Main Content</Section.Body>
        </Section>
        <Section aria-label="Section Two">
          <Section.Header>
            <Section.Title title="Section Two" />
          </Section.Header>
          <Section.Body>Main Content</Section.Body>
        </Section>
      </Page.Body>
    </Page>
  ),
};
