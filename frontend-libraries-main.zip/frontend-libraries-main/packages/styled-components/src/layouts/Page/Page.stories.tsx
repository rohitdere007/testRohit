import { mdiFileEdit, mdiMenu } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { IconButton } from '@/buttons/IconButton';

import { Page } from './Page';
import { PageActions } from './PageActions';
import { PageHeader } from './PageHeader';
import { PageTitle } from './PageTitle';

export default {
  component: PageHeader,
  title: 'layouts/Page',
  args: {
    children: undefined,
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Page` component is intended to be the wrapper of the page specific content. It provides a `Page.Header` & `Page.Title` to use within it.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
} satisfies Meta<typeof PageHeader>;

type Story = StoryObj<typeof PageHeader>;

export const Demo: Story = {
  render: (props) => (
    <Page>
      <PageHeader {...props}>
        <PageTitle title="Hello World" subtitle="Page Subtitle" />
        <PageActions>
          <IconButton icon={mdiMenu} />
          <IconButton icon={mdiFileEdit} />
        </PageActions>
      </PageHeader>
    </Page>
  ),
};
