import { render, screen } from '@testing-library/react';

import { withTheme } from '@/utils/jest';

import { PageTitle } from './PageTitle';

describe('PageTitle', () => {
  it('should render the passed title in a H1 element', () => {
    const title = 'foo';
    render(<PageTitle title={title} />, { wrapper: withTheme });

    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(title);
  });
});
