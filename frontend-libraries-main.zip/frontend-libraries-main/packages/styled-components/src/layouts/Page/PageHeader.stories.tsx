import { mdiFileEdit, mdiMenu } from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { IconButton } from '@/buttons/IconButton';

import { Page } from './Page';
import { PageActions } from './PageActions';
import { PageHeader } from './PageHeader';
import { PageTitle } from './PageTitle';

export default {
  component: PageHeader,
  title: 'layouts/Page.Header',
  args: {
    children: undefined,
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Page.Header` component is a header element expecting one or two children separated with space between. Most commonly it would be used within a `Page` and have a `Page.Title` instance and optional `Page.Actions` as a children.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PageHeader>;

type Story = StoryObj<typeof PageHeader>;

export const Demo: Story = {
  render: (props) => (
    <Page>
      <PageHeader {...props}>
        <PageTitle title="Hello World" subtitle="Page Subtitle" />
      </PageHeader>
    </Page>
  ),
};

export const WithButtons: Story = {
  render: (props) => (
    <Page>
      <PageHeader {...props}>
        <PageTitle title="Hello World" subtitle="Page Subtitle" />
        <PageActions>
          <IconButton icon={mdiMenu} />
          <IconButton icon={mdiFileEdit} />
        </PageActions>
      </PageHeader>
    </Page>
  ),
};
