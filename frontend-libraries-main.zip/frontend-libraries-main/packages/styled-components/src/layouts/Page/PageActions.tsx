import { styled } from 'styled-components';

import { getSpace } from '@/styles/space';

export const PageActions = styled.div`
  display: flex;
  gap: ${getSpace(2)};
  justify-content: flex-end;
  align-items: center;
  flex-shrink: 0;
  flex-grow: 1;
  max-width: 100%;
`;

PageActions.displayName = 'Page.Actions';
