import { mdiChevronDown } from '@mdi/js';
import { ButtonHTMLAttributes, forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { PlainButton } from '@/buttons/PlainButton';
import { getColor } from '@/styles/color';
import { getFontWeight } from '@/styles/fontWeight';
import { getSize } from '@/styles/size';
import { getSpace } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';

const shouldForwardProp = (propName: string) =>
  !['chevronStart', 'flush'].includes(propName);

const AccordionChevron = styled.span`
  display: flex;
  align-items: center;
  color: ${getColor('fgSubtle')};

  transition: transform 200ms ease-in-out;
  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }
`;
export const AccordionTitle = styled.div`
  ${getBodyTextStyles({
    color: 'fg',
    weight: 'semi-bold',
  })}
`;

export const AccordionSubtitle = styled.div`
  color: ${getColor('fgSubtle')};
  font-weight: ${getFontWeight('regular')};
`;

const AccordionHeaderContent = styled.div`
  display: flex;
  align-items: flex-start;
  flex-grow: 1;
  justify-content: center;
  flex-direction: column;
  text-align: start;
  padding: ${getSpace(2)} 0;
`;

export const AccordionButton = styled(PlainButton).withConfig({
  shouldForwardProp,
})`
  display: flex;
  align-items: center;
  min-height: ${getSize(12)};
  height: auto;
  gap: ${getSpace(2)};
  flex-grow: 1;

  &:focus-visible {
    outline-offset: 0px;
  }

  ${({ 'aria-selected': selected, 'aria-expanded': expanded }) =>
    (selected || expanded) &&
    css`
      ${AccordionChevron} {
        transform: rotate(180deg);
      }
    `};
`;

export interface AccordionHeaderButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement> {
  title: string;
  subtitle?: string;
  'aria-controls': string;
}

export const AccordionHeaderButton = forwardRef<
  HTMLButtonElement,
  AccordionHeaderButtonProps
>(({ title, subtitle, 'aria-controls': contentId, ...props }, ref) => (
  <AccordionButton {...props} ref={ref} aria-controls={contentId} type="button">
    <AccordionHeaderContent>
      <AccordionTitle>{title}</AccordionTitle>
      {subtitle && <AccordionSubtitle>{subtitle}</AccordionSubtitle>}
    </AccordionHeaderContent>
    <AccordionChevron>
      <Icon icon={mdiChevronDown} size="lg" />
    </AccordionChevron>
  </AccordionButton>
));

AccordionHeaderButton.displayName = 'Accordion.HeaderButton';
