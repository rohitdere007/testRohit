import { forwardRef, useId } from 'react';
import styled from 'styled-components';

import { getColor } from '@/styles/color';

import { AccordionHeader, AccordionHeaderProps } from './AccordionHeader';
import { AccordionPanel, AccordionPanelProps } from './AccordionPanel';

export const AccordionItemWrapper = styled.div`
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  border-top: 1px solid ${getColor('border')};
  &:last-of-type {
    border-bottom: 1px solid ${getColor('border')};
  }
`;

export type AccordionItemProps = Omit<AccordionHeaderProps, 'aria-controls'> &
  Pick<AccordionPanelProps, 'maxHeight'> & {
    open: boolean;
    id: string;
  };

export const AccordionItem = forwardRef<HTMLDivElement, AccordionItemProps>(
  ({ maxHeight, children, open, title, ...props }, ref) => {
    const backupId = useId();
    const id = props.id || backupId;
    return (
      <AccordionItemWrapper ref={ref}>
        <AccordionHeader
          {...props}
          title={title}
          aria-controls={id}
          aria-expanded={open}
        />
        <AccordionPanel
          id={id}
          maxHeight={maxHeight}
          tabIndex={open ? 0 : -1}
          aria-hidden={!open}
          aria-label={title}
        >
          {children}
        </AccordionPanel>
      </AccordionItemWrapper>
    );
  },
);

AccordionItem.displayName = 'Accordion.Item';
