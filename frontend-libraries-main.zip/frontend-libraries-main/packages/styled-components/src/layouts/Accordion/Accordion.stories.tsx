import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Accordion, accordionSizes } from './Accordion';
import { AccordionItem } from './AccordionItem';

export default {
  component: Accordion,
  args: {
    chevronStart: false,
    flush: false,
    size: 'sm',
  },
  argTypes: {
    size: {
      options: Object.keys(accordionSizes),
      control: {
        type: 'select',
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Accordion (Expandable/Collapsable)',
      },
    },
  },
} satisfies Meta<typeof Accordion>;

type Story = StoryObj<typeof Accordion>;

const content = [
  {
    id: 'lorem',
    title: 'Lorem Ipsum',
    content: `
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris lorem
      orci, semper eu justo sit amet, aliquet euismod neque. Suspendisse
      hendrerit ligula ut sapien semper, sit amet vestibulum nulla imperdiet.
      Suspendisse eget hendrerit tortor. Cras pulvinar magna a lacus finibus,
      et aliquam est consequat. Nunc sem eros, convallis et laoreet eu,
      maximus non eros. Ut euismod pellentesque suscipit. Mauris et leo nec
      urna mollis accumsan vel et arcu. Morbi imperdiet, elit ac egestas
      suscipit, dolor sapien venenatis mi, nec tempus leo urna vel velit.
    `,
  },
  {
    id: 'cat',
    title: 'Cat Ipsum',
    content: `
      Chase ball of string eat plants, meow, and throw up because I ate
      plants going to catch the red dot today going to catch the red dot
      today. I could pee on this if I had the energy. Chew iPad power cord
      steal the warm chair right after you get up for purr for no reason
      leave hair everywhere, decide to want nothing to do with my owner
      today
    `,
  },
  {
    id: 'space',
    title: 'Space Ipsum',
    content: `
      Space, the final frontier. These are the voyages of the Starship
      Enterprise. Its five-year mission: to explore strange new worlds, to
      seek out new life and new civilizations, to boldly go where no man has
      gone before. Many say exploration is part of our destiny, but it’s
      actually our duty to future generations and their quest to ensure the
      survival of the human species.
    `,
  },
];

export const Demo: Story = {
  render: (props) => {
    const [selected, setSelected] = useState(0);
    return (
      <Accordion {...props}>
        {content.map((item, index) => (
          <AccordionItem
            key={item.id}
            id={item.id}
            title={item.title}
            open={selected === index}
            onClick={() => setSelected(index)}
          >
            {item.content}
          </AccordionItem>
        ))}
      </Accordion>
    );
  },
};
