import { ReactNode, forwardRef } from 'react';

import { Flex } from '@/atoms/Flex';

import {
  AccordionHeaderButton,
  AccordionHeaderButtonProps,
} from './AccordionHeaderButton';

export interface AccordionHeaderProps extends AccordionHeaderButtonProps {
  actions?: ReactNode;
  className?: string;
}

export const AccordionHeader = forwardRef<
  HTMLButtonElement,
  AccordionHeaderProps
>(({ actions, className, ...props }, ref) => (
  <Flex align="center" justify="space-between" className={className}>
    <AccordionHeaderButton {...props} ref={ref} />
    {actions}
  </Flex>
));

AccordionHeader.displayName = 'Accordion.Header';
