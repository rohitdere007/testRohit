import { HTMLAttributes } from 'react';
import styled from 'styled-components';

import { FontSize, getFontSize } from '@/styles/fontSize';
import { getSpacing } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';

import {
  AccordionButton,
  AccordionSubtitle,
  AccordionTitle,
} from './AccordionHeaderButton';
import { AccordionItem } from './AccordionItem';
import { AccordionPanelContent } from './AccordionPanel';

export const accordionSizes = {
  sm: '48px',
  md: '52px',
  lg: '76px',
};

type AccordionSize = keyof typeof accordionSizes;

const titleSizes: Record<AccordionSize, FontSize> = {
  sm: 'md',
  md: 'lg',
  lg: 'xl',
};

const subtitleSizes: Record<AccordionSize, FontSize> = {
  sm: 'xs',
  md: 'sm',
  lg: 'md',
};

export interface AccordionProps extends HTMLAttributes<HTMLElement> {
  size?: AccordionSize;
  chevronStart?: boolean;
  flush?: boolean;
}

const AccordionWrapper = styled.div.withConfig({
  shouldForwardProp: (propName) =>
    !['size', 'flush', 'chevronStart'].includes(propName),
})<AccordionProps>`
  box-sizing: content-box;
  width: 100%;

  ${AccordionTitle} {
    font-size: ${({ size }) => getFontSize(titleSizes[size || 'md'])};
  }

  ${AccordionSubtitle} {
    font-size: ${({ size }) => getFontSize(subtitleSizes[size || 'md'])};
  }

  ${AccordionButton} {
    padding: ${({ flush }) => getSpacing(flush ? '0' : '0 3')};
    flex-direction: ${({ chevronStart }) =>
      chevronStart ? 'row-reverse' : 'row'};
    min-height: ${({ size = 'sm' }) => accordionSizes[size]};
  }

  ${AccordionPanelContent} {
    ${getBodyTextStyles({ color: 'fg' })};
    padding: ${({ flush }) => getSpacing(flush ? '2 0 4' : '2 3 4')};
  }
`;

export const Accordion = (props: AccordionProps) => (
  <AccordionWrapper {...props} />
);

Accordion.displayName = 'Accordion';

Accordion.Item = AccordionItem;
