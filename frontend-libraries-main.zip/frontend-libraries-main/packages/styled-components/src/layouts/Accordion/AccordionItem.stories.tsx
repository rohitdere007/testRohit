import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';

import { AccordionItem } from './AccordionItem';

import { Accordion } from '.';

export default {
  component: AccordionItem,
  title: 'layouts/Accordion.Item',
  args: {
    id: 'foo',
    title: 'Lorum Ipsum',
    subtitle: 'Lorem ipsum dolor sit amet',
    children:
      'Space, the final frontier. These are the voyages of the Starship' +
      'Enterprise. Its five-year mission: to explore strange new worlds, to' +
      'seek out new life and new civilizations, to boldly go where no man has' +
      'gone before. Many say exploration is part of our destiny, but it’s' +
      'actually our duty to future generations and their quest to ensure the' +
      'survival of the human species.',
    onClick: action('onClick'),
    open: true,
  },
  argTypes: {
    id: {
      description:
        'The unique id that contextually binds the button to the content area',
      table: {
        type: { summary: 'string' },
      },
      control: {
        type: 'text',
      },
    },
    open: {
      control: { type: 'boolean' },
      defaultValue: false,
      description: 'if the item is currently expanded',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'false' },
      },
    },
    title: {
      description: 'The title of the accordion item',
      table: {
        type: { summary: 'string' },
      },
      control: {
        type: 'text',
      },
    },
    subtitle: {
      description: 'The subtitle of the accordion item',
      table: {
        type: { summary: 'string' },
      },
      control: {
        type: 'text',
      },
    },
    children: {
      description: 'The contents of the accordion item',
      table: {
        type: { summary: 'ReactNode' },
      },
      control: {
        type: 'text',
      },
    },
    onClick: {
      action: 'clicked',
      description: 'The native button click handler',
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Accordion.Item (Expandable/Collapsable)',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof AccordionItem>;

type Story = StoryObj<typeof AccordionItem>;

export const Demo: Story = {
  render: (props) => {
    const [args, updateArgs] = useArgs();
    return (
      <Accordion>
        <AccordionItem
          {...props}
          onClick={(v) => {
            props.onClick?.(v);
            updateArgs({ open: !args.open });
          }}
        />
      </Accordion>
    );
  },
};
