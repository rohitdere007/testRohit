import { HTMLAttributes } from 'react';
import styled, { css } from 'styled-components';

import { Size, getSize } from '@/styles/size';
import { getBodyTextStyles } from '@/styles/typography';

export const AccordionPanelContent = styled.div`
  box-sizing: border-box;
`;

export interface AccordionPanelProps extends HTMLAttributes<HTMLElement> {
  maxHeight?: Size;
}

const AccordionPanelWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'maxHeight',
})<AccordionPanelProps>`
  max-height: 0;
  box-sizing: border-box;
  transition: max-height 300ms ease-in-out;
  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }
  overflow: hidden;
  outline: none;
  ${getBodyTextStyles()};

  ${({ 'aria-hidden': hidden, maxHeight }) =>
    !hidden &&
    css`
      max-height: ${getSize(maxHeight || 125)};
    `}
`;

export const AccordionPanel = ({ children, ...props }: AccordionPanelProps) => (
  <AccordionPanelWrapper {...props}>
    <AccordionPanelContent>{children}</AccordionPanelContent>
  </AccordionPanelWrapper>
);
