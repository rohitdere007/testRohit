import { mdiAlertCircleOutline, mdiCheckCircleOutline } from '@mdi/js';
import { PropsWithChildren } from 'react';
import styled from 'styled-components';

import { Icon, IconWrapper } from '@/atoms/Icon';
import { Color, getColor } from '@/styles/color';
import { getSize } from '@/styles/size';
import { getSpace } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

const variantColor: Record<string, Color> = {
  success: 'fgSuccess',
  critical: 'fgCritical',
};

type SupportTextVariant = keyof typeof variantColor;

type SupportTextProps = {
  variant?: SupportTextVariant;
  size?: 'sm' | 'md';
};

export const SupportTextWrapper = styled.span.withConfig({
  shouldForwardProp: (p) => !['variant', 'size'].includes(p),
})<SupportTextProps>`
  display: flex;
  flex-direction: row;
  align-items: center;
  height: ${getSize(4)};
  ${({ size = 'sm' }) => getUITextStyles({ size })};
  gap: ${getSpace(0.5)};
  color: ${({ variant, theme }) =>
    getColor(variant ? (variantColor[variant] as Color) : 'fg')({ theme })};

  ${IconWrapper} {
    color: ${({ variant, theme }) =>
      getColor(variant ? (variantColor[variant] as Color) : 'fg')({
        theme,
      })};
  }
`;

const Text = styled.span``;

const getVariantIcon = (variant: SupportTextVariant | undefined) => {
  switch (variant) {
    case 'critical':
      return mdiAlertCircleOutline;
    case 'success':
      return mdiCheckCircleOutline;
    default:
      return;
  }
};

export const SupportText = ({
  variant = 'critical',
  children,
}: PropsWithChildren<SupportTextProps>) => {
  const path = getVariantIcon(variant);
  return (
    <SupportTextWrapper variant={variant}>
      {path && <Icon icon={path} size="md" />}
      <Text aria-live="polite">{children}</Text>
    </SupportTextWrapper>
  );
};

SupportText.displayName = 'SupportText';
