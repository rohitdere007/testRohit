import { Meta, StoryObj } from '@storybook/react';

import { Input } from '../Input';

import { SupportText } from './SupportText';

export default {
  component: SupportText,
  args: {
    children: '{support-text}',
    variant: 'critical',
  },
  argTypes: {
    variant: {
      control: {
        type: 'select',
      },
      options: [undefined, 'success', 'critical'],
    },
    size: {
      control: {
        type: 'select',
      },
      options: ['sm', 'md'],
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'Support text component intended for form validation feedback',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof SupportText>;

type Story = StoryObj<typeof SupportText>;

export const SupportTextStory: Story = {
  name: 'SupportText',
  parameters: {
    docs: {
      name: 'SupportText',
      description: {
        story:
          '<p>When providing a validation message, any ReactNode can be passed to the message prop to be displayed below the input. ' +
          'For the majority of cases, there is a `SupportText` component which takes a `variant` prop for different use cases</p>',
      },
    },

    controls: {
      include: ['children', 'variant'],
    },
  },
  args: {
    variant: 'critical',
  },
  argTypes: {
    variant: {
      control: {
        type: 'select',
      },
      options: [undefined, 'success', 'critical'],
    },
  },
  render(props) {
    return (
      <Input
        required
        invalid
        type="email"
        label="Email"
        message={
          <SupportText {...props}>Some sort of validation error</SupportText>
        }
      />
    );
  },
};
