import { InputHTMLAttributes, ReactNode, forwardRef } from 'react';

import { BaseInput } from './BaseInput';
import { InputBorder } from './InputBorder';
import { InputContent } from './InputContent';
import { InputSharedStylesProps } from './inputSharedStyles';

export type InputElementProps = InputSharedStylesProps &
  Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'children' | 'prefix' | 'suffix' | 'size' | 'width'
  > & {
    leading?: ReactNode;
    trailing?: ReactNode;
    suffix?: ReactNode;
    prefix?: ReactNode;
  };

export const InputElement = forwardRef<HTMLInputElement, InputElementProps>(
  (
    {
      prefix,
      suffix,
      leading,
      trailing,
      size = 'md',
      css: cssProp,
      label,
      width,
      error,
      ...inputProps
    },
    ref,
  ) => {
    const { required, readOnly, invalid, disabled } = inputProps;
    const borderProps = { readOnly, required, invalid, disabled, width, error };
    return (
      <InputBorder css={cssProp} size={size} {...borderProps}>
        {(leading || prefix) && (
          <InputContent prefix={!!prefix}>
            {leading}
            {prefix}
          </InputContent>
        )}
        <BaseInput
          ref={ref}
          aria-label={label}
          {...inputProps}
          readOnly={readOnly}
        />
        {(trailing || suffix) && (
          <InputContent suffix={!!suffix}>
            {suffix}
            {trailing}
          </InputContent>
        )}
      </InputBorder>
    );
  },
);

InputElement.displayName = 'InputElement';
