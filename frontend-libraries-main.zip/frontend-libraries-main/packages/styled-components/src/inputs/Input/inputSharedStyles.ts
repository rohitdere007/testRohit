import { Property } from 'csstype';
import { ReactNode } from 'react';
import { css } from 'styled-components';

import { getColor } from '@/styles/color';

import {
  InputSize,
  InputSizeProps,
  inputSizeStyles,
  inputWidthStyles,
  isInputSizeProp,
} from './inputSizes';

export interface InputSharedStylesProps extends InputSizeProps {
  'aria-invalid'?: boolean;
  'aria-disabled'?: boolean;
  invalid?: boolean;
  disabled?: boolean;
  error?: ReactNode;
  align?: Property.TextAlign;
  label: string;
  readOnly?: boolean;
  size?: InputSize;
}

export const isInputSharedProp = (propName: string) =>
  isInputSizeProp(propName) ||
  ['error', 'invalid', 'align', 'label', 'size'].includes(propName);

export const inputSharedStyles = css<Omit<InputSharedStylesProps, 'label'>>`
  transition: opacity 200ms ease-in-out;
  text-align: ${({ align = 'left' }) => align};

  ${({ invalid, 'aria-invalid': aria, error }) =>
    (aria || invalid || error) &&
    css`
      border-color: ${getColor('borderCritical')};
    `}

  ${({ disabled, 'aria-disabled': aria }) =>
    (disabled || aria) &&
    css`
      cursor: not-allowed;
      border-color: ${getColor('border')};
      opacity: 0.4;
    `};

  ${({ readOnly }) =>
    readOnly
      ? css`
          pointer-events: none;
          border-color: transparent;
          color: ${getColor('fgPlaceholder')};
          background-color: transparent;
        `
      : css`
          &:focus-within {
            border-color: ${getColor('borderInfo')};
            outline: 1px solid ${getColor('borderInfo')};
          }
        `};

  ${inputWidthStyles};

  ${({ size }) => inputSizeStyles[size || 'md']};
`;
