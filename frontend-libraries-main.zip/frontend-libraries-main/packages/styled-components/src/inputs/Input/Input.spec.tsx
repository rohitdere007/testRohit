import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { withTheme } from '@/utils/jest';

import { Input } from './Input';

const params = { wrapper: withTheme };

describe('Input', () => {
  it('links label and input', () => {
    render(<Input label="a field" defaultValue="b" />, params);

    expect(screen.getByLabelText<HTMLInputElement>('a field').type).toBe(
      'text',
    );
  });

  it('links label and input uniquely', () => {
    render(
      <>
        <Input label="field-a" defaultValue="a" />
        <Input label="field-b" defaultValue="b" />
      </>,
      params,
    );

    expect(screen.getByLabelText('field-a')).toHaveValue('a');
    expect(screen.getByLabelText('field-b')).toHaveValue('b');
  });

  it('accepts an explicit id', () => {
    render(<Input id="a-field" defaultValue="a" label="a field" />, params);
    expect(screen.getByDisplayValue('a')).toHaveAttribute('id', 'a-field');
  });

  it('calls onChange event as if it were a normal input element', async () => {
    const user = userEvent.setup();
    let res = 'foo';

    render(
      <Input
        label="field-a"
        onChange={(event) => {
          res = event.target.value;
        }}
        defaultValue=""
      />,
      params,
    );

    await user.click(screen.getByDisplayValue(''));
    await user.keyboard('biz');

    expect(res).toBe('biz');
  });

  it('appends leading', () => {
    render(<Input label="field-a" leading="after" defaultValue="" />, params);

    expect(screen.getByText('after')).toBeInTheDocument();
  });

  it('prepends trailing', () => {
    render(<Input label="field-a" trailing="before" defaultValue="" />, params);

    expect(screen.getByText('before')).toBeInTheDocument();
  });

  it('appends suffix', () => {
    render(<Input label="field-a" suffix="after" defaultValue="" />, params);

    expect(screen.getByText('after')).toBeInTheDocument();
  });

  it('prepends prefix', () => {
    render(<Input label="field-a" prefix="before" defaultValue="" />, params);

    expect(screen.getByText('before')).toBeInTheDocument();
  });

  it('appends message', () => {
    render(
      <Input
        label="field-a"
        defaultValue="a"
        message={<span>appended content</span>}
      />,
      params,
    );

    expect(screen.getByText('appended content')).toBeInTheDocument();
  });
});
