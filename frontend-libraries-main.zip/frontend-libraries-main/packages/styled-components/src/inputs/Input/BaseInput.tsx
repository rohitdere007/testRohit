import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getUITextStyles } from '@/styles/typography';

export const BaseInput = styled.input`
  width: 100%;
  min-width: 3ch;
  height: 100%;
  padding: 0;
  margin: 0;
  border: none;
  background: ${getColor('bgPrimary')};

  outline: none;

  ${getUITextStyles({ color: 'fg', weight: 'regular' })};

  &::placeholder {
    ${getUITextStyles({
      color: 'fgPlaceholder',
      weight: 'regular',
    })};
  }

  &:disabled {
    pointer-events: none;
  }
`;
