import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getSpace } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

import { BaseInput } from './BaseInput';
import {
  InputSharedStylesProps,
  inputSharedStyles,
  isInputSharedProp,
} from './inputSharedStyles';

export const InputBorder = styled.div.withConfig({
  shouldForwardProp: (propName) =>
    !isInputSharedProp(propName) &&
    !['disabled', 'readOnly'].includes(propName),
})<Omit<InputSharedStylesProps, 'label'>>`
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${getSpace()};
  align-self: stretch;
  background: ${getColor('bgPrimary')};
  border: 1px solid ${getColor('border')};
  ${getUITextStyles({ size: 'md' })};

  ${inputSharedStyles};

  ${({ readOnly }) =>
    readOnly &&
    css`
      ${BaseInput} {
        color: ${getColor('fgPlaceholder')};
        background-color: transparent;
      }
    `}
`;
