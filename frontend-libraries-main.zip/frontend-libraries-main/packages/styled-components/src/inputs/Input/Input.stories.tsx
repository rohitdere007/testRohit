import { mdiClose, mdiEye, mdiEyeOff, mdiMagnify } from '@mdi/js';
import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Icon } from '@/atoms/Icon';

import { PlainIconButton } from '../../buttons/PlainIconButton';
import FieldMeta from '../Field/Field.stories';

import { Input } from './Input';

type Story = StoryObj<typeof Input>;

const typeOptions = [
  'date',
  'datetime-local',
  'email',
  'month',
  'number',
  'password',
  'search',
  'tel',
  'text',
  'time',
  'url',
  'week',
];

export default {
  component: Input,
  parameters: {
    layout: 'flex',
    actions: {
      handles: ['focus', 'blur', 'change'],
    },
  },
  args: {
    disabled: false,
    placeholder: '',
    readOnly: false,
    required: false,
    invalid: false,
    hideLabel: false,
    defaultValue: '',
    label: 'Input Label',
    type: 'text',
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    placeholder: {
      control: { type: 'text' },
      description: 'a placeholder value for the input',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '' },
      },
    },
    type: {
      control: {
        type: 'select',
      },
      description: "html input's native type attribute",
      defaultValue: 'text',
      table: {
        type: {
          summary: typeOptions.join(' | '),
        },
        defaultValue: { summary: '"text"' },
      },

      options: typeOptions,
    },
    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    prefix: {
      control: { type: 'text' },
      description: 'A prefix applied to the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    suffix: {
      control: { type: 'text' },
      description: 'A suffix applied to the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    leading: {
      control: { type: 'text' },
      description: 'A prefix applied to the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    trailing: {
      control: { type: 'text' },
      description: 'A suffix applied to the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    ...FieldMeta.argTypes,
  },
} satisfies Meta<typeof Input>;

export const InputStory: Story = {
  name: 'Input',
  args: {
    type: 'email',
    label: 'Email',
    placeholder: 'Placeholder...',
  },
};

export const ReadOnly: Story = {
  args: {
    readOnly: true,
    value: 'Some value',
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    value: 'Some value',
  },
};

export const RequiredWithMessage: Story = {
  args: {
    value: 'Some value',
  },
  render(props) {
    return (
      <Input
        {...props}
        required
        invalid
        type="email"
        label="Email"
        error="Some sort of validation error"
      />
    );
  },
};

export const LeadingTrailing: Story = {
  args: {
    defaultValue: 'value',
  },
  render: (props) => (
    <Input
      {...props}
      type="text"
      leading={<Icon icon={mdiMagnify} />}
      trailing={
        <PlainIconButton
          aria-label="Clear Value"
          onClick={() => {}}
          icon={mdiClose}
        />
      }
    />
  ),
};

export const Password: Story = {
  args: {
    defaultValue: 'secret-password',
  },
  render: (props) => {
    const [show, setShow] = useState(false);

    return (
      <Input
        {...props}
        type={show ? 'text' : 'password'}
        trailing={
          <PlainIconButton
            aria-label={show ? 'Hide Password' : 'Show Password'}
            onClick={() => setShow((s) => !s)}
            icon={show ? mdiEyeOff : mdiEye}
          />
        }
      />
    );
  },
};

export const PrefixSuffix: Story = {
  args: {
    prefix: '$',
    suffix: '.00',
  },
};

export const HiddenLabel: Story = {
  args: {
    hideLabel: true,
  },
};
