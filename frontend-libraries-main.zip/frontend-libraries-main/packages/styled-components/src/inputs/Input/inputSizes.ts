import { RuleSet, css } from 'styled-components';

import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';
import { getSpace, getSpacing } from '@/styles/space';

export type InputSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface InputHeightProps {
  size?: InputSize;
}

export const inputSizeStyles: Record<InputSize, RuleSet<object>> = {
  xs: css`
    min-height: ${getSize(6)};
    padding: 0 ${getSpace()};
    border-radius: ${getRadius()};
  `,
  sm: css`
    min-height: ${getSize(7)};
    padding: ${getSpacing('1.5 1')};
    border-radius: ${getRadius()};
  `,
  md: css`
    min-height: ${getSize(8)};
    padding: ${getSpace(1.5)};
    border-radius: ${getRadius(1.5)};
  `,
  lg: css`
    min-height: ${getSize(9)};
    padding: ${getSpace(2)};
    border-radius: ${getRadius(1.5)};
  `,
  xl: css`
    min-height: ${getSize(10)};
    padding: ${getSpace(2)};
    border-radius: ${getRadius(1.5)};
  `,
};

export const inputWidths = {
  xs: 20,
  sm: 40,
  md: 60,
  lg: 80,
  xl: 96,
};

export type InputWidth = keyof typeof inputWidths;

export interface InputWidthProps {
  width?: InputWidth;
}

export const inputWidthStyles = ({ width }: InputWidthProps) =>
  width &&
  css`
    width: ${getSpace(inputWidths[width])};
  `;

export type InputSizeProps = InputHeightProps & InputWidthProps;

export const isInputSizeProp = (propName: string) =>
  ['size', 'width'].includes(propName);
