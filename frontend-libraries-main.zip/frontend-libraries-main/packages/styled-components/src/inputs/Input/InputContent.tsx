import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getSize } from '@/styles/size';
import { getSpace } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';

interface InputContentProps {
  prefix?: boolean;
  suffix?: boolean;
}

export const InputContent = styled.span.withConfig({
  shouldForwardProp: (p) => !['prefix', 'suffix'].includes(p),
})<InputContentProps>`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: ${getSpace()};
  ${getBodyTextStyles({ color: 'fgSubtle' })};

  height: ${getSize(4)};
  box-sizing: border-box;

  ${({ prefix }) =>
    prefix &&
    css`
      margin: 1px 0;
      border-right: 1px solid ${getColor('border')};
      padding-right: ${getSpace(2)};
      padding-left: ${getSpace(1)};
    `}
  ${({ suffix }) =>
    suffix &&
    css`
      margin: 1px 0;
      border-left: 1px solid ${getColor('border')};
      padding-left: ${getSpace(2)};
      padding-right: ${getSpace(1.5)};
    `}
`;
