import { forwardRef } from 'react';

import { InputElement, InputElementProps } from '@/inputs/Input/InputElement';

import { Field, FieldProps } from '../Field';

export type InputProps = InputElementProps & Omit<FieldProps, 'as'>;

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      id,
      label,
      desc,
      message,
      hideLabel,
      width,
      tooltip,
      placeholder,
      ...inputProps
    },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      desc={desc}
      message={message}
      required={inputProps.required || !!inputProps['aria-required']}
      error={inputProps.error}
      size={inputProps.size}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
    >
      <InputElement
        ref={ref}
        id={id}
        label={label}
        {...inputProps}
        placeholder={inputProps.readOnly ? undefined : placeholder}
      />
    </Field>
  ),
);

Input.displayName = 'Input';
