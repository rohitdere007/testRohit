import { TextareaHTMLAttributes } from 'react';
import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getSpace } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

import {
  InputSharedStylesProps,
  inputSharedStyles,
  isInputSharedProp,
} from '../Input/inputSharedStyles';

export type TextAreaElementProps = Omit<
  TextareaHTMLAttributes<HTMLTextAreaElement>,
  'children'
> &
  InputSharedStylesProps;

export const TextAreaElement = styled.textarea.withConfig({
  shouldForwardProp: (propName) => !isInputSharedProp(propName),
})<InputSharedStylesProps>`
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  margin: 0;

  outline: none;

  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${getSpace()};
  align-self: stretch;
  background-color: ${getColor('bgPrimary')};
  border: 1px solid ${getColor('border')};

  ${getUITextStyles({
    color: 'fg',
    weight: 'regular',
  })};

  &::placeholder {
    ${getUITextStyles({
      color: 'fgPlaceholder',
      weight: 'regular',
    })};
  }

  &:disabled {
    pointer-events: none;
  }

  ${inputSharedStyles};

  &:read-only {
    color: ${getColor('fgPlaceholder')};
    background-color: transparent;
    resize: none;
  }
`;
