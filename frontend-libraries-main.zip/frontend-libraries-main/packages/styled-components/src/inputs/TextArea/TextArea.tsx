import { LegacyRef, forwardRef } from 'react';

import {
  TextAreaElement,
  TextAreaElementProps,
} from '@/inputs/TextArea/TextAreaElement';

import { Field, FieldProps } from '../Field';

type TextAreaProps = Omit<FieldProps, 'as'> & TextAreaElementProps;

export const TextArea = forwardRef<HTMLTextAreaElement, TextAreaProps>(
  (
    { id, label, desc, message, hideLabel, width, tooltip, ...inputProps },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      message={message}
      required={inputProps.required || !!inputProps['aria-required']}
      error={inputProps.error}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
      size={inputProps.size}
      desc={desc}
    >
      <TextAreaElement
        label={label}
        ref={ref as unknown as LegacyRef<HTMLTextAreaElement> | undefined}
        id={id}
        {...inputProps}
      />
    </Field>
  ),
);

TextArea.displayName = 'TextArea';
