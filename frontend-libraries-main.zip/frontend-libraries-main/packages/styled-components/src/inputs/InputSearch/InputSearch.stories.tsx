import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';

import { inputSizeStyles, inputWidths } from '../Input/inputSizes';
import { SupportText } from '../SupportText';

import { InputSearch } from './InputSearch';

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

type Story = StoryObj<typeof InputSearch>;

export default {
  component: InputSearch,
  parameters: {
    controls: {
      exclude: ['onFocus', 'onBlur', 'onChange'],
    },
    docs: {
      description: {
        component:
          'The InputSearch component is the same as Input except that the input "type" is already set to "search"',
      },
    },
    actions: {
      handles: ['focus', 'blur', 'change'],
    },
  },
  args: {
    disabled: false,
    placeholder: '',
    readOnly: false,
    required: false,
    invalid: false,
    defaultValue: 'Search Term',
    label: 'Input Label',
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    size: {
      control: {
        type: 'select',
      },
      description:
        'the height of the input field which matches the button sizes',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'undefined' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the input is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description:
        "If the input value is invalid but shouldn't use default browser messaging.",
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    invalid: {
      control: { type: 'boolean' },
      description: 'If the input value is invalid',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof InputSearch>;

export const Demo: Story = {
  args: {
    label: 'Search',
  },
  render(props) {
    return (
      <InputSearch
        {...props}
        message={
          (props.invalid || props.message) && (
            <SupportText variant="critical">
              {props.message || 'Some sort of validation error'}
            </SupportText>
          )
        }
      />
    );
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    value: 'Loading...',
  },
};

export const InvalidWithMessage: Story = {
  args: {
    invalid: true,
    value: 'Cheese',
  },
  render(props) {
    return (
      <InputSearch
        {...props}
        required
        invalid
        label="Date"
        defaultValue="Something..."
        message={
          <SupportText variant="critical">
            Some sort of validation error
          </SupportText>
        }
      />
    );
  },
};
