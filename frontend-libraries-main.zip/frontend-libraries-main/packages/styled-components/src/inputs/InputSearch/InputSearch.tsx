import { mdiMagnify } from '@mdi/js';
import { forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { Icon } from '@/atoms/Icon';

import { Field, FieldProps } from '../Field';
import { BaseInput } from '../Input/BaseInput';
import { InputElement, InputElementProps } from '../Input/InputElement';

type InputSearchProps = Omit<FieldProps, 'as'> &
  Omit<InputElementProps, 'type'> & {
    controls?: boolean;
  };

const InputSearchWrapper = styled.div<{ $controls?: boolean }>`
  ${({ $controls }) =>
    $controls === false &&
    css`
      ${BaseInput} {
        &::-webkit-search-decoration,
        &::-webkit-search-cancel-button,
        &::-webkit-search-results-button,
        &::-webkit-search-results-decoration {
          appearance: none;
        }
      }
    `}
`;

export const InputSearch = forwardRef<HTMLInputElement, InputSearchProps>(
  (
    { id, label, desc, message, hideLabel, controls, width, tooltip, ...props },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      desc={desc}
      message={message}
      required={props.required || !!props['aria-required']}
      error={props.error}
      size={props.size}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
    >
      <InputSearchWrapper $controls={controls}>
        <InputElement
          ref={ref}
          id={id}
          label={label}
          {...props}
          type="search"
          leading={<Icon icon={mdiMagnify} />}
        />
      </InputSearchWrapper>
    </Field>
  ),
);

InputSearch.displayName = 'InputSearch';
