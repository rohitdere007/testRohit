import { ReactNode } from 'react';
import styled from 'styled-components';
import { KnownTarget } from 'styled-components/dist/types';

import { Flex } from '@/atoms/Flex';
import { Label } from '@/inputs/Label';
import { LabelText, LabelTextMode } from '@/inputs/LabelText/LabelText';
import { getSpace } from '@/styles/space';
import { ScreenReaderText } from '@/typography/ScreenReaderText';
import { UIText } from '@/typography/UIText';

import {
  InputSize,
  InputWidthProps,
  inputWidthStyles,
} from '../Input/inputSizes';
import { SupportText, SupportTextWrapper } from '../SupportText/SupportText';

export const FieldWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'width',
})<InputWidthProps>`
  display: flex;
  flex-direction: column;
  gap: ${getSpace(2)};
  width: 100%;
  box-sizing: border-box;
  ${SupportTextWrapper} {
    margin-left: -1px;
  }
  ${inputWidthStyles}
`;

export type FieldProps = InputWidthProps & {
  id?: string;
  label: string;
  desc?: string;
  children?: ReactNode;
  tooltip?: ReactNode;
  message?: ReactNode;
  error?: ReactNode;
  required?: boolean;
  'aria-required'?: boolean;
  hideLabel?: boolean;
  size?: InputSize;
  as?: KnownTarget;
  mode?: LabelTextMode;
};

export const Field = ({
  id,
  label,
  desc,
  required,
  message,
  error,
  hideLabel,
  children,
  tooltip,
  size = 'md',
  mode,
  ...rest
}: FieldProps) => (
  <FieldWrapper {...rest}>
    <Label htmlFor={id}>
      {hideLabel ? (
        <ScreenReaderText>{label}</ScreenReaderText>
      ) : (
        <>
          <Flex gap="1" align="center">
            <LabelText
              mode={mode}
              required={required}
              size={!['md', 'lg', 'xl'].includes(size) ? 'sm' : undefined}
            >
              {label}
            </LabelText>
            {tooltip}
          </Flex>

          {desc && <UIText color="fgSubtle">{desc}</UIText>}
        </>
      )}
      {children}
    </Label>
    {error && error !== true && <SupportText>{error}</SupportText>}
    {message}
  </FieldWrapper>
);
