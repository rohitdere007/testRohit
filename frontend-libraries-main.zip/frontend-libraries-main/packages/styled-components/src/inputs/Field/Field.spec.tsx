import { render, screen } from '@testing-library/react';

import { InputElement } from '@/inputs/Input/InputElement';
import { withTheme } from '@/utils/jest';

import { Field } from './Field';

const params = { wrapper: withTheme };

describe('Field', () => {
  it('links label and input', () => {
    render(
      <Field label="a field">
        <InputElement label="test" defaultValue="" />
      </Field>,
      params,
    );

    expect(screen.getByLabelText<HTMLInputElement>('a field').type).toBe(
      'text',
    );
  });

  it('links label and input with passed id', () => {
    const id = 'test-id';
    render(
      <Field label="a field" id={id}>
        <InputElement label="test" id={id} defaultValue="a" />
      </Field>,
      params,
    );
    expect(screen.getByLabelText<HTMLInputElement>('a field').type).toBe(
      'text',
    );
    expect(screen.getByDisplayValue('a')).toHaveAttribute('id', id);
  });

  it('links label and input uniquely', () => {
    render(
      <>
        <Field label="field-a">
          <InputElement label="test" defaultValue="a" />
        </Field>
        <Field label="field-b">
          <InputElement label="test" defaultValue="b" />
        </Field>
      </>,
      params,
    );

    expect(screen.getByLabelText('field-a')).toHaveValue('a');
    expect(screen.getByLabelText('field-b')).toHaveValue('b');
  });

  it('appends content', () => {
    render(
      <Field label="field-a" message={<span>appended content</span>}>
        <InputElement label="test" defaultValue="a" />
      </Field>,
      params,
    );

    expect(screen.getByText('appended content')).toBeInTheDocument();
  });
});
