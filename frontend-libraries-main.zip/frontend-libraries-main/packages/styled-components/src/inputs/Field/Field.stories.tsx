import { Meta, StoryObj } from '@storybook/react';

import { InputElement } from '../Input/InputElement';
import { inputSizeStyles, inputWidths } from '../Input/inputSizes';

import { Field } from './Field';

type Story = StoryObj<typeof Field>;

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

export default {
  component: Field,
  parameters: {
    layout: 'flex',
    actions: {
      handles: ['focus', 'blur', 'change'],
    },
  },
  args: {
    required: false,
    hideLabel: false,
    mode: 'required',
    label: 'Input Label',
  },
  argTypes: {
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    desc: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The optional description associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    size: {
      control: {
        type: 'select',
      },
      description: 'the height of the input field also controls the label size',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'undefined' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    mode: {
      control: {
        type: 'select',
      },
      description:
        'If the label should have a * for required fields or (Optional) for optional fields.',
      options: ['required', 'optional'],
    },
    error: {
      control: { type: 'text' },
      description: 'Used for error messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for non error messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  render(props) {
    return (
      <Field {...props}>
        <InputElement label={props.label} placeholder="Placeholder..." />
      </Field>
    );
  },
} satisfies Meta<typeof Field>;

export const FieldStory: Story = {
  name: 'Field',
};

export const HiddenLabel: Story = {
  args: {
    hideLabel: true,
  },
};

export const ErrorWithMessage: Story = {
  args: {
    error: 'Some sort of validation error',
  },
  render(props) {
    return (
      <Field {...props}>
        <InputElement
          label={props.label}
          required={props.required}
          type="email"
          defaultValue="Something..."
        />
      </Field>
    );
  },
};
