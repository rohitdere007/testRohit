import { Meta, StoryObj } from '@storybook/react';

import { InputElement } from '../Input/InputElement';

import { Label } from './Label';

type Story = StoryObj<typeof Label>;

export default {
  component: Label,
  args: {
    children: 'Input Label',
  },
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'HTML label element.',
      },
    },
  },
} satisfies Meta<typeof Label>;

export const Wrapper: Story = {
  render: ({ children }) => (
    <Label>
      {children}
      <InputElement label="test" name="test" value="text" />
    </Label>
  ),
};

export const HtmlFor: Story = {
  render: ({ children }) => {
    const id = 'test-id';
    return (
      <>
        <Label htmlFor={id}>{children}</Label>
        <InputElement
          label={children as string}
          id={id}
          name="test"
          value="text"
        />
      </>
    );
  },
};
