import { render, screen } from '@testing-library/react';

import { withTheme } from '@/utils/jest';

import { InputElement } from '../Input/InputElement';

import { Label } from './Label';

const params = { wrapper: withTheme };

describe('Label', () => {
  it('links label and input passed as a child', () => {
    render(
      <Label>
        a field
        <InputElement label="test" defaultValue="text" />
      </Label>,
      params,
    );

    expect(screen.getByLabelText<HTMLInputElement>('a field').type).toBe(
      'text',
    );
  });

  it('links label "for" with input "id"', () => {
    const testId = 'test-id';
    render(
      <>
        <Label htmlFor={testId}>a field</Label>
        <InputElement id={testId} label="test" defaultValue="text" />
      </>,
      params,
    );

    expect(screen.getByLabelText<HTMLInputElement>('a field').type).toBe(
      'text',
    );
  });
});
