import styled from 'styled-components';

import { getSpace } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

export const Label = styled.label.withConfig({ displayName: 'Label' })`
  display: flex;
  flex-direction: column;
  gap: ${getSpace()};
  ${getUITextStyles({ color: 'fg', weight: 'semi-bold' })}
`;
