// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const sanitiseStoryProps = ({ type, ...props }: any) => props;
