import { forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';

import { CheckedInput } from '../CheckedInput';
import { CheckboxBorderProps } from '../InputCheckbox/checkboxBorderStyles';
import { InputCheckboxProps } from '../InputCheckbox/InputCheckbox';

const Toggle = styled.span``;

const ToggleWrapper = styled.span.withConfig({
  shouldForwardProp: (propName) => propName !== 'size',
})<Pick<CheckboxBorderProps, 'size'>>`
  position: relative;
  display: inline-block;
  width: ${getSize(9)};
  height: ${getSize(4.5)};
  flex-shrink: 0;

  ${Toggle} {
    overflow: hidden;
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: ${getRadius('full')};
    border-color: ${getColor('borderStrong')};
    border: 1px solid;

    &:hover {
      background-color: ${getColor('bgTertiaryHover')};
    }

    &:before {
      position: absolute;
      content: '';
      height: ${getSize(3.5)};
      width: ${getSize(3.5)};
      left: ${getSize(0.25)};
      bottom: ${getSize(0.25)};
      background-color: ${getColor('fgOnLight')};
      transition: transform 300ms;
      @media (prefers-reduced-motion) {
        transition-duration: 0ms;
      }
      border-radius: ${getRadius('full')};
      box-shadow: 0px 2px 2px 0px rgba(0, 0, 0, 0.12);
    }
  }

  &:has(~ :checked) {
    ${Toggle} {
      background-color: ${getColor('bgInfo')};
      border-color: ${getColor('bgInfo')};

      &:hover {
        background-color: ${getColor('bgInfoHover')};
      }
      &:before {
        background-color: ${getColor('fgOnDark')};
        transform: translateX(${getSize(4.5)});
      }
    }
  }

  &:has(~ :focus-visible) {
    outline: solid 2px ${getColor('borderInfo')};
    outline-offset: 2px;
    border-radius: ${getRadius('full')};
  }

  ${({ size }) =>
    size === 'md' &&
    css`
      width: ${getSize(14)};
      height: ${getSize(7)};
      ${Toggle} {
        &:before {
          left: ${getSize(0.75)};
          bottom: ${getSize(0.75)};
          width: ${getSize(5)};
          height: ${getSize(5)};
        }
      }
      &:has(~ :checked) {
        ${Toggle} {
          &:before {
            transform: translateX(${getSize(7)});
          }
        }
      }
    `}
`;

export const InputToggle = forwardRef<HTMLInputElement, InputCheckboxProps>(
  ({ size = 'sm', ...props }, ref) => (
    <CheckedInput
      {...props}
      ref={ref}
      size={size}
      type="checkbox"
      input={
        <ToggleWrapper size={size}>
          <Toggle />
        </ToggleWrapper>
      }
    />
  ),
);

InputToggle.displayName = 'InputToggle';
