import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';

import FlexMeta from '@/atoms/Flex/Flex.stories';

import { sanitiseStoryProps } from '../utils/stories';

import { InputToggle } from './InputToggle';

const { margin, padding, ...flexArgs } = FlexMeta.argTypes;

export default {
  component: InputToggle,
  args: {
    value: 'value',
    label: 'Value label',
    size: 'md',
    disabled: false,
    invalid: false,
    align: 'center',
    hideLabel: false,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    size: {
      control: {
        type: 'select',
      },
      options: ['sm', 'md'],
    },
    ...flexArgs,
    align: {
      control: {
        type: 'select',
      },
      options: ['start', 'center'],
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Checkbox Input component',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof InputToggle>;

type Story = StoryObj<typeof InputToggle>;

export const InputToggleStory: Story = {
  name: 'InputToggle',
  parameters: {
    controls: {
      exclude: [
        'type',
        'before',
        'after',
        'placeholder',
        'readOnly',
        'hideLabel',
        'defaultValue',
      ],
    },
  },
  render: (props) => <InputToggle {...sanitiseStoryProps(props)} />,
};
