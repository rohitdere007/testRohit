import { forwardRef } from 'react';

import { Field, FieldProps } from '../Field';

import { SelectElement, SelectElementProps } from './SelectElement';

export type SelectOption<T = string> = {
  value: T;
  label: string;
  disabled?: boolean;
};

export type SelectOptionGroup<T = string> = {
  options: SelectOption<T>[];
  label: string;
  disabled?: boolean;
};

export type SelectOptions<T = string> =
  | SelectOption<T>[]
  | SelectOptionGroup<T>[];

type SelectProps = Omit<FieldProps, 'children' | 'as'> &
  Omit<SelectElementProps, 'children'> & {
    options: SelectOptions;
  };

export const Options = ({ options = [] }: { options: SelectOption[] }) => (
  <>
    {options.map(({ value, label: text }) => (
      <option key={value} value={value}>
        {text}
      </option>
    ))}
  </>
);

export const OptionGroups = ({
  groups = [],
}: {
  groups: SelectOptionGroup[];
}) => (
  <>
    {groups.map(({ label, options }) => (
      <optgroup key={label} label={label}>
        <Options options={options} />
      </optgroup>
    ))}
  </>
);

export const isSelectOption = <T,>(
  value: SelectOption<T> | object,
): value is SelectOption<T> => 'value' in value && 'label' in value;

export const isOptionGroups = (
  options: SelectOptions,
): options is SelectOptionGroup[] =>
  !!options?.length && 'options' in options[0];

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  (
    {
      id,
      label,
      desc,
      options,
      message,
      hideLabel,
      width,
      tooltip,
      ...inputProps
    },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      desc={desc}
      message={message}
      required={inputProps.required || !!inputProps['aria-required']}
      error={inputProps.error}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
      size={inputProps.size}
    >
      <SelectElement ref={ref} id={id} label={label} {...inputProps}>
        {isOptionGroups(options) ? (
          <OptionGroups groups={options} />
        ) : (
          <Options options={options} />
        )}
      </SelectElement>
    </Field>
  ),
);

Select.displayName = 'Select';
