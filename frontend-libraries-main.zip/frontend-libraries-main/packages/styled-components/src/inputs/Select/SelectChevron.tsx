import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getSpace, getSpacing } from '@/styles/space';

export const SelectChevron = styled.span`
  position: absolute;
  right: ${getSpace()};
  height: 100%;
  display: flex;
  align-items: center;
  color: ${getColor('fgSubtle')};
  padding: ${getSpacing('0 1')};

  transition: transform 200ms ease-in-out;

  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }
`;
