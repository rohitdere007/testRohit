import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';

import { inputSizeStyles, inputWidths } from '../Input/inputSizes';
import { SupportText } from '../SupportText';
import { sanitiseStoryProps } from '../utils/stories';

import { Select } from './Select';

type Story = StoryObj<typeof Select>;

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

const options = [
  { label: 'Option One', value: 'one' },
  { label: 'Option Two', value: 'two' },
  { label: 'Option Three', value: 'three' },
  { label: 'Option Four', value: 'four' },
  { label: 'Option Five', value: 'five' },
];

export default {
  component: Select,
  parameters: {
    controls: {
      exclude: ['onFocus', 'onBlur', 'onChange'],
    },
    docs: {
      description: {
        component:
          '<p>The Select component accept the native props expected of the html select element along with some extra props which are listed below</p>' +
          '<p>It is very important that any input displayed on a page has a label associated with it. ' +
          'To reach AAA compliance the label must be visible. ' +
          'To reach AA compliance there must be a label but ' +
          "it doesn't have to be visible so our Input components " +
          'do provide a "hideLabel" prop to accomodate this.</p>',
      },
    },
    actions: {
      handles: ['focus', 'blur', 'change'],
    },
  },
  args: {
    disabled: false,
    readOnly: false,
    required: false,
    invalid: false,
    hideLabel: false,
    label: 'Select Label',
    options: options,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    // placeholder: {
    //   control: { type: 'text' },
    //   description: 'a placeholder value for the input',
    //   table: {
    //     type: { summary: 'string' },
    //     defaultValue: { summary: '' },
    //   },
    // },
    size: {
      control: {
        type: 'select',
      },
      description:
        'the height of the input field which matches the button sizes',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'undefined' },
      },
    },
    options: {
      control: false,
      description: 'The options associated with the select',
      table: {
        type: { summary: `{ label: string, value: string}[]` },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the input is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description:
        "If the input value is invalid but shouldn't use default browser messaging.",
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    invalid: {
      control: { type: 'boolean' },
      description: 'If the input value is invalid',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
  render({ ...props }) {
    return (
      <Select
        {...sanitiseStoryProps(props)}
        message={
          (props.invalid || props.message) && (
            <SupportText variant="critical">
              {props.message || 'Some sort of validation error'}
            </SupportText>
          )
        }
      />
    );
  },
} satisfies Meta<typeof Select>;

export const SelectStory: Story = {
  name: 'Select',
  parameters: {
    controls: {
      exclude: ['type', 'before', 'after', 'children'],
    },
  },
};

export const ReadOnly: Story = {
  args: {
    readOnly: true,
    value: 'one',
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    value: 'one',
  },
};

export const Error: Story = {
  args: {
    error: 'Some sort of validation error',
    value: 'one',
  },
};

export const CustomMessage: Story = {
  render(props) {
    return (
      <Select
        {...props}
        required
        invalid
        label="Select Label"
        defaultValue="one"
        message={
          <SupportText variant="critical">
            Some sort of validation error
          </SupportText>
        }
        options={options}
      />
    );
  },
};

export const HiddenLabel: Story = {
  args: {
    hideLabel: true,
  },
};
