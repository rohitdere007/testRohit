import { mdiChevronDown } from '@mdi/js';
import { SelectHTMLAttributes, forwardRef } from 'react';
import { css, styled } from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { getColor } from '@/styles/color';
import { getSpacing } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

import {
  InputSharedStylesProps,
  inputSharedStyles,
  isInputSharedProp,
} from '../Input/inputSharedStyles';
import { inputSizeStyles, inputWidthStyles } from '../Input/inputSizes';

import { SelectChevron } from './SelectChevron';

export type SelectElementProps = SelectHTMLAttributes<HTMLSelectElement> &
  InputSharedStylesProps;

export const BaseSelect = styled.select.withConfig({
  shouldForwardProp: (propName) => !isInputSharedProp(propName),
})<SelectElementProps>`
  /* reset */
  outline: none;
  margin: 0;
  appearance: none;
  position: absolute;
  width: 100%;

  /* styling */
  box-sizing: border-box;
  background: transparent;
  border: 1px solid ${getColor('border')};
  display: inline-block;
  font: inherit;
  ${getUITextStyles({ color: 'fg', weight: 'regular' })};
  padding: ${getSpacing('0 8 0 2')};
  z-index: 2;

  &:-moz-focusring {
    color: transparent;
    text-shadow: 0 0 0 #000;
  }

  ${inputSharedStyles};
`;

type WrapperProps = Pick<SelectElementProps, 'size' | 'width' | 'readOnly'>;

export const SelectWrapper = styled.span.withConfig({
  shouldForwardProp: (p) => !['size', 'width'].includes(p),
})<WrapperProps>`
  display: inline-block;
  position: relative;
  background-color: ${getColor('bgPrimary')};
  box-sizing: border-box;

  ${({ size }) => inputSizeStyles[size || 'md']};
  padding: 0;

  ${inputWidthStyles};

  &:focus-within {
    padding: 0;
    ${SelectChevron} {
      transform: rotate(180deg);
    }
  }

  ${({ readOnly }) =>
    readOnly
      ? css`
          background-color: transparent;
          ${SelectChevron} {
            display: none;
          }
        `
      : css`
          &:focus-within {
            ${SelectChevron} {
              color: ${getColor('borderPressed')};
            }
          }
        `};
`;

export const SelectElement = forwardRef<HTMLSelectElement, SelectElementProps>(
  (props, ref) => {
    const { size, width, readOnly, label } = props;

    return (
      <SelectWrapper readOnly={readOnly} size={size} width={width}>
        <BaseSelect {...props} ref={ref} aria-label={label} />
        <SelectChevron>
          <Icon icon={mdiChevronDown} size="md" />
        </SelectChevron>
      </SelectWrapper>
    );
  },
);

SelectElement.displayName = 'SelectElement';
