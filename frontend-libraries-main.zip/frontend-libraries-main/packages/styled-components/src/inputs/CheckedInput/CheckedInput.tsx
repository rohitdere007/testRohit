import { InputHTMLAttributes, ReactNode, forwardRef } from 'react';
import { styled } from 'styled-components';

import { FlexProps, isFlexPropName } from '@/atoms/Flex';
import { FlexParams, flex } from '@/styles/flex';
import { getUITextStyles } from '@/styles/typography';
import { WidthProps, isWidthProp, width } from '@/styles/width';
import { ScreenReaderText } from '@/typography/ScreenReaderText';

import { LabelText } from '../LabelText';

const HiddenCheckedInput = styled.input<React.HTMLAttributes<HTMLInputElement>>`
  opacity: 0;
  height: 0;
  width: 0;
  overflow: hidden;
  position: fixed;
`;

const config = {
  shouldForwardProp: (p: string) => !isFlexPropName(p) && !isWidthProp(p),
};

export const CheckedLabel = styled.label.withConfig(config)<
  FlexParams & WidthProps
>`
  ${({
    justify = 'center',
    align = 'flex-start',
    direction = 'row',
    gap = 2,
  }) => flex({ justify, align, direction, gap })}
  ${width}
  cursor: pointer;
  user-select: none;
  ${getUITextStyles({ size: 'md' })};
  flex-shrink: 0;

  &:has(:disabled) {
    opacity: 0.4;
  }
`;

export type CheckedInputProps = Omit<
  InputHTMLAttributes<HTMLInputElement>,
  'size'
> &
  FlexProps &
  WidthProps & {
    type: 'checkbox' | 'radio';
    label: string;
    hideLabel?: boolean;
    size?: 'sm' | 'md';
    labelSize?: 'sm' | 'md';
    input: ReactNode;
  };

export const CheckedInput = forwardRef<HTMLInputElement, CheckedInputProps>(
  (
    {
      children,
      direction = 'row',
      justify = 'flex-start',
      align = 'center',
      hideLabel,
      label,
      labelSize,
      size = 'md',
      className,
      input,
      width: widthProp,
      ...props
    },
    ref,
  ) => (
    <CheckedLabel
      direction={direction}
      justify={justify}
      align={align}
      className={className}
      width={widthProp}
    >
      {input}
      {hideLabel ? (
        <ScreenReaderText>{label}</ScreenReaderText>
      ) : (
        <LabelText
          required={props.required || !!props['aria-required']}
          size={labelSize || size}
          weight="regular"
        >
          {children || label}
        </LabelText>
      )}
      <HiddenCheckedInput {...props} ref={ref} aria-label={label} />
    </CheckedLabel>
  ),
);

CheckedInput.displayName = 'CheckedInput';
