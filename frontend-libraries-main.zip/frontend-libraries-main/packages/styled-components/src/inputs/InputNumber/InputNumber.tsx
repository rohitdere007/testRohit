import { Property } from 'csstype';
import { forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { Field, FieldProps } from '../Field';
import { BaseInput } from '../Input/BaseInput';
import { InputElement, InputElementProps } from '../Input/InputElement';

interface InputNumberWrapperProps {
  controls?: boolean;
  align?: Property.TextAlign;
}

type InputNumberProps = Omit<FieldProps, 'as'> &
  Omit<InputElementProps, 'type'> &
  InputNumberWrapperProps;

export const InputNumberWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => !['controls', 'align'].includes(p),
})<InputNumberWrapperProps>`
  ${({ controls = true }) =>
    !controls &&
    css`
      ${BaseInput} {
        &::-webkit-outer-spin-button,
        &::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }

        /* Firefox */
        & {
          -moz-appearance: textfield;
          appearance: textfield;
        }
      }
    `}
  ${BaseInput} {
    text-align: ${({ align = 'left' }) => align};
  }
`;

export const InputNumber = forwardRef<HTMLInputElement, InputNumberProps>(
  (
    {
      id,
      label,
      desc,
      message,
      hideLabel,
      align,
      controls,
      width,
      tooltip,
      ...inputProps
    },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      desc={desc}
      message={message}
      required={inputProps.required || !!inputProps['aria-required']}
      error={inputProps.error}
      size={inputProps.size}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
    >
      <InputNumberWrapper align={align} controls={controls}>
        <InputElement
          ref={ref}
          id={id}
          label={label}
          {...inputProps}
          type="number"
        />
      </InputNumberWrapper>
    </Field>
  ),
);

InputNumber.displayName = 'InputNumber';
