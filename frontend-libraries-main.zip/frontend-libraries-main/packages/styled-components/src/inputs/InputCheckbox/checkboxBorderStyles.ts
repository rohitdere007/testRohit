import { css } from 'styled-components';

import { IconSize } from '@/atoms/Icon';
import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';

export type CheckboxBorderProps = {
  size?: keyof typeof checkboxSizes;
  invalid?: boolean;
};

export const checkboxSizes: Record<string, IconSize> = {
  sm: 'xs',
  md: 'sm',
};

export const checkboxBorderStyles = css<CheckboxBorderProps>`
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;

  background-color: ${getColor('bgPrimary')};
  border: 1px solid ${getColor('border')};
  border-radius: ${getRadius(0.5)};

  height: ${getSize(4)};
  width: ${getSize(4)};

  flex-shrink: 0;

  ${({ size }) =>
    size === 'md' &&
    css`
      padding: 1px;
      height: ${getSize(5)};
      width: ${getSize(5)};
      border-radius: ${getRadius()};
    `}

  svg {
    opacity: 0;
    transition: opacity 200ms ease-in-out;
  }

  &:has(~ [type='checkbox']:indeterminate),
  &:has(~ :checked) {
    background-color: ${getColor('bgInfo')};
    border-color: ${getColor('bgInfo')};
    color: ${getColor('fgOnDark')};

    svg {
      opacity: 1;
    }
  }
  &:has(~ :focus-visible) {
    outline: solid 2px ${getColor('borderInfo')};
    outline-offset: 2px;
    border-radius: ${getRadius(0.5)};
  }

  ${({ invalid }) =>
    invalid
      ? css`
          border-color: ${getColor('bgCritical')};
          &:has(~ :checked),
          &:has(~ :indeterminate) {
            border-color: ${getColor('bgCritical')};
            background: ${getColor('bgCritical')};
          }
        `
      : css`
          &:not(:has(~ :checked)):not(:has(~ :indeterminate)) {
            &:hover,
            &:focus-within {
              border-color: ${getColor('borderHover')};
            }
          }
        `}
`;
