import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { ChangeEvent } from 'react';

import FlexMeta from '@/atoms/Flex/Flex.stories';

import { sanitiseStoryProps } from '../utils/stories';

import { InputCheckbox, InputCheckboxProps } from './InputCheckbox';

const { margin, padding, ...flexArgs } = FlexMeta.argTypes;

export default {
  component: InputCheckbox,
  args: {
    value: 'value',
    label: 'Value label',
    size: 'md',
    disabled: false,
    // invalid: false,
    direction: 'row',
    align: 'center',
    justify: 'flex-start',
    hideLabel: false,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    size: {
      control: {
        type: 'select',
      },
      options: ['sm', 'md'],
    },
    ...flexArgs,
    checked: {
      control: { type: 'boolean' },
      description: 'If the input value is checked',
      table: {
        type: { summary: 'true | false | undefined' },
        defaultValue: { summary: 'undefined' },
      },
    },
    indeterminate: {
      control: { type: 'boolean' },
      description: 'If the input value is indeterminate',
      table: {
        type: { summary: 'true | false | undefined' },
        defaultValue: { summary: 'undefined' },
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Checkbox Input component',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof InputCheckbox>;

type Story = StoryObj<typeof InputCheckbox>;

const render = (props: InputCheckboxProps) => {
  const [, updateArgs] = useArgs();
  const onChange = (e: ChangeEvent<HTMLInputElement>) => {
    props.onChange?.(e);
    updateArgs({ indeterminate: false, checked: e.target.checked });
  };
  return <InputCheckbox {...sanitiseStoryProps(props)} onChange={onChange} />;
};

export const InputCheckboxStory: Story = {
  name: 'InputCheckbox',
  parameters: {
    controls: {
      exclude: [
        'type',
        'before',
        'after',
        'placeholder',
        'readOnly',
        'hideLabel',
        'defaultValue',
      ],
    },
  },
  render,
};

export const CheckboxIndeterminate: Story = {
  args: {
    indeterminate: true,
  },
  render,
};
