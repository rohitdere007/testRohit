import { mdiCheck, mdiMinusThick } from '@mdi/js';
import { forwardRef, useEffect, useRef, useState } from 'react';
import styled from 'styled-components';

import { Icon } from '@/atoms/Icon';

import { CheckedInput, CheckedInputProps } from '../CheckedInput';

import {
  CheckboxBorderProps,
  checkboxBorderStyles,
  checkboxSizes,
} from './checkboxBorderStyles';

export const CheckboxBorder = styled.span.withConfig({
  shouldForwardProp: (propName) => !['size', 'invalid'].includes(propName),
})<CheckboxBorderProps>`
  ${checkboxBorderStyles};
`;

export type InputCheckboxProps = Omit<CheckedInputProps, 'type' | 'input'> &
  CheckboxBorderProps & {
    indeterminate?: boolean;
  };

export const InputCheckbox = forwardRef<HTMLInputElement, InputCheckboxProps>(
  ({ size = 'md', indeterminate, invalid, ...props }, forwardedRef) => {
    const ref = useRef<HTMLInputElement | null>(null);
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
      if (indeterminate === undefined) {
        return;
      }
      if (!ref.current) {
        if (!mounted) {
          setMounted(true);
        }
        return;
      }
      ref.current.indeterminate = !!indeterminate;
    }, [ref, indeterminate, mounted]);

    const icon = indeterminate ? mdiMinusThick : mdiCheck;

    return (
      <CheckedInput
        {...props}
        size={size}
        type="checkbox"
        ref={(el) => {
          ref.current = el;
          if (typeof forwardedRef === 'function') {
            forwardedRef(el);
          } else if (forwardedRef) {
            forwardedRef.current = el;
          }
        }}
        input={
          <CheckboxBorder size={size} invalid={invalid}>
            <Icon icon={icon} size={checkboxSizes[size]} />
          </CheckboxBorder>
        }
      />
    );
  },
);

InputCheckbox.displayName = 'InputCheckbox';
