import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { useEffect, useState } from 'react';

import { inputSizeStyles, inputWidths } from '../Input/inputSizes';
import { sanitiseStoryProps } from '../utils/stories';

import { InputRange } from './InputRange';

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

export default {
  component: InputRange,
  args: {
    disabled: false,
    invalid: false,
    readOnly: false,
    required: false,
    hideLabel: false,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
    min: 0,
    max: 100,
    value: 80,
    unit: '%',
    label: 'Range Slider',
  },
  argTypes: {
    value: {
      control: {
        type: 'number',
      },
      description: 'The numeric value of the field',
    },
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    desc: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'Optional additional description',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'a placeholder value for the input',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '' },
      },
    },
    size: {
      control: {
        type: 'select',
      },
      description:
        'the height of the input field which matches the button sizes',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'undefined' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the input is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description:
        "If the input value is invalid but shouldn't use default browser messaging.",
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    invalid: {
      control: { type: 'boolean' },
      description: 'If the input value is invalid',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    prefix: {
      control: { type: 'text' },
      description: 'A prefix applied to the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    suffix: {
      control: { type: 'text' },
      description: 'A suffix applied to the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Range Input component',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof InputRange>;

type Story = StoryObj<typeof InputRange>;

export const InputRangeStory: Story = {
  name: 'InputRange',
  parameters: {
    controls: {
      exclude: [
        'type',
        'before',
        'after',
        'placeholder',
        'readOnly',
        'hideLabel',
        'defaultValue',
      ],
    },
  },
  render: ({ value, ...props }) => {
    const [, updateArgs] = useArgs();
    const [valueState, setValueState] = useState(value);
    useEffect(() => {
      updateArgs({ value: valueState });
    }, [valueState]);
    useEffect(() => {
      if (value !== valueState) {
        setValueState(value);
      }
    }, [value]);
    return (
      <InputRange
        {...sanitiseStoryProps(props)}
        name="range"
        value={valueState}
        onChange={(e) => {
          props.onChange?.(e);
          setValueState(e.target.value);
        }}
      />
    );
  },
};
