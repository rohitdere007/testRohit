import { forwardRef } from 'react';

import { Field, FieldProps } from '../Field';

import { InputRangeField, InputRangeFieldProps } from './InputRangeField';

type InputRangeProps = Omit<FieldProps, 'as'> & InputRangeFieldProps;

export const InputRange = forwardRef<HTMLInputElement, InputRangeProps>(
  (
    { id, label, desc, message, hideLabel, width, tooltip, ...inputProps },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      desc={desc}
      message={message}
      required={inputProps.required || !!inputProps['aria-required']}
      error={inputProps.error}
      size={inputProps.size}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
    >
      <InputRangeField ref={ref} id={id} label={label} {...inputProps} />
    </Field>
  ),
);

InputRange.displayName = 'InputRange';
