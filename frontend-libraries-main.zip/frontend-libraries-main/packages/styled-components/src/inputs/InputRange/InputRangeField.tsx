import { ChangeEvent, forwardRef, useEffect, useState } from 'react';
import styled from 'styled-components';

import { getSpace } from '@/styles/space';
import { UIText } from '@/typography/UIText';

import { InputElement, InputElementProps } from '../Input/InputElement';
import { InputWidth, inputWidthStyles } from '../Input/inputSizes';
import { InputNumberWrapper } from '../InputNumber/InputNumber';

import { InputRangeElement, InputRangeElementProps } from './InputRangeElement';

const InputRangeSlider = styled.div`
  display: flex;
  align-items: center;
  gap: ${getSpace(2)};
  flex-grow: 1;
`;

const config = {
  shouldForwardProp: (p: string) => p !== 'width',
};

const InputRangeWrapper = styled.div.withConfig(config)<{ width?: InputWidth }>`
  display: flex;
  align-items: center;
  gap: ${getSpace(3)};
  ${inputWidthStyles};
`;

export type InputRangeFieldProps = Omit<InputElementProps, 'type'> &
  InputRangeElementProps & {
    unit?: string;
    name: string;
  };

export const InputRangeField = forwardRef<
  HTMLInputElement,
  InputRangeFieldProps
>(
  (
    {
      defaultValue,
      value,
      onChange: onChangeProp,
      invalid,
      unit = '',
      width,
      ...props
    },
    ref,
  ) => {
    const [valueState, setValueState] = useState(value || defaultValue);

    useEffect(() => {
      if (value !== valueState) {
        setValueState(value);
      }
    }, [value]);

    const onChange = (e: ChangeEvent<HTMLInputElement>) => {
      setValueState(e.target.value);
      onChange?.(e);
    };

    return (
      <InputRangeWrapper width={width}>
        <InputRangeSlider>
          <UIText color="fgSubtle">{props.min + unit}</UIText>
          <InputRangeElement
            {...props}
            value={valueState}
            onChange={onChange}
            ref={ref}
          />
          <UIText color="fgSubtle">{props.max + unit}</UIText>
        </InputRangeSlider>

        <InputNumberWrapper role="presentation" align="center" controls={false}>
          <InputElement
            {...props}
            type="number"
            name={props.name + '-number'}
            value={valueState}
            onChange={onChange}
            invalid={invalid}
            suffix={unit}
            width="xs"
          />
        </InputNumberWrapper>
      </InputRangeWrapper>
    );
  },
);

InputRangeField.displayName = 'InputRangeField';
