import { InputHTMLAttributes } from 'react';
import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';

export interface InputRangeElementProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  min: number;
  max: number;
}

const focus = css`
  border: 1px solid white;
  outline: 2px solid ${getColor('bgInfo')};
`;

const thumb = css`
  width: ${getSize(5)};
  height: ${getSize(5)};
  border-radius: 50%;
  background: ${getColor('bgInfo')};
  cursor: pointer;
  filter: drop-shadow(0px 2px 2px ${getColor('borderStrong')}3a);
  box-sizing: content-box;
  transition:
    height 0.1s,
    width 0.1s;
  border: 1px solid transparent;
  outline: 2px solid transparent;

  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }

  &:active {
    width: ${getSize(6.5)};
    height: ${getSize(6.5)};
    ${focus}
  }
`;

const disabled = css`
  width: ${getSize(5)};
  height: ${getSize(5)};
  border: 1px solid transparent;
  outline: 2px solid transparent;
`;

export const InputRangeElement = styled.input.attrs({
  type: 'range',
})<InputRangeElementProps>`
  accent-color: ${getColor('bgInfo')};

  -webkit-appearance: none;
  appearance: none;
  width: 100%;
  height: ${getSize()};
  border: 0px;
  border-radius: ${getRadius()};
  outline: none;
  transition: opacity 200ms;

  &::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    ${thumb}
  }
  &::-moz-range-thumb {
    ${thumb}
  }

  &:focus {
    &::-webkit-slider-thumb {
      ${focus}
    }
    &::-moz-range-thumb {
      ${focus}
    }
  }

  &:disabled {
    opacity: 0.4;

    &::-webkit-slider-thumb {
      ${disabled}
    }
    &::-moz-range-thumb {
      ${disabled}
    }
  }

  ${(props) => {
    const v = props.value || props.defaultValue;

    const fallback = css`
      background: ${getColor('bgSecondary')};
    `;
    if (!v) {
      return fallback;
    }

    const value =
      ((Number(v) - Number(props.min)) /
        (Number(props.max) - Number(props.min))) *
      100;

    if (isNaN(value)) {
      return fallback;
    }
    return css`
      background: linear-gradient(
        to right,
        ${getColor('bgInfo')} 0%,
        ${getColor('bgInfo')} ${value}%,
        ${getColor('bgSecondary')} ${value}%,
        ${getColor('bgSecondary')} 100%
      );
    `;
  }}
`;
