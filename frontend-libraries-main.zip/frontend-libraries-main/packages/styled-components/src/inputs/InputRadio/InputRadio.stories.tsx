import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';
import { useEffect, useState } from 'react';

import FlexMeta from '@/atoms/Flex/Flex.stories';

import { Fieldset } from '../Fieldset';
import { sanitiseStoryProps } from '../utils/stories';

import { InputRadio } from './InputRadio';

const { margin, padding, ...flexArgs } = FlexMeta.argTypes;

export default {
  component: InputRadio,
  args: {
    value: 'true',
    label: 'True or False',
    size: 'md',
    disabled: false,
    invalid: false,
    direction: 'row',
    align: 'center',
    justify: 'flex-start',
    hideLabel: false,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    value: {
      control: {
        type: 'select',
      },
      options: ['true', 'false'],
    },
    size: {
      control: {
        type: 'select',
      },
      options: ['sm', 'md'],
    },
    ...flexArgs,
  },
  parameters: {
    docs: {
      description: {
        component: 'Radio Input component',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof InputRadio>;

type Story = StoryObj<typeof InputRadio>;

export const InputRadioStory: Story = {
  name: 'InputRadio',
  parameters: {
    controls: {
      exclude: [
        'type',
        'before',
        'after',
        'placeholder',
        'readOnly',
        'hideLabel',
        'defaultValue',
      ],
    },
  },
  render: ({ value, label, ...props }) => {
    const [, updateArgs] = useArgs();
    const [valueState, setValueState] = useState(value);
    useEffect(() => {
      updateArgs({ value: valueState });
    }, [valueState]);
    useEffect(() => {
      if (value !== valueState) {
        setValueState(value);
      }
    }, [value]);
    return (
      <Fieldset required label={label}>
        <InputRadio
          {...sanitiseStoryProps(props)}
          name="radio"
          value="true"
          label="True"
          checked={valueState === 'true'}
          onChange={(e) => {
            props.onChange?.(e);
            setValueState('true');
          }}
        />
        <InputRadio
          {...sanitiseStoryProps(props)}
          name="radio"
          value="false"
          label="False"
          checked={valueState === 'false'}
          onChange={(e) => {
            props.onChange?.(e);
            setValueState('false');
          }}
        />
      </Fieldset>
    );
  },
};
