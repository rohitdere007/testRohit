import { forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';

import { CheckedInput } from '../CheckedInput';
import {
  CheckboxBorderProps,
  checkboxBorderStyles,
} from '../InputCheckbox/checkboxBorderStyles';
import { InputCheckboxProps } from '../InputCheckbox/InputCheckbox';

const StyledRadioDot = styled.span.withConfig({
  shouldForwardProp: (propName) => propName !== 'size',
})<Pick<CheckboxBorderProps, 'size'>>`
  background: ${getColor('bgPrimary')};
  border-radius: ${getRadius('full')};
  height: ${getSize(1.5)};
  width: ${getSize(1.5)};
  display: block;

  ${({ size }) =>
    size === 'md' &&
    css`
      height: ${getSize(2)};
      width: ${getSize(2)};
    `}
`;

const RadioBorder = styled.span.withConfig({
  shouldForwardProp: (propName) => !['size', 'invalid'].includes(propName),
})<CheckboxBorderProps>`
  ${checkboxBorderStyles};
  &:has(~ :focus-visible) {
    border-radius: ${getRadius('full')};
  }
  height: ${getSize(4)};
  width: ${getSize(4)};
  padding: 0;
  border-radius: ${getRadius('full')};
  display: flex;
  align-items: center;
  justify-content: center;
  &:has(~ :checked) ${StyledRadioDot} {
    background-color: ${getColor('fgOnDark')};
  }
  ${({ size }) =>
    size === 'md' &&
    css`
      height: ${getSize(5)};
      width: ${getSize(5)};
    `}
`;

export const InputRadio = forwardRef<HTMLInputElement, InputCheckboxProps>(
  ({ size = 'md', ...props }, ref) => (
    <CheckedInput
      {...props}
      ref={ref}
      size={size}
      type="radio"
      input={
        <RadioBorder size={size} invalid={props.invalid}>
          <StyledRadioDot size={size} />
        </RadioBorder>
      }
    />
  ),
);

InputRadio.displayName = 'InputRadio';
