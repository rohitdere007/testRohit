import styled, { css } from 'styled-components';

import { getColor } from '@/styles/color';
import { TextStyles, getUITextStyles } from '@/styles/typography';

export type LabelTextMode = 'optional' | 'required';

export interface LabelTextProps extends Pick<TextStyles, 'size' | 'weight'> {
  required?: boolean;
  mode?: LabelTextMode;
}

export const LabelText = styled.span.withConfig({
  shouldForwardProp: (p) => !['required', 'size', 'weight', 'mode'].includes(p),
})<LabelTextProps>`
  ${({ mode = 'required', required, size = 'md', weight = 'semi-bold' }) => css`
    ${getUITextStyles({ size, weight, color: 'fg' })};

    ${mode === 'required' &&
    required &&
    css`
      &::after {
        content: ' *';
        color: ${getColor('fgCritical')};
      }
    `}

    ${mode === 'optional' &&
    !required &&
    css`
      &::after {
        content: ' (Optional)';
        color: ${getColor('fgSubtle')};
      }
    `}
  `}
`;
