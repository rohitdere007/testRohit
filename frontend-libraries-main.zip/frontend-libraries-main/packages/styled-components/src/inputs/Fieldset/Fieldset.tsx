import { Property } from 'csstype';
import { HTMLAttributes, ReactNode } from 'react';
import styled from 'styled-components';

import { Flex, FlexProps, isFlexPropName } from '@/atoms/Flex';
import { Label } from '@/inputs/Label';
import { LabelText, LabelTextMode } from '@/inputs/LabelText';
import { flex } from '@/styles/flex';
import { getSpace } from '@/styles/space';
import { ScreenReaderText } from '@/typography/ScreenReaderText';
import { UIText } from '@/typography/UIText';

import { FieldWrapper } from '../Field';
import { InputSize } from '../Input';

export interface FieldsetProps
  extends HTMLAttributes<HTMLElement>,
    Omit<FlexProps, 'width'> {
  id?: string;
  label: ReactNode;
  desc?: string;
  children: ReactNode;
  tooltip?: ReactNode;
  message?: ReactNode;
  required?: boolean;
  hideLabel?: boolean;
  direction?: Property.FlexDirection;
  size?: InputSize;
  mode?: LabelTextMode;
}

const Legend = styled.legend`
  margin-bottom: ${getSpace(2)};
`;

const StyledFieldset = styled(Label).attrs({ as: 'fieldset' })`
  border: none;
`;

const InputsWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => !isFlexPropName(p),
})<Pick<FlexProps, 'align' | 'direction' | 'justify' | 'gap'>>`
  ${flex}
  margin-bottom: ${getSpace(0.5)};
  flex-wrap: wrap;
`;

export const Fieldset = ({
  id,
  label,
  desc,
  children,
  required,
  message,
  hideLabel,
  direction = 'row',
  align,
  justify,
  gap = 4,
  tooltip,
  size = 'md',
  mode,
  ...rest
}: FieldsetProps) => (
  <FieldWrapper {...rest}>
    <StyledFieldset>
      <Legend>
        {hideLabel ? (
          <ScreenReaderText>{label}</ScreenReaderText>
        ) : (
          <>
            <Flex gap="1" align="center">
              <LabelText
                required={required}
                mode={mode}
                size={!['md', 'lg', 'xl'].includes(size) ? 'sm' : undefined}
              >
                {label}
              </LabelText>
              {tooltip}
            </Flex>

            {desc && <UIText color="fgSubtle">{desc}</UIText>}
          </>
        )}
      </Legend>
      <InputsWrapper
        direction={direction}
        align={align}
        justify={justify}
        gap={gap}
      >
        {children}
      </InputsWrapper>
    </StyledFieldset>
    {message}
  </FieldWrapper>
);

Fieldset.displayName = 'Fieldset';
