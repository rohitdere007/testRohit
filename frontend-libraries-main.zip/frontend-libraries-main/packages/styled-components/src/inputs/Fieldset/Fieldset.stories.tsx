import { Meta, StoryObj } from '@storybook/react';

import { InputCheckbox } from '../InputCheckbox';
import { InputRadio } from '../InputRadio';
import { SupportText } from '../SupportText/SupportText';
import { sanitiseStoryProps } from '../utils/stories';

import { Fieldset } from './Fieldset';

type Story = StoryObj<typeof Fieldset>;

export default {
  component: Fieldset,
  title: 'inputs/Fieldset (RadioGroup)',
  parameters: {
    docs: {
      description: {
        component:
          "The Fieldset component outputs a fieldset element to wrap inputs within. This is commonly used for checkbox and radio groups as each checkbox or radio will have it's own label. Fieldset's use a legend instead of a label to give context to the group of inputs.",
      },
    },
  },
  args: {
    label: 'Input Label',
    required: false,
  },
  argTypes: {
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description: 'If the input value is required',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    mode: {
      control: {
        type: 'select',
      },
      description:
        'If the legend text should have a * for required fieldsets or (Optional) for optional fieldsets.',
      options: ['required', 'optional'],
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Fieldset>;

export const Checkboxes: Story = {
  parameters: {
    controls: {
      exclude: [
        'type',
        'before',
        'after',
        'placeholder',
        'readOnly',
        'hideLabel',
        'defaultValue',
      ],
    },
  },
  render({ ...props }) {
    return (
      <Fieldset
        {...sanitiseStoryProps(props)}
        message={
          props.message && (
            <SupportText variant="critical">
              {props.message || 'Some sort of validation error'}
            </SupportText>
          )
        }
        label="Checkboxes"
      >
        <InputCheckbox name="checkbox" value="one" label="One" />
        <InputCheckbox name="checkbox" value="two" label="Two" />
        <InputCheckbox name="checkbox" value="three" label="Three" />
      </Fieldset>
    );
  },
};

export const Radios: Story = {
  parameters: {
    docs: {
      description: {
        story:
          '<p>The Fieldset component does not manage your support text for you. it takes a ReactNode as a value for the `message` prop</p>',
      },
    },
  },
  render(props) {
    return (
      <Fieldset
        {...props}
        required
        label="Stay or Go"
        message={
          <SupportText variant="critical">
            Some sort of validation error
          </SupportText>
        }
      >
        <InputRadio
          name="radio"
          value="stay"
          label="Stay"
          size="md"
          defaultChecked
        />
        <InputRadio name="radio" value="go" label="Go" size="md" />
      </Fieldset>
    );
  },
};
