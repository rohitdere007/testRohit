import { forwardRef } from 'react';
import styled, { css } from 'styled-components';

import { Field, FieldProps } from '../Field';
import { BaseInput } from '../Input/BaseInput';
import { InputElement, InputElementProps } from '../Input/InputElement';

type InputDateProps = Omit<FieldProps, 'as'> & Omit<InputElementProps, 'type'>;

const InputDateWrapper = styled.div`
  ${BaseInput}::-webkit-calendar-picker-indicator {
    ${({ theme }) =>
      theme.name !== 'light' &&
      css`
        filter: invert(100%);
      `}
  }
`;

export const InputDate = forwardRef<HTMLInputElement, InputDateProps>(
  (
    { id, label, desc, message, hideLabel, width, tooltip, ...inputProps },
    ref,
  ) => (
    <Field
      id={id}
      label={label}
      desc={desc}
      message={message}
      required={inputProps.required || !!inputProps['aria-required']}
      error={inputProps.error}
      size={inputProps.size}
      hideLabel={hideLabel}
      width={width}
      tooltip={tooltip}
    >
      <InputDateWrapper>
        <InputElement
          ref={ref}
          id={id}
          label={label}
          {...inputProps}
          type="date"
        />
      </InputDateWrapper>
    </Field>
  ),
);

InputDate.displayName = 'InputDate';
