import { RuleSet, css } from 'styled-components';

import { Color, getColor } from '@/styles/color';

const complete = css`
  background-color: ${getColor('bgInfo')};
  color: ${getColor('fgOnDark')};
`;

const current = css`
  background-color: ${getColor('bgPrimary')};
  color: ${getColor('fgInfo')};
  border: 2px solid ${getColor('borderInfo')};
`;

const error = css`
  background-color: ${getColor('bgPrimary')};
  color: ${getColor('fgCritical')};
  border: 5px solid ${getColor('borderCritical')};
`;

const base = css`
  background-color: ${getColor('bgPrimary')};
  color: ${getColor('fgSubtle')};
  border: 1px solid ${getColor('border')};
  /* &:hover {
    border: 1px solid ${getColor('grey.40')};
    background-color: ${getColor('grey.20')};
  } */
`;

export type ProgressVariant = 'base' | 'current' | 'complete' | 'error';

export const progressVariants: Record<ProgressVariant, RuleSet> = {
  base,
  current,
  complete,
  error,
};

export const progressLineVariants: Record<ProgressVariant, Color> = {
  base: 'border',
  current: 'borderInfo',
  complete: 'borderInfo',
  error: 'borderCritical',
};
