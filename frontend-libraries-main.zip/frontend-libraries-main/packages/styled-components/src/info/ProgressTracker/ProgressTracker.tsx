import { ComponentProps } from 'react';
import styled, { css } from 'styled-components';

import {
  ProgressListItem,
  ProgressText,
  ProgressTrackerItem,
  ProgressWrapper,
} from './ProgressTrackerItem';

type ProgressTrackerDirection = 'horizontal' | 'vertical';

export interface ProgressTrackerProps {
  direction?: ProgressTrackerDirection;
}

export const ProgressTrackerOL = styled.ol.withConfig({
  shouldForwardProp: (p) => p !== 'direction',
})<ProgressTrackerProps>`
  display: flex;
  flex-direction: column;
  list-style-type: none;
  justify-content: flex-start;
  align-items: start;

  ${({ direction }) =>
    direction === 'horizontal' &&
    css`
      flex-direction: row;
      ${ProgressWrapper} {
        flex-direction: row;
      }
      ${ProgressListItem} {
        flex-direction: column;
      }
      ${ProgressText} {
        align-items: center;
      }
    `}
`;

export const ProgressTracker = (
  props: ComponentProps<typeof ProgressTrackerOL>,
) => <ProgressTrackerOL {...props} />;

ProgressTracker.Item = ProgressTrackerItem;

ProgressTracker.displayName = 'ProgressTracker';
