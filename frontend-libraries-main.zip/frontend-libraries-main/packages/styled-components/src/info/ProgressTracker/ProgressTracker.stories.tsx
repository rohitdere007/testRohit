import { Meta, StoryObj } from '@storybook/react';
import React from 'react';

import { ProgressTracker } from './ProgressTracker';
import { ProgressTrackerItem } from './ProgressTrackerItem';

export default {
  component: ProgressTracker,
  args: {
    direction: 'horizontal',
  },
  argTypes: {
    direction: {
      options: ['horizontal', 'vertical'],
      control: {
        type: 'select',
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'ProgressTracker (Expandable/Collapsable) content area styled the same as ProgressTracker but following the aria-expanded requirements',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ProgressTracker>;

type Story = StoryObj<typeof ProgressTracker>;

export const Demo: Story = {
  render: (props) => (
    <ProgressTracker {...props}>
      <ProgressTrackerItem
        title="Lorem Ipsum"
        subtitle="subtitle content content"
        variant="complete"
      />
      <ProgressTrackerItem
        title="Lorem Ipsum"
        subtitle="subtitle content content"
        variant="error"
      />
      <ProgressTrackerItem title="Lorem Ipsum" subtitle="subtitle content">
        3
      </ProgressTrackerItem>
    </ProgressTracker>
  ),
};
