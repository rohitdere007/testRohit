import { Meta, StoryObj } from '@storybook/react';
import React from 'react';

import { ProgressTrackerItem } from './ProgressTrackerItem';
import { ProgressVariant, progressVariants } from './progressTrackerVariants';

import { ProgressTracker } from '.';

export default {
  component: ProgressTrackerItem,
  title: 'info/ProgressTracker.Item',
  args: {
    title: 'Step Title',
    subtitle: 'Step Subtitle',
    variant: 'base' as ProgressVariant,
  },
  argTypes: {
    variant: {
      options: Object.keys(progressVariants) as ProgressVariant[],
      control: {
        type: 'select',
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'ProgressTracker (Expandable/Collapsable) content area styled the same as ProgressTracker but following the aria-expanded requirements',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ProgressTrackerItem>;

type Story = StoryObj<typeof ProgressTrackerItem>;

export const Demo: Story = {
  render: (props) => (
    <ProgressTracker>
      <ProgressTrackerItem {...props}>1</ProgressTrackerItem>
      <ProgressTrackerItem {...props}>2</ProgressTrackerItem>
      <ProgressTrackerItem {...props}>3</ProgressTrackerItem>
    </ProgressTracker>
  ),
};
