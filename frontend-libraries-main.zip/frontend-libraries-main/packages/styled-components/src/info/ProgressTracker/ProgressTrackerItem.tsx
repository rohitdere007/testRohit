import { mdiCheck, mdiExclamation } from '@mdi/js';
import styled from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSize } from '@/styles/size';
import { getSpace, getSpacing } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';
import { AsProps } from '@/utils/typescript';

import {
  ProgressVariant,
  progressLineVariants,
  progressVariants,
} from './progressTrackerVariants';

export type ProgressTrackerItemProps<C extends React.ElementType> = {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
  hideContent?: boolean;
  variant?: ProgressVariant;
} & AsProps<C>;

interface ProgressVariants {
  variant?: ProgressVariant;
}

export const ProgressWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const ProgressLine = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'variant',
})<ProgressVariants>`
  content: '';
  flex-grow: 1;
  border: 1px solid
    ${({ variant }) => getColor(progressLineVariants[variant || 'base'])};
`;

export const ProgressListItem = styled.li`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: ${getSpace()};
  min-height: ${getSize(13)};
  &:first-child {
    ${ProgressLine}:first-child {
      border-color: transparent;
    }
  }
  &:last-child {
    ${ProgressLine}:last-child {
      border-color: transparent;
    }
  }
`;

const ProgressCircle = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'variant',
})<ProgressVariants>`
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: ${getRadius('full')};
  width: ${getSize(7)};
  height: ${getSize(7)};
  ${getUITextStyles({ size: 'sm' })}
  line-height: 1;
  text-align: center;

  ${({ variant }) => progressVariants[variant || 'base']};
`;

export const ProgressText = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: center;
  flex-direction: column;
  gap: ${getSpace()};
  padding: ${getSpacing('0 0.5')};
`;

const ProgressTitle = styled.div`
  ${getUITextStyles({ color: 'fg', weight: 'semi-bold' })};
`;

const ProgressSubtitle = styled.div`
  ${getUITextStyles({ color: 'fgSubtle', size: 'sm' })};
`;

const selectCircleContent = (
  variant: ProgressVariant,
  stepCircleContent: React.ReactNode,
) => {
  switch (variant) {
    case 'complete':
      return <Icon icon={mdiCheck} color="fgOnDark" aria-label="Complete: " />;
    case 'error':
      return (
        <Icon icon={mdiExclamation} color="fgCritical" aria-label="Error: " />
      );
    default:
      return stepCircleContent;
  }
};

export const ProgressTrackerItem = <C extends React.ElementType>({
  title,
  subtitle,
  hideContent = false,
  variant = 'base',
  children = '',
  ...rest
}: ProgressTrackerItemProps<C>) => (
  <ProgressListItem aria-label={`${title} ${subtitle}`}>
    <ProgressWrapper>
      <ProgressLine variant={variant} />
      <ProgressCircle {...rest} variant={variant}>
        {selectCircleContent(variant, children)}
      </ProgressCircle>
      <ProgressLine variant={variant} />
    </ProgressWrapper>
    {!hideContent && (
      <ProgressText>
        <ProgressTitle>{title}</ProgressTitle>
        <ProgressSubtitle>{subtitle}</ProgressSubtitle>
      </ProgressText>
    )}
  </ProgressListItem>
);

ProgressTrackerItem.displayName = 'ProgressTracker.Item';
