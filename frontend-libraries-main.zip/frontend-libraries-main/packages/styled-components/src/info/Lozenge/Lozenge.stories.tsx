import * as mdiIcons from '@mdi/js';
import { Meta, StoryObj } from '@storybook/react';

import { Lozenge, lozengeSize } from './Lozenge';

const lozengeVariants = [
  'base',
  'risk',
  'critical',
  'discovery',
  'info',
  'success',
  'warning',
];

export default {
  component: Lozenge,
  args: {
    label: 'critical',
    variant: 'critical',
    emphasis: 'subtle',
    size: 'sm',
    icon: '',
    uppercase: false,
  },
  argTypes: {
    icon: {
      control: {
        type: 'select',
      },
      options: Object.keys(mdiIcons),
      mapping: mdiIcons,
    },
    emphasis: {
      control: {
        type: 'select',
      },
      options: ['outline', 'subtle', 'strong'],
    },
    uppercase: {
      control: { type: 'boolean' },
      description: 'If the text should be uppercase',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    size: {
      control: {
        type: 'select',
      },
      options: Object.keys(lozengeSize),
    },
    variant: {
      control: {
        type: 'select',
      },
      options: lozengeVariants,
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Lozenge component intended for taxonomies',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Lozenge>;

type Story = StoryObj<typeof Lozenge>;

export const Demo: Story = {};
