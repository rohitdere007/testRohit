import styled, { css } from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { TextEllipsis } from '@/atoms/TextEllipsis';
import { Color, getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { Size, getSize } from '@/styles/size';
import { getSpace, getSpacing } from '@/styles/space';
import { getUITextStyles } from '@/styles/typography';

type LozengeVariant =
  | 'base'
  | 'risk'
  | 'critical'
  | 'discovery'
  | 'info'
  | 'success'
  | 'warning';

const borderColors: Record<LozengeVariant, Color> = {
  base: 'borderStrong',
  risk: 'borderRisk',
  critical: 'borderCritical',
  discovery: 'borderDiscovery',
  info: 'borderInfo',
  success: 'borderSuccess',
  warning: 'borderWarning',
};

const fgColors: Record<LozengeVariant, Color> = {
  base: 'fgSubtle',
  risk: 'fgRisk',
  critical: 'fgCritical',
  discovery: 'fgDiscovery',
  info: 'fgInfo',
  success: 'fgSuccess',
  warning: 'fgWarning',
};

const bgSubtleColors: Record<LozengeVariant, Color> = {
  base: 'bgSecondary',
  risk: 'bgRiskSubtle',
  critical: 'bgCriticalSubtle',
  discovery: 'bgDiscoverySubtle',
  info: 'bgInfoSubtle',
  success: 'bgSuccessSubtle',
  warning: 'bgWarningSubtle',
};

const bgStrongColors: Record<LozengeVariant, Color> = {
  base: 'bgInverse',
  risk: 'bgRisk',
  critical: 'bgCritical',
  discovery: 'bgDiscovery',
  info: 'bgInfo',
  success: 'bgSuccess',
  warning: 'bgWarning',
};

type LozengeEmphasis = 'outline' | 'subtle' | 'strong';

export const lozengeSize: Record<string, Size> = {
  sm: 5,
  md: 6,
  lg: 7,
};

type LozengeSize = keyof typeof lozengeSize;

interface LozengeWrapperProps {
  emphasis?: LozengeEmphasis;
  size?: LozengeSize;
  variant?: LozengeVariant;
  uppercase?: boolean;
}

export interface LozengeProps extends LozengeWrapperProps {
  icon?: string;
  label: string;
}

const variantStyles = ({ variant, emphasis }: LozengeWrapperProps) => {
  const v: LozengeVariant = variant || 'base';
  switch (emphasis) {
    case 'subtle':
      return css`
        color: ${getColor(fgColors[v])};
        background-color: ${getColor(bgSubtleColors[v])};
      `;
    case 'strong':
      return css`
        color: ${getColor(
          ['risk', 'warning'].includes(v) ? 'fgOnLight' : 'fgOnDark',
        )};
        background-color: ${getColor(bgStrongColors[v])};
      `;
    case 'outline':
    default:
      return css`
        background: transparent;
        border: 1px solid ${getColor(borderColors[v])};
        color: ${getColor(fgColors[v])};
      `;
  }
};

const LozengeWrapper = styled.div.withConfig({
  shouldForwardProp: (propName) =>
    !['size', 'variant', 'emphasis', 'uppercase'].includes(propName),
})<LozengeWrapperProps>`
  box-sizing: border-box;
  display: inline-flex;
  max-width: 250px;

  flex-direction: row;
  align-items: center;
  overflow: hidden;
  gap: ${getSpacing('1')};
  border-radius: ${getRadius('full')};
  ${getUITextStyles({ size: 'sm', weight: 'semi-bold' })};
  text-transform: ${({ uppercase }) => (uppercase ? 'uppercase' : 'none')};
  height: ${({ size }) => getSize(lozengeSize[size || 'md'])};
  padding: 0 ${getSpace(2)};

  ${variantStyles};
`;

const LozengeLabel = styled(TextEllipsis)`
  text-align: center;
  min-width: ${getSpace(2)};
`;

export const Lozenge = ({ label, icon, ...props }: LozengeProps) => (
  <LozengeWrapper {...props}>
    {icon && <Icon icon={icon} />}
    <LozengeLabel>{label}</LozengeLabel>
  </LozengeWrapper>
);
