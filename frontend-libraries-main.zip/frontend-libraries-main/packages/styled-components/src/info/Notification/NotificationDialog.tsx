import styled from 'styled-components';

import { FlexProps } from '@/atoms/Flex';
import {
  BaseDialogProps,
  Dialog,
  DialogElement,
  DialogProps,
} from '@/modals/Dialog';

import { NotificationClose } from './NotificationClose';
import {
  NotificationVariantProps,
  notificationContainerStyles,
} from './NotificationContainer';
import { NotificationLayout } from './NotificationLayout';

type NotificationElementProps = DialogProps & NotificationVariantProps;

const NotificationElement = styled(DialogElement).withConfig({
  shouldForwardProp: (p) => p !== 'variant' && p !== 'shadow',
})<NotificationElementProps>`
  ${notificationContainerStyles};
`;

type NotificationProps = NotificationVariantProps &
  Omit<BaseDialogProps<typeof NotificationElement>, 'inline'> & {
    title?: string;
  } & FlexProps;

export const NotificationDialog = ({
  children,
  title,
  variant = 'info',
  align,
  ...props
}: NotificationProps) => (
  <Dialog
    aria-label={title}
    {...props}
    as={NotificationElement}
    variant={variant}
    inline
  >
    <NotificationLayout align={align} variant={variant}>
      {children}
      <NotificationClose />
    </NotificationLayout>
  </Dialog>
);

NotificationDialog.displayName = 'Notification.Dialog';
