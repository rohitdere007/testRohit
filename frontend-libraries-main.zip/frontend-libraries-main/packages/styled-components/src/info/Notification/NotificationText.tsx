import styled from 'styled-components';

export const NotificationText = styled.span`
  display: -webkit-box;
  max-width: 100%;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

NotificationText.displayName = 'Notification.Text';
