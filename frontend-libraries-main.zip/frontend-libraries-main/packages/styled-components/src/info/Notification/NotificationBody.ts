import styled from 'styled-components';

import { Flex } from '@/atoms/Flex';
import { getUITextStyles } from '@/styles/typography';

export const NotificationBody = styled(Flex)`
  height: 100%;
  width: 100%;
  flex-grow: 1;
  flex-direction: column;
  ${getUITextStyles({ size: 'md' })};
`;

NotificationBody.displayName = 'Notification.Body';
