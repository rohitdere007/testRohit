import { FlexProps } from '@/atoms/Flex';
import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { ModalCloseContext } from '@/modals/Modal';

import { NotificationBody } from './NotificationBody';
import { NotificationClose } from './NotificationClose';
import {
  NotificationContainer,
  NotificationContainerProps,
} from './NotificationContainer';
import { NotificationDialog } from './NotificationDialog';
import { NotificationIcon } from './NotificationIcon';
import { NotificationText } from './NotificationText';
import { NotificationTitle } from './NotificationTitle';

type NotificationProps = Partial<NotificationContainerProps> & FlexProps;

const onCloseFallback = () => void 0;

export const Notification = ({
  children,
  title,
  variant = 'info',
  align,
  open: openProp = true,
  delay = 500,
  onClose = onCloseFallback,
  ...props
}: NotificationProps) => {
  const openState = useDebouncedValue(openProp, !openProp ? 500 : 1);
  if (!openProp && !openState) {
    return null;
  }

  return (
    <ModalCloseContext.Provider value={onClose}>
      <NotificationContainer
        role="status"
        aria-label={title}
        variant={variant}
        open={openProp && openState}
        delay={delay}
        {...props}
      >
        <NotificationIcon variant={variant} />
        {children}
      </NotificationContainer>
    </ModalCloseContext.Provider>
  );
};

Notification.displayName = 'Notification';

Notification.Title = NotificationTitle;
Notification.Text = NotificationText;
Notification.Body = NotificationBody;
Notification.Close = NotificationClose;
Notification.Dialog = NotificationDialog;
