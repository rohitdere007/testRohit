import {
  mdiAlertCircleOutline,
  mdiAlertOutline,
  mdiCheckCircleOutline,
  mdiInformationOutline,
} from '@mdi/js';
import { ReactNode } from 'react';
import styled from 'styled-components';

import { Icon } from '@/atoms/Icon';
import { LoadingSpinner } from '@/info/LoadingSpinner';
import { Color } from '@/styles/color';

export type NotificationVariant =
  | 'info'
  | 'critical'
  | 'warning'
  | 'success'
  | 'loading';

export const notificationFgColor: Record<NotificationVariant, Color> = {
  info: 'fgInfo',
  critical: 'fgCritical',
  warning: 'fgWarning',
  success: 'fgSuccess',
  loading: 'fgInfo',
};

export const notificationIcon: Record<NotificationVariant, ReactNode> = {
  info: mdiInformationOutline,
  critical: mdiAlertCircleOutline,
  warning: mdiAlertOutline,
  success: mdiCheckCircleOutline,
  loading: <LoadingSpinner size="sm" />,
};

const NotificationIconWrapper = styled.div`
  margin-top: 2px;
  margin-bottom: 4px;
  margin-left: 2px;
`;

export interface NotificationIconProps {
  variant?: NotificationVariant;
}

export const NotificationIcon = ({
  variant = 'info',
}: NotificationIconProps) => (
  <NotificationIconWrapper>
    <Icon
      icon={notificationIcon[variant]}
      color={notificationFgColor[variant]}
      size="md"
    />
  </NotificationIconWrapper>
);

NotificationIcon.displayName = 'Notification.Icon';
