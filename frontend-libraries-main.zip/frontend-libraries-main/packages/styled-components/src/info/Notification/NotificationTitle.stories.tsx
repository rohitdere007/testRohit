import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Button } from '@/buttons/Button';

import { Notification } from './Notification';

export default {
  component: Notification.Title,
  title: 'info/Notification.Title',
  args: {
    as: 'h1',
    title: 'Notification Title',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Notification.Title` provides uniform props with other `Title` components. It requires a `title` value. It is important to specify the `as` prop to specify a heading level to give context to screen readers.',
      },
    },
  },
  argTypes: {
    title: {
      control: {
        type: 'text',
      },
      description: 'The main title text',
      table: {
        type: { summary: 'string' },
      },
    },
    as: {
      control: {
        type: 'select',
      },
      description: 'the html element the title text should be contained within',
      defaultValue: 'span',
      table: {
        type: {
          summary: ['span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].join(
            ' | ',
          ),
        },
        defaultValue: { summary: '"span"' },
      },
      options: ['span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Notification.Title>;

type Story = StoryObj<typeof Notification.Title>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);
    const close = () => setOpen(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open Notification</Button>
        <Notification open={open} onClose={close}>
          <Notification.Body>
            <Notification.Title {...props} />
          </Notification.Body>
        </Notification>
      </>
    );
  },
};
