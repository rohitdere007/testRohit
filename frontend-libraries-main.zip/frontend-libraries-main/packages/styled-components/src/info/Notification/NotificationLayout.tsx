import { PropsWithChildren } from 'react';

import { Flex, FlexProps } from '@/atoms/Flex';

import { NotificationIcon, NotificationVariant } from './NotificationIcon';

interface NotificationLayoutProps
  extends Pick<FlexProps, 'align'>,
    PropsWithChildren {
  variant: NotificationVariant;
}

export const NotificationLayout = ({
  align,
  children,
  variant,
}: NotificationLayoutProps) => (
  <Flex gap={3} direction="row" align={align}>
    <NotificationIcon variant={variant} />
    {children}
  </Flex>
);
