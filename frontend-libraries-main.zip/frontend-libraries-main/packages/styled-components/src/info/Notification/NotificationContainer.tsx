import { Property } from 'csstype';
import { PropsWithChildren } from 'react';
import styled, { css } from 'styled-components';

import { Color, getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { getSpace } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';

import { NotificationVariant, notificationFgColor } from './NotificationIcon';

export const notificationBgColor: Record<NotificationVariant, Color> = {
  info: 'bgInfoSubtlest',
  critical: 'bgCriticalSubtlest',
  warning: 'bgWarningSubtlest',
  success: 'bgSuccessSubtlest',
  loading: 'bgInfoSubtlest',
};

export interface NotificationVariantProps {
  variant?: NotificationVariant;
  shadow?: boolean;
}

export interface NotificationContainerProps
  extends PropsWithChildren<NotificationVariantProps> {
  open?: boolean;
  onClose?: (value?: string) => void;
  delay: number;
  title?: string;
  align?: Property.AlignItems;
}

export const notificationContainerStyles = css<NotificationVariantProps>`
  ${({ shadow }) =>
    shadow &&
    css`
      box-shadow: 0px 4px 16px 0px ${getColor('borderStrong')}3a;
    `}

  border-radius: ${getRadius()};
  border: none;
  padding: ${getSpace(3)};
  max-width: 100%;
  ${getBodyTextStyles()};
  ${({ variant = 'info' }) => css`
    border-left: 3px solid ${getColor(notificationFgColor[variant])};
    background: ${getColor(notificationBgColor[variant])};
    outline: 1px solid ${getColor(notificationFgColor[variant])};
  `}
`;

const isNotificationContainerProp = (p: string) =>
  ['open', 'onClose', 'variant', 'shadow', 'title'].includes(p);

export const NotificationContainer = styled.div.withConfig({
  shouldForwardProp: (p) => !isNotificationContainerProp(p),
})<NotificationContainerProps>`
  ${({ open = true, delay = 0, align = 'flex-start' }) => css`
    clip: rect(auto, auto, 0, auto);
    width: auto;
    height: auto;
    overflow: hidden;
    position: relative;
    max-height: ${open ? '500px' : 0};
    opacity: ${open ? 1 : 0};

    transition:
      max-height ${delay}ms ease-in-out,
      opacity ${delay}ms ease-in-out;

    @media (prefers-reduced-motion) {
      transition: opacity ${delay}ms ease-in-out;
    }

    display: flex;
    flex-direction: row;
    align-items: ${align};
    gap: ${getSpace(3)};
  `}

  ${notificationContainerStyles};
`;
