import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Flex } from '@/atoms/Flex';
import { Button } from '@/buttons/Button';
import { LinkButton } from '@/buttons/LinkButton';
import { UIText } from '@/typography/UIText';

import FlexStories from '../../atoms/Flex/Flex.stories';

import { Notification } from './Notification';
import { NotificationDialog } from './NotificationDialog';
import { notificationIcon } from './NotificationIcon';

const { align } = FlexStories.argTypes;

export default {
  component: NotificationDialog,
  title: 'info/Notification.Dialog',
  parameters: {
    docs: {
      description: {
        component: 'Wrapper around HTML dialog element with card styling.',
      },
    },
  },
  args: {
    variant: 'info',
    children: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit....',
  },
  argTypes: {
    variant: {
      control: {
        type: 'select',
      },
      description: 'The variant of the notification',
      options: Object.keys(notificationIcon),
    },
    align,
  },
} satisfies Meta<typeof NotificationDialog>;

type Story = StoryObj<typeof NotificationDialog>;

export const Demo: Story = {
  render({ children, ...props }) {
    const [open, setOpen] = useState(true);
    return (
      <>
        <Button m="0 0 3" onClick={() => setOpen((prev) => !prev)}>
          Toggle Dialog
        </Button>

        <NotificationDialog
          {...props}
          open={open}
          onClose={() => setOpen(false)}
        >
          <Notification.Body>
            <Notification.Title title="Notification Title" />
            {children}
            <LinkButton>Read More</LinkButton>
          </Notification.Body>
        </NotificationDialog>
      </>
    );
  },
};

export const Inline: Story = {
  args: {
    align: 'center',
  },
  render({ children, ...props }) {
    const [open, setOpen] = useState(true);
    return (
      <>
        <Button m="0 0 3" onClick={() => setOpen((prev) => !prev)}>
          Toggle Dialog
        </Button>

        <NotificationDialog
          {...props}
          open={open}
          onClose={() => setOpen(false)}
        >
          <Notification.Body>
            <UIText>
              <UIText weight="bold">Notifiation Title </UIText>
              {children} <LinkButton>Read More</LinkButton>
            </UIText>
          </Notification.Body>
        </NotificationDialog>
      </>
    );
  },
};

export const EndLink: Story = {
  args: {
    align: 'center',
  },
  render({ children, ...props }) {
    const [open, setOpen] = useState(true);
    return (
      <>
        <Button m="0 0 3" onClick={() => setOpen((prev) => !prev)}>
          Toggle Dialog
        </Button>

        <NotificationDialog
          {...props}
          open={open}
          onClose={() => setOpen(false)}
        >
          <Notification.Body>
            <Flex justify="space-between" width="100%">
              <UIText>
                <UIText weight="bold">Notification Title </UIText>
                {children}
              </UIText>
              <LinkButton>Read More</LinkButton>
            </Flex>
          </Notification.Body>
        </NotificationDialog>
      </>
    );
  },
};
