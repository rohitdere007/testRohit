import { mdiClose } from '@mdi/js';

import { PlainIconButton } from '@/buttons/PlainIconButton';
import { useModalCloseContext } from '@/modals/Modal/ModalCloseContext';

export type ModalCloseProps = React.ButtonHTMLAttributes<HTMLButtonElement>;

export const NotificationClose: React.FC<ModalCloseProps> = ({
  children,
  onClick,
  ...props
}) => {
  const close = useModalCloseContext();

  return (
    <>
      <PlainIconButton
        aria-label="Close"
        type="button"
        onClick={(e) => {
          close?.();
          onClick?.(e);
        }}
        icon={mdiClose}
        size="md"
        {...props}
      />
    </>
  );
};

NotificationClose.displayName = 'Notification.Close';
