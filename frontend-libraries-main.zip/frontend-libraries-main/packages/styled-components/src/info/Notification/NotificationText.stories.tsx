import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { Notification } from './Notification';
import { NotificationText } from './NotificationText';

export default {
  component: Notification.Text,
  title: 'info/Notification.Text',
  args: {
    children:
      'Space, the final frontier. These are the voyages of the Starship',
  },
  parameters: {
    docs: {
      description: {
        component:
          'The `Notification.Body` provides padding uniform to the `Notification.Header`. Most commonly it would be used within a `Notification`.',
      },
    },
  },
  argTypes: {
    children: {
      control: undefined,
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof NotificationText>;

type Story = StoryObj<typeof NotificationText>;

export const Demo: Story = {
  render: (props) => {
    const [open, setOpen] = useState(true);
    const close = () => setOpen(false);
    return (
      <>
        <Notification open={open} onClose={close} align="center">
          <Notification.Body>{props.children}</Notification.Body>
        </Notification>
      </>
    );
  },
};
