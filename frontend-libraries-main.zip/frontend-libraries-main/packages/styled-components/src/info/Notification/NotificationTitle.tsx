import { UIText } from '@/typography/UIText';

export interface NotificationTitleProps {
  title: string;
  as?: string;
}

export const NotificationTitle = ({
  title,
  as,
  ...props
}: NotificationTitleProps) => (
  <UIText {...props} weight="semi-bold" size="md">
    {title}
  </UIText>
);

NotificationTitle.displayName = 'Notification.Title';
