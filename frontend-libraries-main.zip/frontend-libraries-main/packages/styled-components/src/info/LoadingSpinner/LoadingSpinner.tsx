import styled, { css } from 'styled-components';

import { Color, getColor } from '@/styles/color';

export const spinnerSizes = {
  xs: '16px',
  sm: '18px',
  md: '24px',
};

// button variants
export const spinnerVariants: Record<string, Color> = {
  base: 'fg',
  primary: 'fgOnDark',
  success: 'fgOnDark',
  critical: 'fgOnDark',
  warning: 'fgOnLight',
  discovery: 'fgOnDark',
};

export interface LoadingSpinnerProps {
  variant?: keyof typeof spinnerVariants | Color;
  size?: keyof typeof spinnerSizes;
}

const config = {
  shouldForwardProp: (propName: string) =>
    !['size', 'variant'].includes(propName),
};

export const LoadingWrapper = styled.div.withConfig(config).attrs({
  'aria-label': 'Loading...',
})<LoadingSpinnerProps>`
  ${({ variant = 'fgInfo', size = 'md' }) => css`
    width: ${spinnerSizes[size]};
    height: ${spinnerSizes[size]};
    color: ${getColor(spinnerVariants[variant] || variant)};

    svg {
      animation: rotate 2s linear infinite;
      width: ${spinnerSizes[size]};
      height: ${spinnerSizes[size]};

      & circle {
        stroke-linecap: round;
        animation: dash 1.5s ease-in-out infinite;
      }
    }

    @keyframes rotate {
      100% {
        transform: rotate(360deg);
      }
    }

    @keyframes dash {
      0% {
        stroke-dasharray: 1, 150;
        stroke-dashoffset: 0;
      }
      50% {
        stroke-dasharray: 90, 150;
        stroke-dashoffset: -35;
      }
      100% {
        stroke-dasharray: 90, 150;
        stroke-dashoffset: -124;
      }
    }
  `}
`;

export const LoadingSpinner = ({ variant, size }: LoadingSpinnerProps) => (
  <LoadingWrapper variant={variant} size={size}>
    <svg viewBox="0 0 50 50">
      <circle
        cx="25"
        cy="25"
        r="20"
        fill="none"
        strokeWidth="5"
        stroke="currentColor"
      ></circle>
    </svg>
  </LoadingWrapper>
);
