import { Meta, StoryObj } from '@storybook/react';

import {
  LoadingSpinner,
  spinnerSizes,
  spinnerVariants,
} from './LoadingSpinner';

export default {
  component: LoadingSpinner,
  parameters: {
    docs: {
      description: {
        component: 'Loading Spinner component',
      },
    },
    actions: {
      handles: ['onRemove', 'onClick'],
    },
  },
  args: {
    size: 'md',
  },
  argTypes: {
    variant: {
      description: 'The color variant of the spinner',
      table: {
        type: {
          summary: Object.keys(spinnerVariants).join(' | '),
        },
        defaultValue: { summary: '' },
      },
      control: {
        type: 'select',
      },
      options: Object.keys(spinnerVariants),
    },
    size: {
      description: 'The size of the spinner',
      defaultValue: 'base',
      table: {
        type: {
          summary: Object.keys(spinnerSizes).join(' | '),
        },
        defaultValue: { summary: '"base"' },
      },
      control: {
        type: 'select',
      },
      options: Object.keys(spinnerSizes),
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof LoadingSpinner>;

type Story = StoryObj<typeof LoadingSpinner>;

export const Spinner: Story = {};
