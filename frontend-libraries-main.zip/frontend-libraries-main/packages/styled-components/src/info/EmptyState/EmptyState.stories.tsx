import { Meta, StoryObj } from '@storybook/react';

import { Button } from '@/buttons/Button';
import {
  SvgCall,
  SvgComplete,
  SvgError,
  SvgFolder,
  SvgFolderEmpty,
  SvgIdCard,
  SvgLaptop,
  SvgLocation,
  SvgMessage,
  SvgNoResults,
  SvgNotFound,
  SvgOnboarding,
  SvgPhone,
  SvgProtection,
  SvgResearch,
  SvgTablet,
  SvgUnauthorized,
  SvgUnderConstruction,
} from '@/svgs';

import { EmptyState } from './EmptyState';

export default {
  component: EmptyState,
  args: {
    image: 'SvgNoResults',
    title: 'No bill of materials',
    message: 'Add a bill of materials to your project',
    footer: '',
  },
  argTypes: {
    title: {
      control: { type: 'text' },
      description: 'The title of the message',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'The contents of the message',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    image: {
      control: {
        type: 'select',
      },
      options: [
        'SvgCall',
        'SvgComplete',
        'SvgError',
        'SvgFolder',
        'SvgFolderEmpty',
        'SvgIdCard',
        'SvgLaptop',
        'SvgLocation',
        'SvgMessage',
        'SvgNotFound',
        'SvgNoResults',
        'SvgOnboarding',
        'SvgPhone',
        'SvgProtection',
        'SvgResearch',
        'SvgTablet',
        'SvgUnauthorized',
        'SvgUnderConstruction',
        'None',
        'Image',
      ],
      mapping: {
        SvgCall: <SvgCall />,
        SvgComplete: <SvgComplete />,
        SvgError: <SvgError />,
        SvgFolder: <SvgFolder />,
        SvgFolderEmpty: <SvgFolderEmpty />,
        SvgIdCard: <SvgIdCard />,
        SvgLaptop: <SvgLaptop />,
        SvgLocation: <SvgLocation />,
        SvgMessage: <SvgMessage />,
        SvgNotFound: <SvgNotFound />,
        SvgNoResults: <SvgNoResults />,
        SvgOnboarding: <SvgOnboarding />,
        SvgPhone: <SvgPhone />,
        SvgResearch: <SvgResearch />,
        SvgTablet: <SvgTablet />,
        SvgProtection: <SvgProtection />,
        SvgUnauthorized: <SvgUnauthorized />,
        SvgUnderConstruction: <SvgUnderConstruction />,
        None: null,
        Image: <img src="/images/fine.png" alt="This is fine." width="200px" />,
      },
      description: 'The image for the message',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    actions: {
      control: false,
      description: 'The description of the message',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    footer: {
      control: { type: 'text' },
      description: 'Optional message after the actions',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  parameters: {
    layout: 'flex',
    docs: {
      description: {
        component:
          'When providing a full page message, any ReactNode can be passed to each of the prop to be displayed on the page.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof EmptyState>;

type Story = StoryObj<typeof EmptyState>;

export const Demo: Story = {
  args: {},
  render(props) {
    return (
      <EmptyState
        {...props}
        actions={
          <>
            <Button>Back</Button>
            <Button variant="primary">Add</Button>
          </>
        }
      />
    );
  },
};

export const WithFooter: Story = {
  args: {
    footer: 'The quick brown fox jumped over the lazy dog.',
  },
  render(props) {
    return (
      <EmptyState
        {...props}
        actions={
          <>
            <Button>Back</Button>
            <Button variant="primary">Add</Button>
          </>
        }
      />
    );
  },
};
