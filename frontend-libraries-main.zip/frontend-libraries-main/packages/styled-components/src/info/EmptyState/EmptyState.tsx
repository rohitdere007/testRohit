import { ElementType, ReactNode } from 'react';
import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getSpace } from '@/styles/space';
import { BodyText } from '@/typography/BodyText';
import { HeadingText } from '@/typography/HeadingText';

const EmptyStateContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  background: ${getColor('bgPrimary')};
  color: ${getColor('fgSubtle')};
  height: 100%;
  width: 100%;
  text-align: center;
`;

const EmptyStateWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: ${getSpace(4)};
  align-items: center;
  padding: ${getSpace(8)};
  height: auto;
  width: 400px;
  max-width: 100%;
  box-sizing: border-box;
`;

const EmptyStateActions = styled.div`
  display: flex;
  flex-direction: row;
  gap: ${getSpace(2)};
`;

const EmptyStateImage = styled.div`
  max-width: 80%;
  max-height: 80%;
  margin-bottom: ${getSpace(2)};
  svg,
  img {
    max-width: 250px;
    max-height: 150px;
    width: auto;
    height: auto;
    display: block;
  }
`;

export interface EmptyStateProps {
  title: ReactNode;
  titleAs?: ElementType;
  message: ReactNode;
  image?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
}

export const EmptyState = ({
  title,
  titleAs,
  message,
  image,
  actions,
  footer,
}: EmptyStateProps) => (
  <EmptyStateContainer>
    <EmptyStateWrapper>
      <EmptyStateImage>{image}</EmptyStateImage>
      <HeadingText size="sm" as={titleAs} weight="semi-bold" color="fg">
        {title}
      </HeadingText>
      <BodyText color="fgSubtle">{message}</BodyText>
      {actions && <EmptyStateActions>{actions}</EmptyStateActions>}
      {footer && (
        <BodyText color="fgSubtle" size="sm">
          {footer}
        </BodyText>
      )}
    </EmptyStateWrapper>
  </EmptyStateContainer>
);
