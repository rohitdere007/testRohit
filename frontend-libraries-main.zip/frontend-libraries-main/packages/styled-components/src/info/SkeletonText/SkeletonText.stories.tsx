import { Meta, StoryObj } from '@storybook/react';

import { SkeletonText } from './SkeletonText';

export default {
  component: SkeletonText,
  args: {
    height: undefined,
    isLoading: true,
    spacing: 2,
    noOfLines: 4,
  },
  argTypes: {
    height: {
      control: 'text',
      description:
        'If not specified the height will match any wrapped (child) elements, if there are none then height must be specified in px',
      defaultValue: { summary: 'undefined' },
    },
    isLoading: {
      description:
        'If false the component will not render. Useful for data fetching',
      defaultValue: { summary: 'true' },
    },
    noOfLines: {
      description: 'The number of lines to render',
      defaultValue: 4,
    },
    spacing: {
      description: 'Spacing between the lines, references the space scale',
      defaultValue: 2,
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'The foundational text skeletonText component. This component can be used as a standalone component or to wrap components which load data.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof SkeletonText>;

type Story = StoryObj<typeof SkeletonText>;

export const Demo: Story = {
  render: (props) => (
    <SkeletonText {...props}>
      <div>Loaded child component</div>
    </SkeletonText>
  ),
};
