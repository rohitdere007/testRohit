export * from './SkeletonText';
