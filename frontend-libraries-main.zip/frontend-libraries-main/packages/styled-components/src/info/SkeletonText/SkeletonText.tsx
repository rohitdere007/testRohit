import { styled } from 'styled-components';

import { Space, getSpace } from '@/styles/space';

import { Skeleton, SkeletonProps } from '../Skeleton/Skeleton';

export interface SkeletonTextProps {
  spacing?: Space;
  noOfLines?: number;
  height?: SkeletonProps['height'];
  isLoading?: SkeletonProps['isLoading'];
}

const getWidth = (index: number, noOfLines: number) => {
  if (noOfLines > 1) {
    return index + 1 === [...Array(noOfLines).keys()].length ? '80%' : '100%';
  }
  return '100%';
};

const SkeletonWrapper = styled.div<SkeletonTextProps>`
  margin-top: ${({ spacing }) => getSpace(spacing || '2')};
`;

export const SkeletonText = ({
  height = '10px',
  isLoading = true,
  noOfLines = 4,
  spacing,
}: SkeletonTextProps) => {
  if (!isLoading) {
    return null;
  }

  return (
    <>
      {[...Array(noOfLines).keys()].map((_, i) => (
        <SkeletonWrapper spacing={spacing} key={i}>
          <Skeleton
            isLoading={isLoading}
            height={height}
            width={getWidth(i, noOfLines)}
          />
        </SkeletonWrapper>
      ))}
    </>
  );
};
