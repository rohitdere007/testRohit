import { theme } from '@nationalgrid-engineering/styled-theme';
import { Meta, StoryObj } from '@storybook/react';

import { Skeleton } from './Skeleton';

export default {
  component: Skeleton,
  args: {
    height: undefined,
    width: '100%',
    isLoading: true,
    radius: undefined,
  },
  argTypes: {
    height: {
      control: 'text',
      description:
        'If not specified the height will match any wrapped (child) elements, if there are none then height must be specified',
      defaultValue: { summary: 'fit-content' },
    },
    width: {
      control: 'text',
      description:
        'If not specified, the width will default to the width of any child components',
      defaultValue: { summary: 'fit-content' },
    },
    maxWidth: {
      control: 'text',
      description:
        'The max-width property sets the maximum width of an element. It prevents the used value of the width property from becoming larger than the value specified by max-width',
      defaultValue: { summary: 'undefined' },
    },
    isLoading: {
      description:
        'If false the component will just render any wrapped (child) elements. Useful for data fetching',
      defaultValue: { summary: 'true' },
    },
    animationWidth: {
      description:
        'This value should not need to be adjusted (unless the skeleton is more than 1000px wide). This prop must be passed as a number. The animation internally requires a pixel value for width.',
      defaultValue: { summary: '1000px' },
    },
    aspectRatio: {
      control: 'text',
      description:
        'When passing an image as a child, the aspect ratio value should be passed in order to set the correct height',
      defaultValue: { summary: 'undefined' },
    },
    radius: {
      control: { type: 'select' },
      options: Object.keys(theme.radii),
      description:
        'Use the radius property to adjust the shape of the skeleton to match UI elements that are loading',
      defaultValue: { summary: 'undefined' },
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          'The foundational text skeleton component. This component can be used as a standalone component or to wrap components which load data.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Skeleton>;

type Story = StoryObj<typeof Skeleton>;

export const Demo: Story = {
  render: (props) => (
    <Skeleton {...props}>
      <div>Loading Elements wrapped</div>
      <div>Wont be visible</div>
    </Skeleton>
  ),
};
