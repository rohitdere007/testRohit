import { Property } from 'csstype';
import { css, styled } from 'styled-components';

import { getColor } from '@/styles/color';
import { height } from '@/styles/height';
import { Radii, getRadius } from '@/styles/radius';
import { maxWidth, width } from '@/styles/width';

export interface SkeletonProps {
  height?: Property.Height;
  width?: Property.Width;
  maxWidth?: Property.MaxWidth;
  radius?: Radii;
  aspectRatio?: Property.AspectRatio;
  animationWidth?: number;
  children?: React.ReactNode;
  isLoading?: boolean;
}

const SkeletonAnimation = styled.div.withConfig({
  shouldForwardProp: (p) =>
    !['width', 'height', 'radius', 'aspectRatio', 'animationWidth'].includes(p),
})<SkeletonProps>`
  ${height}
  @keyframes shimmerAnimation {
    0% {
      background-position-x: -${({ animationWidth }) => `${animationWidth}px`};
    }

    100% {
      background-position-x: ${({ animationWidth }) => `${animationWidth}px`};
    }
  }
  ${({ aspectRatio = 'auto' }) =>
    aspectRatio
      ? css`
          aspect-ratio: ${aspectRatio};
        `
      : css`
          height: fit-content;
        `}
  width: fit-content;
  ${width}
  ${maxWidth}
  border-radius: ${({ radius }) => (radius ? getRadius(radius) : 0)};
  background-size: ${({ animationWidth }) => `${animationWidth}px`} 100%;
  background-color: ${getColor('bgSecondary')};
  background-image: linear-gradient(
    to right,
    ${getColor('bgSecondary')} 0,
    ${getColor('bg')} 23%,
    ${getColor('bg')} 27%,
    ${getColor('bgSecondary')} 50%
  );
  background-repeat: no-repeat;
  animation-name: shimmerAnimation;
  animation-duration: 1.5s;
  animation-iteration-count: infinite;
  animation-delay: inherit;
  animation-timing-function: linear;

  box-shadow: none;
  background-clip: padding-box;
  cursor: default;
  color: transparent;
  pointer-events: none;
  user-select: none;
`;

export const Skeleton = ({
  animationWidth = 1000,
  isLoading = true,
  children,
  ...props
}: SkeletonProps) => {
  if (!isLoading) {
    return <>{children}</>;
  }
  return (
    <SkeletonAnimation {...props} animationWidth={animationWidth}>
      {children}
    </SkeletonAnimation>
  );
};
