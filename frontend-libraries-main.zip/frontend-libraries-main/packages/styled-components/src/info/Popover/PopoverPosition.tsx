import styled, { css } from 'styled-components';

import { getSpace } from '@/styles/space';

export type PopoverPositionType = 'top' | 'bottom' | 'left' | 'right';

export interface PopoverPositionProps {
  position?: PopoverPositionType;
  align?: 'start' | 'center' | 'end';
}

export const isPopoverPositionProps = (p: string) =>
  ['position', 'align'].includes(p);

export const PopoverPosition = styled.div.withConfig({
  shouldForwardProp: (p) => !isPopoverPositionProps(p),
})<PopoverPositionProps>`
  position: absolute;
  ${({ position, align }) => {
    switch (align) {
      case 'start':
        switch (position) {
          case 'right':
            return css`
              left: ${getSpace()};
            `;
          case 'left':
            return css`
              right: ${getSpace()};
            `;
          case 'top':
            return css`
              bottom: ${getSpace()};
            `;
          case 'bottom':
          default:
            return css`
              top: ${getSpace()};
            `;
        }

      case 'end':
        switch (position) {
          case 'right':
            return css`
              bottom: 0;
              left: ${getSpace()};
            `;
          case 'left':
            return css`
              bottom: 0;
              right: ${getSpace()};
            `;
          case 'top':
            return css`
              right: 0;
              bottom: ${getSpace()};
            `;
          case 'bottom':
          default:
            return css`
              right: 0;
              top: ${getSpace()};
            `;
        }
      case 'center':
      default:
        switch (position) {
          case 'right':
            return css`
              left: ${getSpace()};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'left':
            return css`
              right: ${getSpace()};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'top':
            return css`
              bottom: ${getSpace()};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
          case 'bottom':
          default:
            return css`
              top: ${getSpace()};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
        }
    }
  }};
`;
