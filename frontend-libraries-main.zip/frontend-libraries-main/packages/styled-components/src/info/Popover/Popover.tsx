import { HTMLAttributes, ReactNode } from 'react';
import styled from 'styled-components';

import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { getBodyTextStyles } from '@/styles/typography';

import { PopoverCaretContent } from './PopoverCaretContent';
import { PopoverCaretTip } from './PopoverCaretTip';
import { PopoverContent, PopoverContentProps } from './PopoverContent';
import { PopoverPosition, PopoverPositionProps } from './PopoverPosition';
import { PopoverWrapper } from './PopoverWrapper';

export interface PopoverProps
  extends HTMLAttributes<HTMLElement>,
    PopoverPositionProps,
    PopoverContentProps {
  open: boolean;
  onClose?: () => void;
  trigger: ReactNode;
  caretTip?: boolean;
}

const PopoverContainer = styled.div`
  position: relative;
  display: inline-block;
  ${getBodyTextStyles()};
`;

export const Popover = ({
  open,
  onClose,
  trigger,
  children,
  position,
  align,
  size,
  caretTip,
  ...props
}: PopoverProps) => {
  const openState = useDebouncedValue(open, open ? 0 : 400);
  const onKeyUp = (e: React.KeyboardEvent) => {
    if (!open) {
      return;
    }
    if (['Escape'].includes(e.code)) {
      e.preventDefault();
    }
    switch (e.code) {
      case 'Escape':
        onClose?.();
        break;
      default:
        break;
    }
  };

  const content = (
    <PopoverContent size={size}>{openState && children}</PopoverContent>
  );

  return (
    <PopoverContainer onKeyUp={onKeyUp} {...props}>
      <PopoverWrapper aria-hidden={!open} position={position}>
        <PopoverPosition
          position={position}
          align={caretTip ? 'center' : align}
        >
          {caretTip ? (
            <>
              <PopoverCaretContent position={position} align={align}>
                {content}
              </PopoverCaretContent>
              <PopoverCaretTip position={position} />
            </>
          ) : (
            content
          )}
        </PopoverPosition>
      </PopoverWrapper>
      {trigger}
    </PopoverContainer>
  );
};

Popover.displayName = 'Popover';
