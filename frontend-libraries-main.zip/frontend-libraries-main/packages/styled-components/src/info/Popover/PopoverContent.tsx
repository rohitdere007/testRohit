import styled from 'styled-components';

import { getColor } from '@/styles/color';
import { getRadius } from '@/styles/radius';
import { Spacing, getSpace, getSpacing } from '@/styles/space';
import { getBodyTextStyles } from '@/styles/typography';

type PopoverSize = 'sm' | 'md' | 'lg';

const popoverSize: Record<PopoverSize, Spacing> = {
  sm: '2',
  md: '4',
  lg: '6',
};

export interface PopoverContentProps {
  size?: PopoverSize;
}

export const PopoverContent = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'size',
})<PopoverContentProps>`
  box-shadow: 0px 4px 16px 0px ${getColor('borderStrong')}3a;
  border-radius: ${getRadius()};
  background: ${getColor('bgPrimary')};
  position: relative;
  outline: none;
  padding: ${getSpace(2)};
  ${getBodyTextStyles({ color: 'fg' })};
  padding: ${({ size = 'sm', theme }) =>
    getSpacing(popoverSize[size])({ theme })};
`;
