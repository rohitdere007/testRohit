import styled, { css } from 'styled-components';

import { getSpace } from '@/styles/space';

import {
  PopoverPositionProps,
  isPopoverPositionProps,
} from './PopoverPosition';

export const PopoverCaretContent = styled.div.withConfig({
  shouldForwardProp: (p) => !isPopoverPositionProps(p),
})<PopoverPositionProps>`
  position: absolute;
  ${({ position, align }) => {
    switch (align) {
      case 'start':
        switch (position) {
          case 'right':
            return css`
              left: ${getSpace(2)};
              margin-top: -${getSpace(6)};
            `;
          case 'left':
            return css`
              right: ${getSpace(2)};
              margin-top: -${getSpace(6)};
            `;
          case 'top':
            return css`
              bottom: ${getSpace(2)};
              margin-left: -${getSpace(6)};
            `;
          case 'bottom':
          default:
            return css`
              top: ${getSpace(2)};
              margin-left: -${getSpace(6)};
            `;
        }

      case 'end':
        switch (position) {
          case 'right':
            return css`
              bottom: -${getSpace(6)};
              left: ${getSpace(2)};
            `;
          case 'left':
            return css`
              bottom: -${getSpace(6)};
              right: ${getSpace(2)};
            `;
          case 'top':
            return css`
              right: -${getSpace(6)};
              bottom: ${getSpace(2)};
            `;
          case 'bottom':
          default:
            return css`
              right: -${getSpace(6)};
              top: ${getSpace(2)};
            `;
        }
      case 'center':
      default:
        switch (position) {
          case 'right':
            return css`
              left: ${getSpace(2)};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'left':
            return css`
              right: ${getSpace(2)};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'top':
            return css`
              bottom: ${getSpace(2)};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
          case 'bottom':
          default:
            return css`
              top: ${getSpace(2)};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
        }
    }
  }};
`;
