import styled from 'styled-components';

export const PopoverFixed = styled.div`
  position: fixed;
`;

PopoverFixed.displayName = 'PositionFixed';
