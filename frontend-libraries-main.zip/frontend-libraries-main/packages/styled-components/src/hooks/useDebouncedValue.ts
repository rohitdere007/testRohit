import { useEffect, useRef, useState } from 'react';

export const useDebouncedValue = <T = unknown>(param: T, delay: number) => {
  const [value, setValue] = useState<T>();
  const timer = useRef<NodeJS.Timeout | number>();

  useEffect(() => {
    if (value !== param) {
      if (delay) {
        timer.current = setTimeout(() => {
          setValue(param);
        }, delay);
      } else {
        setValue(param);
      }
    }
    return () => {
      clearTimeout(timer.current);
    };
  }, [param, value, delay]);

  return value;
};
