import { useEffect } from 'react';

export const isBrowser = typeof window !== 'undefined';
export const isNavigator = typeof navigator !== 'undefined';

interface HasAddEventListener {
  addEventListener(
    name: string,
    handler: (event?: unknown) => void,
    ...args: unknown[]
  ): void;

  removeEventListener(
    name: string,
    handler: (event?: unknown) => void,
    ...args: unknown[]
  ): void;
}

interface HasOnListener {
  on(
    name: string,
    handler: (event?: unknown) => void,
    ...args: unknown[]
  ): void;
  off(
    name: string,
    handler: (event?: unknown) => void,
    ...args: unknown[]
  ): void;
}

type UseEventTarget = HasAddEventListener | HasOnListener;

const defaultTarget = isBrowser ? window : null;

const isAddEventListener = (target: object): target is HasAddEventListener =>
  'addEventListener' in target;
const isOnListener = (target: object): target is HasOnListener =>
  'on' in target;

type AddEventListener<T> = T extends HasAddEventListener
  ? T['addEventListener']
  : T extends HasOnListener
    ? T['on']
    : never;

export const useEvent = <T extends UseEventTarget>(
  name: Parameters<AddEventListener<T>>[0],
  handler?: null | undefined | Parameters<AddEventListener<T>>[1],
  target: null | T | Window = defaultTarget,
  options?: boolean | EventListenerOptions | undefined,
) => {
  useEffect(() => {
    if (!handler) {
      return;
    }
    if (!target) {
      return;
    }
    if (isAddEventListener(target)) {
      target.addEventListener(name, handler, options);
    } else if (isOnListener(target)) {
      target.on(name, handler, options);
    }
    return () => {
      if (isAddEventListener(target)) {
        target.removeEventListener(name, handler, options);
      } else if (isOnListener(target)) {
        target.off(name, handler, options);
      }
    };
  }, [name, handler, target, options]);
};
