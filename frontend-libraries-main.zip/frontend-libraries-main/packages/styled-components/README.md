# Introduction

## National Grid Experience System

This package is a collection of reusable components and utils for ReactJs projects built using styled components. Currently this package is available to all organisations within the github enterprise account.

This package is currently in alpha and is expected to have breaking changes frequently until a future release. Consumers of this package are expected to update to the latest version when released as older versions will be removed from github.

### Setup Github & NPM regristry credentials

**Step 1**: Ensure that you have an ssh key configured for your github account so then you are able to clone the repository locally by following [this tutorial](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account).

Once your ssh key has been created in github, Click the "Configure SSO" button for the key and ensure that the key is authorised for `nationalgrid-engineering`

**Step 2**: open or create your user-level npm config at `~/.npmrc` and copy the below into the file
Note: for mac, if hidden files are not visible, press [`CMD` + `Shift` + `.`] then you will be able to see/create your `.npmrc` file.

```bash
//npm.pkg.github.com/:_authToken=[YOUR_ACCESS_TOKEN]
```

**Step 3**: Generate a [Personal Access Token (classic)](https://github.com/settings/tokens) with at least read:package selected in the available scopes.

**Step 4**: copy your new token and replace `[YOUR_ACCESS_TOKEN]` in your user-level `.npmrc` file with your new token. (you will not be able to see the token again after leaving this github page)

**Step 5**: Click the "Configure SSO" button on your newly created token and select `nationalgrid-engineering`

### Getting Started

Once you have your github token setup following the above steps, you should create a `.npmrc` file in the root of your project
that lets your package manager know to fetch the package from the github registry rather than npm.

```bash
@nationalgrid-engineering:registry=https://npm.pkg.github.com
@nationalgrid-your-org:registry=https://npm.pkg.github.com

always-auth=true
```

you should replace `@nationalgrid-your-org` in the above example with the name of your github orgainsiation.

Given you've created the `.npmrc` file you should now be able to add this package as a dependency to your project:

```bash
yarn add @nationalgrid-engineering/styled-components styled-components @mdi/js @mdi/react
```
Once added, create a new file in your project named `styled-components.d.ts` and add the following

```javascript
import { lightMode } from '@nationalgrid-engineering/styled-components';

type ThemeType = typeof lightMode;

declare module 'styled-components' {
  // eslint-disable-next-line @typescript-eslint/no-empty-interface
  export interface DefaultTheme extends ThemeType {}
}
```

Then ensure that the new file is found by your `tsconfig.json` by adding it's path to the `types` array. In the example below, the new file is with the `src/types` folder within the project

```json
"types": ["./src/types/*"]
```

### Fonts

The component library uses the font "Inter". To install it, you can download the font [here](https://fonts.google.com/specimen/Inter). Click the "Get Font" button where you'll be taken to a new "selection" screen. Click the "Download all" button to download the zip file.

Create a "fonts" folder in your app's public folder and copy the ttf files from the "static" folder within the zip to said "fonts" folder. If you would like to specify a custom path for the font files, the ThemeProvider accepts a "fontPath" prop.

### Theme Provider

Finally, import the `ThemeProvider` component from the `@nationalgrid-engineering/styled-components` package and wrap your app within it.

```javascript
import { ThemeProvider } from '@nationalgrid-engineering/styled-components';
import React from 'react';
import ReactDOM from 'react-dom/client';

import App from './App.tsx';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ThemeProvider>
      <App />
    </ThemeProvider>
  </React.StrictMode>,
);
```

An example of a basic React App that implements `@nationalgrid-engineering/styled-components` along with @nationalgrid-engineering linting and prettier rules can be found in [apps/react-styled](https://github.com/nationalgrid-engineering/frontend-libraries/tree/main/apps/react-styled)

If you are using NextJS, please follow their intructions [here](https://nextjs.org/docs/app/building-your-application/styling/css-in-js#styled-components), otherwise, you should now be all setup! Happy Coding!

An example of a NextJS 13 app that implements `@nationalgrid-engineering/styled-components` can be found in [apps/next-styled](https://github.com/nationalgrid-engineering/frontend-libraries/tree/main/apps/next-styled)
