import {
  SupportText,
  inputSizeStyles,
  inputWidths,
} from '@nationalgrid-engineering/styled-components';
import { action } from '@storybook/addon-actions';
import { Meta, StoryObj } from '@storybook/react';

import { Select } from './Select';

type Story = StoryObj<typeof Select>;

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

const options = [
  { label: 'Option One', value: 'one' },
  { label: 'Option Two', value: 'two' },
  { label: 'Option Three', value: 'three' },
  { label: 'Option Four', value: 'four' },
  { label: 'Really long option label', value: 'five' },
];

export default {
  component: Select,
  parameters: {
    docs: {
      description: {
        component:
          '<p>The Select component is a wrapper around the `react-select` library</p>',
      },
    },
    actions: {
      handles: ['focus', 'blur', 'change'],
    },
  },
  args: {
    isMulti: true,
    isCreatable: false,
    isClearable: true,
    disabled: false,
    readOnly: false,
    required: false,
    invalid: false,
    hideLabel: false,
    label: 'Select Label',
    options: options,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
    menuPlacement: 'bottom',
    // menuPosition: 'fixed',
    // menuIsOpen: true,
  },
  argTypes: {
    isMulti: {
      control: { type: 'boolean' },
      defaultValue: false,
      description: 'If the select can take multiple values',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'false' },
      },
    },
    isCreatable: {
      control: { type: 'boolean' },
      defaultValue: false,
      description: 'If the user can create new options',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'false' },
      },
    },
    isClearable: {
      control: { type: 'boolean' },
      description: 'If the input value is clearable',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'undefined' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'a placeholder value for the input',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '' },
      },
    },
    size: {
      control: {
        type: 'select',
      },
      description:
        'the height of the input field which matches the button sizes',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    menuPlacement: {
      control: {
        type: 'select',
      },
      description: 'react-select menuPlacement prop',
      options: ['bottom', 'top', 'auto'],
      table: {
        type: {
          summary: ['bottom', 'top', 'auto'].join(' | '),
        },
        defaultValue: { summary: '"auto"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'md' },
      },
    },
    options: {
      control: false,
      description: 'The options associated with the select',
      table: {
        type: { summary: `{ label: string, value: string}[]` },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the input is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },

    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description:
        "If the input value is invalid but shouldn't use default browser messaging.",
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    invalid: {
      control: { type: 'boolean' },
      description: 'If the input value is invalid',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Select>;

export const SelectStory: Story = {
  name: 'Select',
  args: {},
  parameters: {
    layout: 'flex',
    minHeight: '300px',
    controls: {
      exclude: ['type', 'before', 'after', 'children'],
    },
  },
  render({ ...props }) {
    return (
      <Select
        {...props}
        message={
          (props.invalid || props.message) && (
            <SupportText variant="critical">
              {props.message || 'Some sort of validation error'}
            </SupportText>
          )
        }
      />
    );
  },
};

export const ReadOnly: Story = {
  args: {
    readOnly: true,
    value: 'one',
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    value: 'one',
  },
};

export const InvalidWithMessage: Story = {
  render(props) {
    return (
      <Select
        {...props}
        required
        label="Select Label"
        defaultValue="one"
        error="Some sort of validation error"
        options={options}
      />
    );
  },
};

export const HiddenLabel: Story = {
  args: {
    hideLabel: true,
  },
};
