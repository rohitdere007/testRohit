import {
  getColor,
  getRadius,
  getSpace,
  getSpacing,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

export const SelectMenu = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: ${getSpace()};
  margin: ${getSpacing('1 -0.25 0')};
  padding: ${getSpace(2)};
  background: ${getColor('bgPrimary')};
  border-radius: ${getRadius(1.5)};
  border: 1px solid ${getColor('border')};
  box-shadow: 0px 4px 16px 0px ${getColor('borderStrong')}3a;
`;
