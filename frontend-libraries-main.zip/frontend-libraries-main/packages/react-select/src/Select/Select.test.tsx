import { render, screen } from '@testing-library/react';

import { withTheme } from '@/testUtils';

import { Select } from './Select';
import { SelectProps } from './SelectElement';

const params = { wrapper: withTheme };

describe('Select', () => {
  const props: SelectProps = {
    label: 'testing',
    name: 'select-demo',
    isMulti: true,
    isCreatable: false,
    isClearable: true,
    disabled: false,
    options: [
      { value: 'a', label: 'A' },
      { value: 'b', label: 'B' },
    ],
    value: { value: 'a', label: 'A' },
  };

  it('renders the a component with props', () => {
    render(<Select {...props} />, params);
    expect(screen.getByText(props.label)).toBeDefined();
  });

  it('renders a Creatable when isCreatable is passed', () => {
    render(<Select {...props} isCreatable />, params);
    expect(screen.getByText(props.label)).toBeDefined();
  });
});
