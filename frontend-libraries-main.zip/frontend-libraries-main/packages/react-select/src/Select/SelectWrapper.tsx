import {
  InputSharedStylesProps,
  InputSize,
  getColor,
  getFontWeight,
  getSpace,
  getUITextStyles,
  inputSharedStyles,
  isInputSharedProp,
} from '@nationalgrid-engineering/styled-components';
import styled, { RuleSet, css } from 'styled-components';

const seperatorStyles: Record<InputSize, RuleSet<object>> = {
  xs: css`
    margin: ${getSpace(1)} ${getSpace(0.5)};
  `,
  sm: css`
    margin: 0 ${getSpace(1)} 0 ${getSpace(0.5)};
  `,
  md: css`
    margin: 0 ${getSpace(1)};
  `,
  lg: css`
    margin: 0 ${getSpace(1.5)};
  `,
  xl: css`
    margin: 0 ${getSpace(1.5)};
  `,
};

export const SelectWrapper = styled.div.withConfig({
  shouldForwardProp: (propName) => !isInputSharedProp(propName),
})<InputSharedStylesProps>`
  .react-select {
    font-weight: ${getFontWeight('regular')};

    &__dropdown-indicator {
      height: 100%;
      display: flex;
      align-items: center;
      color: ${getColor('fgSubtle')};

      transition: transform 300ms ease-in-out;

      @media (prefers-reduced-motion) {
        transition-duration: 0ms;
      }
    }

    &__placeholder {
      color: ${getColor('fgPlaceholder')};
      font-weight: ${getFontWeight('regular')};
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      max-width: 100%;
      position: absolute;
      padding-right: ${getSpace()};
    }

    &__control {
      border: 1px solid ${getColor('border')};
      box-sizing: border-box;
      background-color: ${getColor('bgPrimary')};

      &:focus-within {
        outline: 1px solid ${getColor('borderInfo')} !important;
      }

      ${getUITextStyles({ color: 'fg', weight: 'regular' })};
      ${inputSharedStyles};

      &--menu-is-open {
        .react-select {
          &__dropdown-indicator {
            transform: rotate(180deg);
          }
        }
      }
    }

    &__clear-indicator {
      height: 100%;
      display: flex;
      align-items: center;
      color: ${getColor('fgSubtle')};
      margin: 0 ${getSpace()};
    }

    &__indicator-separator {
      background: ${getColor('border')};
      ${({ size }) => seperatorStyles[size || 'md']};
    }

    &__value-container {
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      gap: ${getSpace()};
    }

    &__input {
      background: ${getColor('bgPrimary')};
    }

    &__input-container {
      background: ${getColor('bgPrimary')};
      ${getUITextStyles({ color: 'fg', weight: 'regular' })};
    }

    &__menu-list {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: ${getSpace(1)};
    }

    &__option {
      ${getUITextStyles({ color: 'fg' })};
    }

    &__menu-notice {
      font-weight: ${getFontWeight('regular')};
    }

    &__multi-value {
      ${getUITextStyles({ size: 'sm' })};
    }
  }
`;
