import {
  Field,
  forwardRefGeneric,
} from '@nationalgrid-engineering/styled-components';
import { GroupBase } from 'react-select';

import { SelectElement, SelectOptionType, SelectProps } from './SelectElement';

export const SelectField = <
  Option = SelectOptionType,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>(
  {
    id,
    label,
    message,
    hideLabel,
    width,
    tooltip,
    ...inputProps
  }: SelectProps<Option, IsMulti, Group>,
  // thier ref def isn't exported
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ref: React.ForwardedRef<any>,
) => (
  <Field
    id={id}
    label={label}
    message={message}
    required={inputProps.required || !!inputProps['aria-required']}
    error={inputProps.error}
    hideLabel={hideLabel}
    width={width}
    tooltip={tooltip}
  >
    <SelectElement ref={ref} id={id} label={label} {...inputProps} />
  </Field>
);

export const Select = forwardRefGeneric(SelectField);
