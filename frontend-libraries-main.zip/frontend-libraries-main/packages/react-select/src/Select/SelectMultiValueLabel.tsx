import styled from 'styled-components';

export const SelectMultiValueLabel = styled.div`
  max-width: 90px;
  overflow: hidden;
  text-overflow: ellipsis;
`;
