import {
  getColor,
  getFontWeight,
  getRadius,
  getSize,
  getSpace,
  getSpacing,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

export const SelectOption = styled.div<{ selected?: boolean }>`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  background: ${getColor('bgPrimary')};
  min-width: ${getSize(32)};
  min-height: ${getSize(8)};
  padding: ${getSpacing('1 2')};
  gap: ${getSpace(2)};
  border-radius: ${getRadius(1.5)};
  font-weight: ${getFontWeight('regular')};

  &:hover {
    background: ${getColor('bgInfoSubtlest')};
  }
`;
