import {
  getColor,
  getRadius,
  getSpace,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

export const SelectMultiValueContainer = styled.div<{ selected?: boolean }>`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  background: ${getColor('bgPrimary')};
  padding: ${getSpace(0.5)};
  gap: ${getSpace()};
  border-radius: ${getRadius(1)};
  border: 1px solid;
  border-color: ${getColor('borderInfoSubtle')};
  background: ${getColor('bgInfoSubtlest')};
  box-sizing: border-box;
  pointer-events: none;
  [role='button'] {
    pointer-events: auto;
  }
  &:hover,
  &:focus-visible {
    border-color: ${getColor('borderInfoSubtleHover')};
    background-color: ${getColor('bgInfoSubtlestHover')};
  }
`;
