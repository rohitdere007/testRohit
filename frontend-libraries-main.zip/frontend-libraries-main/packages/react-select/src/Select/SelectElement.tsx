import { mdiCheck, mdiChevronDown, mdiClose } from '@mdi/js';
import {
  FieldProps,
  Icon,
  InputSharedStylesProps,
  forwardRefGeneric,
  getSize,
} from '@nationalgrid-engineering/styled-components';
import { InputHTMLAttributes } from 'react';
import ReactSelect, {
  ClearIndicatorProps,
  DropdownIndicatorProps,
  GroupBase,
  MenuPlacement,
  MenuProps,
  MultiValueGenericProps,
  MultiValueRemoveProps,
  OptionProps,
  Props as ReactSelectProps,
  components as SelectComponent,
} from 'react-select';
import makeAnimated from 'react-select/animated';
import Creatable, { CreatableProps } from 'react-select/creatable';
import styled from 'styled-components';

import { SelectMenu } from './SelectMenu';
import { SelectMultiValueContainer } from './SelectMultiValueContainer';
import { SelectMultiValueLabel } from './SelectMultiValueLabel';
import { SelectOption } from './SelectOption';
import { SelectWrapper } from './SelectWrapper';

const animatedComponents = makeAnimated();

const InputIcon = styled(Icon)`
  height: ${getSize(4)};
`;

const DropdownIndicator = <
  Option = unknown,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>({
  ...props
}: DropdownIndicatorProps<Option, IsMulti, Group>) => (
  <SelectComponent.DropdownIndicator {...props}>
    <InputIcon icon={mdiChevronDown} size="md" />
  </SelectComponent.DropdownIndicator>
);

const ClearIndicator = <
  Option = unknown,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>({
  ...props
}: ClearIndicatorProps<Option, IsMulti, Group>) => (
  <SelectComponent.ClearIndicator {...props}>
    <InputIcon icon={mdiClose} size="sm" />
  </SelectComponent.ClearIndicator>
);

const Menu = <
  Option = unknown,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>({
  children,
  ...props
}: MenuProps<Option, IsMulti, Group>) => (
  <SelectComponent.Menu {...props}>
    <SelectMenu>{children}</SelectMenu>
  </SelectComponent.Menu>
);

const Option = <
  Option = unknown,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>({
  children,
  ...props
}: OptionProps<Option, IsMulti, Group>) => {
  const { isSelected } = props;
  return (
    <SelectComponent.Option {...props}>
      <SelectOption selected={isSelected}>
        {children}
        {isSelected && <Icon icon={mdiCheck} size="sm" color="fgInfo" />}
      </SelectOption>
    </SelectComponent.Option>
  );
};

const MultiValueContainer = <
  Option = unknown,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>({
  children,
  ...props
}: MultiValueGenericProps<Option, IsMulti, Group>) => (
  <SelectComponent.MultiValueContainer {...props}>
    <SelectMultiValueContainer>{children}</SelectMultiValueContainer>
  </SelectComponent.MultiValueContainer>
);

const MultiValueLabel = ({ children, ...props }: MultiValueGenericProps) => (
  <SelectComponent.MultiValueLabel {...props}>
    <SelectMultiValueLabel>{children}</SelectMultiValueLabel>
  </SelectComponent.MultiValueLabel>
);

const MultiValueRemove = (props: MultiValueRemoveProps) => (
  <SelectComponent.MultiValueRemove {...props}>
    <Icon icon={mdiClose} size="xs" />
  </SelectComponent.MultiValueRemove>
);

const components = {
  ...animatedComponents,
  DropdownIndicator,
  Menu,
  ClearIndicator,
  Option,
  MultiValueContainer,
  MultiValueLabel,
  MultiValueRemove,
};

export type SelectElementProps = InputHTMLAttributes<HTMLInputElement> &
  InputSharedStylesProps;

type AdditionalProps = {
  isCreatable?: boolean;
};

export type SelectOptionType = {
  value: string;
  label: string;
};

export type SelectProps<
  Option = SelectOptionType,
  IsMulti extends boolean = boolean,
  Group extends GroupBase<Option> = GroupBase<Option>,
> = Omit<
  Partial<CreatableProps<Option, IsMulti, Group>> &
    ReactSelectProps<Option, IsMulti, Group>,
  'isDisabled'
> &
  Omit<FieldProps, 'children' | 'as'> &
  AdditionalProps &
  InputSharedStylesProps;

const SelectWithRef = <
  Option = SelectOptionType,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
>(
  {
    error,
    isCreatable,
    invalid,
    align,
    label,
    size,
    width,
    ...props
  }: SelectProps<Option, IsMulti, Group>,
  // thier ref def isn't exported
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ref: React.ForwardedRef<any>,
) => {
  const selectProps = {
    menuPlacement: 'auto' as MenuPlacement,
    ...props,
    components: components,
    className: 'react-select-container',
    classNamePrefix: 'react-select',
    unstyled: true,
    hideSelectedOptions: false,
    ref,
  };
  const disabled = selectProps.disabled || selectProps['aria-disabled'];

  const select = isCreatable ? (
    <Creatable {...selectProps} isDisabled={disabled} />
  ) : (
    <ReactSelect {...selectProps} isDisabled={disabled} />
  );

  return (
    <SelectWrapper
      invalid={invalid}
      error={error}
      disabled={disabled}
      align={align}
      label={label}
      size={size}
      width={width}
    >
      {select}
    </SelectWrapper>
  );
};

export const SelectElement = forwardRefGeneric(SelectWithRef);
