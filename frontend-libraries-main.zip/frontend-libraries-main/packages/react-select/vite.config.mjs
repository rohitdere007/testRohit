import path from 'path';

import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import dts from 'vite-plugin-dts';
import svgr from 'vite-plugin-svgr';
import tsconfigPaths from 'vite-tsconfig-paths';

import pkg from './package.json';

export default defineConfig({
  build: {
    lib: {
      // eslint-disable-next-line no-undef
      entry: path.resolve(__dirname, 'src/index.ts'),
      name: pkg.name,
      formats: ['es', 'umd'],
      fileName: (format) => {
        switch (format) {
          case 'es':
            return 'index.js';
          default:
            return `index.${format}.js`;
        }
      },
    },
    rollupOptions: {
      external: [
        'react',
        'react-dom',
        'styled-components',
        '@nationalgrid-engineering/styled-components',
        'react-select',
        '@mdi/js',
        '@mdi/react',
      ],
      output: {
        interop: 'auto',
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM',
          'styled-components': 'styled',
          'react-select': 'ReactSelect',
          '@nationalgrid-engineering/styled-components': 'NGES',
          '@mdi/js': 'mdijs',
          '@mdi/react': 'mdireact',
        },
      },
    },
  },
  resolve: {
    alias: {
      // eslint-disable-next-line no-undef
      '@': path.resolve(__dirname, './src'),
    },
  },
  plugins: [
    svgr(),
    react({
      babel: {
        plugins: [['styled-components', { displayName: false }]],

        env: {
          development: {
            plugins: [['styled-components', { displayName: true }]],
          },
        },
      },
    }),
    dts({
      insertTypesEntry: true,
    }),
    tsconfigPaths(),
  ],
});
