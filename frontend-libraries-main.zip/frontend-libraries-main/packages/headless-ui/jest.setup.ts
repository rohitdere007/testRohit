import '@testing-library/jest-dom';
import 'jest-styled-components';

beforeEach(() => {
  HTMLDialogElement.prototype.show = jest.fn(function () {
    this.ariaModal = false;
    this.open = true;
  });
  HTMLDialogElement.prototype.showModal = jest.fn(function () {
    this.ariaModal = true;
    this.open = true;
  });
  HTMLDialogElement.prototype.close = jest.fn(function () {
    this.ariaModal = false;
    this.open = false;
  });
});
