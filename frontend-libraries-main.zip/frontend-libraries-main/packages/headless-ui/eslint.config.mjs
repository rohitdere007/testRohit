import config from '@nationalgrid-engineering/eslint-nges';
export default config;
