import {
  darkMode,
  lightMode,
} from '@nationalgrid-engineering/styled-components';
import { PropsWithChildren } from 'react';
import { ThemeProvider } from 'styled-components';

export const JestTheme = (props: PropsWithChildren) => (
  <ThemeProvider theme={darkMode as unknown as typeof lightMode}>
    {props.children}
  </ThemeProvider>
);
