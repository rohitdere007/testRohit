import {
  DropdownBody,
  getSpace,
  getSpacing,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

export const ActionMenuBody = styled(DropdownBody)`
  display: flex;
  flex-direction: column;
  gap: ${getSpace(1)};

  &:not(:last-child):first-child {
    padding: ${getSpacing('2 2 1')};
  }
  &:not(:first-child):last-child {
    padding: ${getSpacing('1 2 2')};
  }
  &:not(:first-child):not(:last-child) {
    padding: ${getSpacing('1 2')};
  }
`;

ActionMenuBody.displayName = 'ActionMenu.Body';
