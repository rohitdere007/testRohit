import { DropdownDivider } from '@nationalgrid-engineering/styled-components';
import { ForwardRefExoticComponent, forwardRef } from 'react';
import styled from 'styled-components';

import { Dropdown, DropdownProps } from '@/Dropdown';

import { ActionMenuBody } from './ActionMenuBody';
import { ActionMenuHandle } from './ActionMenuHandle';
import { ActionMenuItem } from './ActionMenuItem';

type ActionMenuType = ForwardRefExoticComponent<
  DropdownProps & React.RefAttributes<HTMLDivElement>
> & {
  Handle: typeof ActionMenuHandle;
  Item: typeof ActionMenuItem;
  Body: typeof ActionMenuBody;
  Divider: typeof DropdownDivider;
};

export const ActionMenu = forwardRef<HTMLDivElement, DropdownProps>(
  (props, ref) => <Dropdown {...props} ref={ref} />,
) as ActionMenuType;

const ActionMenuDivider = styled(DropdownDivider)``;
ActionMenuDivider.displayName = 'ActionMenu.Divider';

ActionMenu.displayName = 'ActionMenu';
ActionMenu.Item = ActionMenuItem;
ActionMenu.Handle = ActionMenuHandle;
ActionMenu.Body = ActionMenuBody;
ActionMenu.Divider = ActionMenuDivider;
