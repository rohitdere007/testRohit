import {
  DropdownItem,
  DropdownItemProps,
} from '@nationalgrid-engineering/styled-components';

export type ActionButtonProps<C extends React.ElementType> =
  DropdownItemProps<C>;

export const ActionMenuItem = <C extends React.ElementType>({
  ...props
}: ActionButtonProps<C>) => <DropdownItem {...props} />;

ActionMenuItem.displayName = 'ActionMenu.Item';
