import { CloseButton, PopoverButton } from '@headlessui/react';
import { mdiDelete, mdiFileEdit } from '@mdi/js';
import { MoonIcon } from '@nationalgrid-engineering/styled-components';
import { Meta, StoryObj } from '@storybook/react';

import { ActionMenu } from './ActionMenu';

type Story = StoryObj<typeof ActionMenu>;

export default {
  component: ActionMenu,
  args: {
    anchor: 'bottom start',
  },
  parameters: {
    layout: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  argTypes: {
    anchor: {
      control: {
        type: 'select',
      },
      options: [
        'top',
        'top start',
        'top end',
        'bottom',
        'bottom start',
        'bottom end',
        'left',
        'left start',
        'left end',
        'right',
        'right start',
        'right end',
      ],
      defaultValue: '',
      description: 'The position of the dropdown relative to the trigger',
    },
    zIndex: {
      control: { type: 'number' },
      defaultValue: '',
      description: 'The z-index value of the options dropdown',
      table: {
        type: { summary: 'string' },
      },
    },
  },
  render(props) {
    return (
      <ActionMenu
        {...props}
        data-open
        handle={<ActionMenu.Handle label="Actions" />}
      >
        {({ close }) => (
          <>
            <ActionMenu.Body>
              <ActionMenu.Item icon={<MoonIcon />} as={CloseButton}>
                Custom Icon
              </ActionMenu.Item>

              <ActionMenu
                {...props}
                anchor="right start"
                style={{ width: '100%' }}
                handle={
                  <ActionMenu.Item
                    icon={mdiFileEdit}
                    as={PopoverButton}
                    chevron
                  >
                    Edit Item
                  </ActionMenu.Item>
                }
              >
                {({ close: subClose }) => {
                  const c = () => {
                    close();
                    subClose();
                  };
                  return (
                    <ActionMenu.Body>
                      <ActionMenu.Item icon={<MoonIcon />} onClick={c}>
                        Custom Icon
                      </ActionMenu.Item>
                      <ActionMenu.Item icon={mdiFileEdit} onClick={c}>
                        Edit Item
                      </ActionMenu.Item>
                    </ActionMenu.Body>
                  );
                }}
              </ActionMenu>
            </ActionMenu.Body>
            <ActionMenu.Divider />
            <ActionMenu.Body>
              <ActionMenu.Item
                variant="critical"
                icon={mdiDelete}
                as={CloseButton}
              >
                To long to put in the width of a menu
              </ActionMenu.Item>
            </ActionMenu.Body>
          </>
        )}
      </ActionMenu>
    );
  },
} satisfies Meta<typeof ActionMenu>;

export const Default: Story = {
  name: 'ActionMenu',
  args: {},
};
