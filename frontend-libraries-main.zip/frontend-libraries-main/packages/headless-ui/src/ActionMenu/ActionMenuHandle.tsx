import { PopoverButton } from '@headlessui/react';
import { mdiDotsVertical } from '@mdi/js';
import { IconButton } from '@nationalgrid-engineering/styled-components';
import { forwardRef } from 'react';

export type ActionMenuHandleProps = {
  label: string;
};

export const ActionMenuHandle = forwardRef<
  HTMLButtonElement,
  ActionMenuHandleProps
>(({ label, ...props }, ref) => (
  <IconButton
    {...props}
    as={PopoverButton}
    ref={ref}
    type="button"
    ghost
    icon={mdiDotsVertical}
    aria-label={label || 'Actions Menu'}
  />
));

ActionMenuHandle.displayName = 'ActionMenu.Handle';
