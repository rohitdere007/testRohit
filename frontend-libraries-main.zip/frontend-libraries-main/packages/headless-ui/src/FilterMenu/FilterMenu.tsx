import {
  DropdownFooter,
  DropdownScrollable,
  getSize,
} from '@nationalgrid-engineering/styled-components';
import { ForwardRefExoticComponent, forwardRef } from 'react';
import styled from 'styled-components';

import { Dropdown, DropdownProps } from '@/Dropdown';

import { FilterMenuHandle } from './FilterMenuHandle';

type FilterMenuType = ForwardRefExoticComponent<
  DropdownProps & React.RefAttributes<HTMLDivElement>
> & {
  Handle: typeof FilterMenuHandle;
  Body: typeof DropdownScrollable;
  Footer: typeof DropdownFooter;
};

export const FilterMenu = forwardRef<HTMLDivElement, DropdownProps>(
  (props, ref) => <Dropdown {...props} ref={ref} />,
) as FilterMenuType;

FilterMenu.displayName = 'FilterMenu';

FilterMenu.Handle = FilterMenuHandle;

const FilterMenuBody = styled(DropdownScrollable)`
  max-height: ${getSize(75)};
`;
FilterMenuBody.displayName = 'FilterMenu.Body';
FilterMenu.Body = FilterMenuBody;

const FilterMenuFooter = styled(DropdownFooter)``;
FilterMenuFooter.displayName = 'FilterMenu.Footer';
FilterMenu.Footer = FilterMenuFooter;
