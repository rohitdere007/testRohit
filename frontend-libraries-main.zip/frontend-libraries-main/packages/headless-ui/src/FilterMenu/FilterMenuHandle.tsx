import { Popover } from '@headlessui/react';
import { mdiChevronDown } from '@mdi/js';
import { Button, Icon } from '@nationalgrid-engineering/styled-components';
import { forwardRef } from 'react';

export type FilterMenuHandleProps = {
  label: string;
  filterCount?: number;
};

export const FilterMenuHandle = forwardRef<
  HTMLButtonElement,
  FilterMenuHandleProps
>(({ label, filterCount = 0 }, ref) => (
  <Button as={Popover.Button} ref={ref}>
    {label}
    {filterCount ? ` (${filterCount})` : ''}
    <Icon icon={mdiChevronDown} />
  </Button>
));

FilterMenuHandle.displayName = 'FilterMenu.Handle';
