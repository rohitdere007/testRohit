import { mdiTrashCan } from '@mdi/js';
import {
  Button,
  Flex,
  IconButton,
  InputCheckbox,
  InputSearch,
  List,
  UIText,
} from '@nationalgrid-engineering/styled-components';
import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { FilterMenu } from './FilterMenu';

type Story = StoryObj<typeof FilterMenu>;

const options = [
  {
    label: 'Group One',
    options: [
      { value: 'a', label: 'Option A' },
      { value: 'b', label: 'Option B' },
      { value: 'c', label: 'Option C' },
    ],
  },
  {
    label: 'Group Two',
    options: [
      { value: 'd', label: 'Option D' },
      { value: 'e', label: 'Option E' },
      { value: 'f', label: 'Option F' },
    ],
  },
  {
    label: 'Group Three',
    options: [
      { value: 'g', label: 'Option G' },
      { value: 'h', label: 'Option H' },
      { value: 'i', label: 'Option I' },
    ],
  },
] as const;

type Values = (typeof options)[number]['options'][number]['value'];

export default {
  component: FilterMenu,
  args: {
    anchor: 'bottom start',
  },
  argTypes: {
    anchor: {
      control: {
        type: 'select',
      },
      options: [
        'top',
        'top start',
        'top end',
        'bottom',
        'bottom start',
        'bottom end',
        'left',
        'left start',
        'left end',
        'right',
        'right start',
        'right end',
      ],
      defaultValue: '',
      description: 'The position of the dropdown relative to the trigger',
    },
    zIndex: {
      control: { type: 'number' },
      defaultValue: '',
      description: 'The z-index value of the options dropdown',
      table: {
        type: { summary: 'string' },
      },
    },
  },
  parameters: {
    layout: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  render(props) {
    const [selectedApplied, setSelectedApplied] = useState<Values[]>([]);
    const [selected, setSelected] = useState<Values[]>([]);

    const onCancel = (close: () => void) => {
      setSelected(selectedApplied);
      close();
    };

    return (
      <Flex direction="column" gap={2}>
        <UIText>Filters applied: {selectedApplied.join(', ') || 'none'}</UIText>

        <FilterMenu
          {...props}
          handle={
            <FilterMenu.Handle
              label="Filter"
              filterCount={selectedApplied.length}
            />
          }
        >
          {({ close }) => (
            <form
              style={{ width: '100%' }}
              onSubmit={(e) => {
                e.preventDefault();
                setSelectedApplied(selected);
                close();
              }}
              onReset={() => {
                setSelectedApplied([]);
                setSelected([]);
                close();
              }}
            >
              <FilterMenu.Body>
                <InputSearch
                  label="Filter"
                  hideLabel
                  placeholder="Filter"
                  autoFocus
                />

                <List indentSpacing={6} m="3 2 1 2" gap={5}>
                  {options.map((group) => {
                    const nestedValues = group.options.map((op) => op.value);

                    const allChecked = nestedValues.every((val) =>
                      selected.includes(val),
                    );

                    const someChecked =
                      !allChecked &&
                      nestedValues.some((val) => selected.includes(val));

                    return (
                      <List.Item key={group.label}>
                        <InputCheckbox
                          label={group.label}
                          justify="flex-start"
                          checked={allChecked}
                          indeterminate={someChecked}
                          name="filterGroup"
                          onChange={() => {
                            setSelected((prev) => {
                              const otherValues = prev.filter(
                                (v) => !nestedValues.includes(v),
                              );

                              if (allChecked || someChecked) {
                                return otherValues;
                              }

                              return [...otherValues, ...nestedValues];
                            });
                          }}
                        />

                        <List>
                          {group.options.map((option) => (
                            <List.Item key={option.value}>
                              <InputCheckbox
                                name="filterName"
                                label={option.label}
                                value={option.value}
                                checked={selected.includes(option.value)}
                                onChange={() =>
                                  setSelected((prev) =>
                                    prev.includes(option.value)
                                      ? prev.filter((v) => v !== option.value)
                                      : [...prev, option.value],
                                  )
                                }
                              />
                            </List.Item>
                          ))}
                        </List>
                      </List.Item>
                    );
                  })}
                </List>
              </FilterMenu.Body>
              <FilterMenu.Footer
                secondary={
                  <IconButton
                    icon={mdiTrashCan}
                    ghost
                    variant="critical"
                    type="reset"
                  />
                }
              >
                <Button variant="primary" type="submit">
                  Apply
                </Button>
                <Button onClick={() => onCancel(close)} type="button">
                  Cancel
                </Button>
              </FilterMenu.Footer>
            </form>
          )}
        </FilterMenu>
      </Flex>
    );
  },
} satisfies Meta<typeof FilterMenu>;

export const Default: Story = {
  name: 'FilterMenu',
  args: {},
};
