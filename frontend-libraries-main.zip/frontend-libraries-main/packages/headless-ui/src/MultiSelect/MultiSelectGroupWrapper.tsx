import { getSpace } from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

import { Option } from '@/Listbox/Option';

type SelectGroupWrapperProps = {
  depth?: number;
};

export const MultiSelectGroupWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'depth',
})<SelectGroupWrapperProps>`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: ${getSpace()};

  ${Option} {
    padding-left: ${({ depth = 1, theme }) => getSpace(depth * 8)({ theme })};
  }
`;
