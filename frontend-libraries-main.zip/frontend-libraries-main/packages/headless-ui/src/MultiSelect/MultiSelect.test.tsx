import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { JestTheme } from '@/testUtils';

import { MultiSelect } from './MultiSelect';
import { MultiSelectProps } from './MultiSelectElement';
import { MultiSelectOptionsProp } from './MultiSelectOptions';

global.ResizeObserver = class FakeResizeObserver {
  observe() {}
  disconnect() {}
  unobserve() {}
};

global.ResizeObserver = class FakeResizeObserver {
  observe() {}
  disconnect() {}
  unobserve() {}
};

const params = { wrapper: JestTheme };

const options = [
  { value: 'a', label: 'Option A' },
  { value: 'b', label: 'Option B' },
  { value: 'c', label: 'Option C' },
];

const optionGroups: MultiSelectOptionsProp<string> = [
  {
    label: 'Group 1',
    options: options,
  },
  {
    label: 'Group 2',
    options: [
      { value: 'd', label: 'Option D' },
      { value: 'e', label: 'Option E' },
      { value: 'f', label: 'Option F' },
    ],
  },
];

describe('Multi Select', () => {
  const props: MultiSelectProps<string> = {
    options,
    label: 'Pick some options',
    placeholder: 'All',
    onChange: jest.fn(),
    value: [],
  };

  it('renders the component', () => {
    render(<MultiSelect {...props} />, params);

    expect(screen.getByText(props.label)).toBeDefined();
    expect(screen.getByRole('button')).toHaveTextContent(props.placeholder);
  });

  it('should handle changes', async () => {
    render(<MultiSelect {...props} value={['a']} />, params);

    await userEvent.click(screen.getByRole('button'));

    await userEvent.click(screen.getByRole('option', { name: 'Option B' }));

    expect(props.onChange).toHaveBeenCalledWith(['a', 'b']);
  });

  it('should stop showing tags when 3 or more options selected', async () => {
    render(<MultiSelect {...props} value={['a', 'b', 'c']} />, params);
    expect(screen.getByRole('button')).toHaveTextContent('3 selected');
  });
});

describe('Multi Select with Groups', () => {
  const props: MultiSelectProps<string> = {
    options: optionGroups,
    label: 'Pick some options',
    placeholder: 'select...',
    onChange: jest.fn(),
    value: [],
  };

  it('renders the component with a label', () => {
    render(<MultiSelect {...props} />, params);

    expect(screen.getByText(props.label)).toBeDefined();
    expect(screen.getByRole('button')).toHaveTextContent(props.placeholder);
  });

  it('should handle changes', async () => {
    render(
      <MultiSelect {...props} />,

      params,
    );

    await userEvent.click(screen.getByRole('button'));

    // Click two options
    await userEvent.click(screen.getByRole('option', { name: 'Option E' }));

    expect(props.onChange).toHaveBeenCalledWith(['e']);
  });

  it('should show an indeterminate checkbox when some but not all options are selected', async () => {
    render(<MultiSelect {...props} value={['a', 'c']} />, params);

    await userEvent.click(screen.getByRole('button'));

    expect(
      screen.getByTestId('option-group-checkbox-group-1'),
    ).toBePartiallyChecked();
  });

  it('should select all children when a group is selected', async () => {
    render(<MultiSelect {...props} />, params);

    await userEvent.click(screen.getByRole('button'));

    // Click the group
    await userEvent.click(screen.getByText('Group 1'));
    expect(props.onChange).toHaveBeenCalledWith(['a', 'b', 'c']);
  });
});
