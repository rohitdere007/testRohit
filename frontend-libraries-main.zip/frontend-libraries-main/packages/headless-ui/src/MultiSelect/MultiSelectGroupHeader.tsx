import {
  InputCheckbox,
  LabelText,
  getSpace,
  textEllipsisStyles,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

import { optionStyles } from '@/Listbox/Option';

const GroupCheckbox = styled(InputCheckbox)`
  ${optionStyles};
  justify-content: flex-start;
  gap: ${getSpace(2)};
  ${LabelText} {
    ${textEllipsisStyles};
  }
`;

export type MultiSelectGroupHeaderProps<T> = {
  value: T[];
  onChange(value: T[]): void;
  label: string;
  optionValues: T[];
  disabled?: boolean;
};

export const MultiSelectGroupHeader = <T,>({
  value: selected,
  label,
  optionValues,
  disabled,
  onChange,
}: MultiSelectGroupHeaderProps<T>) => {
  const checked = optionValues.every((v) => selected.includes(v));
  const indeterminate =
    !checked && optionValues.some((v) => selected.includes(v));

  return (
    <GroupCheckbox
      align="center"
      size="sm"
      width="100%"
      label={label}
      labelSize="md"
      tabIndex={-1}
      role="option"
      checked={checked}
      disabled={disabled}
      indeterminate={indeterminate}
      onChange={() => {
        if (!Array.isArray(selected)) {
          return;
        }
        let newValues: T[] = [...selected];
        if (indeterminate || checked) {
          newValues = selected.filter((item) => !optionValues.includes(item));
        }
        if (indeterminate || !checked) {
          newValues = newValues.concat(optionValues);
        }
        onChange(newValues);
      }}
      data-testid={`option-group-checkbox-${label
        .replace(/[^\w]/g, '-')
        .toLowerCase()}`}
    />
  );
};
