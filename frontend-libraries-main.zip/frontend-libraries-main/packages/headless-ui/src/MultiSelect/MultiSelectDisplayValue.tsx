import {
  ScreenReaderText,
  SelectOption,
  SelectOptions,
  UIText,
  getColor,
  getRadius,
  getSize,
  getSpace,
  getSpacing,
  getUITextStyles,
  isSelectOption,
} from '@nationalgrid-engineering/styled-components';
import { Fragment, useMemo } from 'react';
import styled from 'styled-components';

import { MultiSelectOptionsProp } from './MultiSelectOptions';

const MultiPreviewWrapper = styled.div`
  display: flex;
  align-items: stretch;
  gap: ${getSpace()};
  flex: 1;
  flex-wrap: nowrap;
  overflow-x: hidden;
  height: ${getSize(8)};
  padding: ${getSpacing('1.5 0')};
  box-sizing: border-box;
`;

const PreviewTag = styled.span`
  flex-shrink: 0;
  display: flex;
  align-items: center;
  padding: ${getSpacing('0 1')};
  ${getUITextStyles({ size: 'sm' })};
  border: 1px solid ${getColor('border')};
  border-radius: ${getRadius()};
  background: ${getColor('bg')};
`;

type PlaceholderProps = {
  placeholder: string;
};

type SelectValueProps<T> = {
  options: SelectOptions<T> | MultiSelectOptionsProp<T>;
  value: T | T[];
} & PlaceholderProps;

const Placeholder = ({ placeholder }: PlaceholderProps) => (
  <UIText color="fgPlaceholder">{placeholder}</UIText>
);

const flattenOptions = <T,>(
  options: SelectOptions<T> | MultiSelectOptionsProp<T>,
): SelectOption<T>[] =>
  options.reduce<SelectOption<T>[]>((acc, group) => {
    if (isSelectOption(group)) {
      acc.push(group as SelectOption<T>);
      return acc;
    }
    return acc.concat(flattenOptions(group.options));
  }, []);

export function MultiSelectDisplayValue<T>({
  options,
  value,
  placeholder,
}: SelectValueProps<T>) {
  const flatOptions = useMemo(() => flattenOptions(options), [options]);
  const empty = <Placeholder placeholder={placeholder} />;

  if (!value) {
    return empty;
  }

  if (!Array.isArray(value)) {
    const label = flatOptions.find((item) => item.value === value)?.label;
    if (!label) {
      return empty;
    }
    return <UIText>{label}</UIText>;
  }

  if (value.length < 1) {
    return empty;
  }

  if (value.length >= 3) {
    return <UIText>{value.length} selected</UIText>;
  }

  return (
    <MultiPreviewWrapper>
      {value.map((item, i) => {
        const label = flatOptions.find((j) => j.value === item)?.label;
        if (!label) {
          return null;
        }
        return (
          <Fragment key={item as string}>
            <PreviewTag>{label}</PreviewTag>
            {i < value.length - 1 ? (
              <ScreenReaderText>, </ScreenReaderText>
            ) : null}
          </Fragment>
        );
      })}
    </MultiPreviewWrapper>
  );
}
