import {
  SelectOption,
  isSelectOption,
} from '@nationalgrid-engineering/styled-components';

import { ListboxCheckboxOption } from '@/Listbox/ListboxCheckboxOption';

import {
  MultiSelectGroupHeader,
  MultiSelectGroupHeaderProps,
} from './MultiSelectGroupHeader';
import { MultiSelectGroupWrapper } from './MultiSelectGroupWrapper';

export type MultiSelectOptionGroup<T = string> = {
  options: MultiSelectOptionsProp<T>;
  label: string;
  disabled?: boolean;
};

export type MultiSelectOptionsProp<T = string> = (
  | MultiSelectOptionGroup<T>
  | SelectOption<T>
)[];

type SelectOptionGroupProps<T> = MultiSelectGroupHeaderProps<T> & {
  options: MultiSelectOptionsProp<T>;
  depth?: number;
};

const MultiSelectGroup = <T,>({
  options,
  onChange,
  depth = 1,
  ...rest
}: SelectOptionGroupProps<T>) => {
  const selected = rest.value;
  if (!Array.isArray(selected)) {
    return null;
  }

  return (
    <>
      <MultiSelectGroupHeader {...rest} onChange={onChange} />
      <MultiSelectGroupWrapper role="group">
        <MultiSelectOptions
          options={options}
          onChange={onChange}
          value={selected}
          depth={depth + 1}
        />
      </MultiSelectGroupWrapper>
    </>
  );
};

export const getGroupValues = <T,>(
  group: MultiSelectOptionGroup<T> | SelectOption<T>,
) => {
  let values: T[] = [];
  if (isSelectOption(group)) {
    values.push(group.value);
  } else {
    group.options.forEach((option) => {
      values = values.concat(getGroupValues(option));
    });
  }
  return values;
};

export const MultiSelectOptions = <T,>({
  options,
  value,
  onChange,
}: Omit<SelectOptionGroupProps<T>, 'optionValues' | 'label'>) =>
  options.map((option, i) =>
    isSelectOption(option) ? (
      <ListboxCheckboxOption {...option} key={option.value as string}>
        {option.label}
      </ListboxCheckboxOption>
    ) : (
      <MultiSelectGroup
        {...option}
        key={i}
        optionValues={getGroupValues(option)}
        value={value}
        onChange={onChange}
      />
    ),
  );
