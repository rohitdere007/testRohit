import {
  SelectOptions,
  inputSizeStyles,
  inputWidths,
} from '@nationalgrid-engineering/styled-components';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';

import { MultiSelect } from './MultiSelect';
import { MultiSelectOptionsProp } from './MultiSelectOptions';

type Story = StoryObj<typeof MultiSelect>;

const options = [
  { value: 'a', label: 'Option A' },
  { value: 'b', label: 'Option B' },
  {
    value: 'c',
    label: 'Option C Option C Option C Option C Option C Option C ',
  },
];

const options2 = [
  { value: 'd', label: 'Option D' },
  { value: 'e', label: 'Option E' },
  { value: 'f', label: 'Option F' },
];

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

export default {
  component: MultiSelect,
  args: {
    value: [],
    label: 'Pick some option',
    placeholder: 'Select option',
  },
  argTypes: {
    size: {
      control: {
        type: 'select',
      },
      description:
        'the height of the input field which matches the button sizes',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    optionsSize: {
      control: {
        type: 'select',
      },
      description: 'the width of the dropdown containing the options',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'undefined' },
      },
    },
    anchor: {
      control: {
        type: 'select',
      },
      options: [
        'top',
        'top start',
        'top end',
        'bottom',
        'bottom start',
        'bottom end',
        'left',
        'left start',
        'left end',
        'right',
        'right start',
        'right end',
        'selection',
        'selection start',
        'selection end',
      ],
      defaultValue: '',
      description: 'The position of the dropdown relative to the trigger',
    },
    zIndex: {
      control: { type: 'number' },
      defaultValue: '',
      description: 'The z-index value of the options dropdown',
      table: {
        type: { summary: 'string' },
      },
    },
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'a placeholder value for the input',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '' },
      },
    },

    options: {
      control: false,
      description: 'The options associated with the select',
      table: {
        type: { summary: `{ label: string, value: string}[]` },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the input is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description:
        "If the input value is invalid but shouldn't use default browser messaging.",
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    invalid: {
      control: { type: 'boolean' },
      description: 'If the input value is invalid',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  render({ defaultValue, onChange, options: optionsProp, ...props }) {
    const [, updateArgs] = useArgs();
    return (
      <MultiSelect
        {...props}
        options={optionsProp as SelectOptions<string>}
        onChange={(v) => {
          onChange?.(v);
          updateArgs({ value: v });
        }}
      />
    );
  },
} satisfies Meta<typeof MultiSelect>;

export const MultiSelectStory: Story = {
  name: 'MultiSelect',
  args: {
    label: 'Pick some options',
    options,
  },
};

const groups: MultiSelectOptionsProp = [
  {
    label: 'Group One',
    options,
  },
  {
    label: 'Group Two Group Two Group Two Group Two Group Two Group Two ',
    options: options2,
  },
];

export const MultiSelectGroups: Story = {
  name: 'MultiSelect with Groups',
  args: {
    label: 'Pick some options',
    options: groups,
  },
};
