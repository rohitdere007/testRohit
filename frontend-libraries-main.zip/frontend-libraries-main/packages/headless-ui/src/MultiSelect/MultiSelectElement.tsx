import { Listbox, ListboxProps } from '@headlessui/react';
import { AnchorProps } from '@headlessui/react/dist/internal/floating';
import {
  DropdownWrapperProps,
  FieldProps,
  InputSharedStylesProps,
  InputWidth,
  forwardRefGeneric,
  inputWidths,
} from '@nationalgrid-engineering/styled-components';

import { useAnchorProp } from '@/anchor';
import { ListboxButtonStyled } from '@/Listbox/ListboxButtonStyled';
import {
  ListboxOptionsStyled,
  ListboxOptionsStyledProps,
} from '@/Listbox/ListboxOptionsStyled';

import { MultiSelectDisplayValue } from './MultiSelectDisplayValue';
import {
  MultiSelectOptions,
  MultiSelectOptionsProp,
} from './MultiSelectOptions';

type MultiSelectBaseProps<T> = {
  placeholder: string;
  options: MultiSelectOptionsProp<T>;
  value: T[];
  onChange(value: T[]): void;
};

export type MultiSelectElementProps<T> = ListboxOptionsStyledProps &
  Omit<
    ListboxProps<'div', T>,
    | 'defaultValue'
    | 'children'
    | 'value'
    | 'multiple'
    | 'onChange'
    | 'horizontal'
  > &
  MultiSelectBaseProps<T>;

export type MultiSelectProps<T> = Omit<DropdownWrapperProps, 'size'> & {
  optionsSize?: InputWidth;
} & Omit<FieldProps, 'children' | 'as'> &
  InputSharedStylesProps &
  MultiSelectElementProps<T>;

const MultiSelectInput = <T,>({
  value,
  onChange,
  placeholder,
  options,
  anchor = 'bottom start',
  error,
  invalid,
  size,
  width,
  modal,
  portal,
  unmount,
  optionsSize,
  zIndex,
  static: staticProp,
  by,
  name,
  form,
  className,
  readOnly,
  ...props
}: MultiSelectProps<T>) => {
  const a = useAnchorProp(anchor as AnchorProps);
  const disabled = props.disabled || props['aria-disabled'];
  const optionsWidth = optionsSize || 'md';

  return (
    <Listbox
      value={value}
      onChange={onChange}
      multiple
      by={by}
      name={name}
      form={form}
    >
      <ListboxButtonStyled
        invalid={invalid}
        error={error}
        size={size}
        width={width}
        disabled={disabled}
        readOnly={readOnly}
      >
        <MultiSelectDisplayValue
          options={options}
          value={value}
          placeholder={placeholder}
        />
      </ListboxButtonStyled>
      <ListboxOptionsStyled
        anchor={a}
        modal={modal}
        portal={portal}
        unmount={unmount}
        size={inputWidths[optionsWidth] || optionsWidth}
        zIndex={zIndex}
        static={staticProp}
        className={className}
      >
        <MultiSelectOptions
          options={options}
          value={value}
          onChange={onChange}
        />
      </ListboxOptionsStyled>
    </Listbox>
  );
};

export const MultiSelectElement = forwardRefGeneric(MultiSelectInput);
