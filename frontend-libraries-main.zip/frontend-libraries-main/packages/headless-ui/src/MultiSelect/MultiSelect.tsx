import {
  Field,
  forwardRefGeneric,
} from '@nationalgrid-engineering/styled-components';

import { MultiSelectElement, MultiSelectProps } from './MultiSelectElement';

const MultiSelectField = <T,>(
  { label, hideLabel, size = 'md', width, ...props }: MultiSelectProps<T>,
  ref: React.ForwardedRef<HTMLElement>,
) => (
  <Field label={label} hideLabel={hideLabel} size={size} width={width}>
    <MultiSelectElement
      {...props}
      ref={ref}
      size={size}
      width={width}
      label={label}
    />
  </Field>
);

export const MultiSelect = forwardRefGeneric(MultiSelectField);
