import {
  getSpacing,
  getUITextStyles,
  textEllipsisStyles,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

export const SelectGroupHeader = styled.div`
  ${getUITextStyles({ size: 'sm', color: 'fg Subtle', weight: 'semi-bold' })}
  padding: ${getSpacing('1 2')};
  pointer-events: none;
  ${textEllipsisStyles};
`;
