import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { JestTheme } from '@/testUtils';

import { Select } from './Select';
import { SelectProps } from './SelectElement';

global.ResizeObserver = class FakeResizeObserver {
  observe() {}
  disconnect() {}
  unobserve() {}
};

global.ResizeObserver = class FakeResizeObserver {
  observe() {}
  disconnect() {}
  unobserve() {}
};

const params = { wrapper: JestTheme };

const options = [
  { value: 'a', label: 'Option A' },
  { value: 'b', label: 'Option B' },
  { value: 'c', label: 'Option C' },
];

describe('Single Select', () => {
  const props: SelectProps<string> = {
    options,
    label: 'Pick an option',
    placeholder: 'select option',
    value: 'a',
    onChange: jest.fn(),
  };

  it('renders the component with a label', () => {
    render(<Select {...props} />, params);
    expect(screen.getByText(props.label)).toBeDefined();
    expect(screen.getByRole('button')).toHaveTextContent('Option A');
  });

  it('handles changes', async () => {
    render(<Select {...props} />, params);

    // open the dropdown
    await userEvent.click(screen.getByRole('button'));

    // click a different option
    await userEvent.click(screen.getByRole('option', { name: 'Option B' }));

    expect(props.onChange).toHaveBeenCalledWith('b');
  });
});
