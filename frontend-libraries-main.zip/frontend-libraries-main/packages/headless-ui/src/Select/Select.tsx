import {
  Field,
  forwardRefGeneric,
} from '@nationalgrid-engineering/styled-components';

import { SelectElement, SelectProps } from './SelectElement';

export const SelectField = <T,>(
  {
    id,
    label,
    message,
    hideLabel,
    width,
    tooltip,
    size = 'md',
    ...props
  }: SelectProps<T>,
  ref: React.ForwardedRef<HTMLElement>,
) => (
  <Field
    id={id}
    label={label}
    message={message}
    required={props.required || !!props['aria-required']}
    error={props.error}
    hideLabel={hideLabel}
    width={width}
    tooltip={tooltip}
    size={size}
  >
    <SelectElement
      {...props}
      ref={ref}
      size={size}
      width={width}
      label={label}
    />
  </Field>
);

export const Select = forwardRefGeneric(SelectField);
