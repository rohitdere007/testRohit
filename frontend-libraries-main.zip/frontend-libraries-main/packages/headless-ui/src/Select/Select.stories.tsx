import {
  SelectOption,
  SelectOptionGroup,
  SelectOptions,
  inputSizeStyles,
  inputWidths,
} from '@nationalgrid-engineering/styled-components';
import { action } from '@storybook/addon-actions';
import { useArgs } from '@storybook/preview-api';
import { Meta, StoryObj } from '@storybook/react';

import { Select } from './Select';

type Story = StoryObj<typeof Select>;

const inputSizeOptions = Object.keys(inputSizeStyles);
const inputWidthOptions = [undefined, ...Object.keys(inputWidths)];

const options: SelectOption[] = [
  { value: 'a', label: 'Option A' },
  { value: 'b', label: 'Option B' },
  {
    value: 'c',
    label:
      'Option C Option C Option C Option C Option C Option C Option C Option C Option C Option C',
  },
];

const options2: SelectOption[] = [
  { value: 'd', label: 'Option D' },
  { value: 'e', label: 'Option E' },
  { value: 'f', label: 'Option F' },
];

export default {
  component: Select,
  parameters: {
    actions: {
      handles: ['focus', 'blur', 'change'],
    },
  },
  args: {
    disabled: false,
    readOnly: false,
    required: false,
    invalid: false,
    hideLabel: false,
    label: 'Select Label',
    placeholder: 'Placeholder',
    options: options,
    onFocus: action('onFocus'),
    onBlur: action('onBlur'),
    onChange: action('onChange'),
  },
  argTypes: {
    size: {
      control: {
        type: 'select',
      },
      description:
        'the height of the input field which matches the button sizes',
      options: inputSizeOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputSizeOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    optionsSize: {
      control: {
        type: 'text',
      },
      description: 'the width of the dropdown containing the options',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: '"md"' },
      },
    },
    width: {
      control: {
        type: 'select',
      },
      description: 'the width of the input field',
      options: inputWidthOptions,
      defaultValue: 'md',
      table: {
        type: {
          summary: inputWidthOptions.join(' | '),
        },
        defaultValue: { summary: 'undefined' },
      },
    },
    anchor: {
      control: {
        type: 'select',
      },
      options: [
        'top',
        'top start',
        'top end',
        'bottom',
        'bottom start',
        'bottom end',
        'left',
        'left start',
        'left end',
        'right',
        'right start',
        'right end',
        'selection',
        'selection start',
        'selection end',
      ],
      defaultValue: '',
      description: 'The position of the dropdown relative to the trigger',
    },
    zIndex: {
      control: { type: 'number' },
      defaultValue: '',
      description: 'The z-index value of the options dropdown',
      table: {
        type: { summary: 'string' },
      },
    },
    label: {
      control: { type: 'text' },
      defaultValue: '',
      description: 'The label associated with the input',
      table: {
        type: { summary: 'string' },
      },
    },
    hideLabel: {
      control: { type: 'boolean' },
      description: 'If the input label is only visible to screen readers',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'a placeholder value for the input',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: '' },
      },
    },

    options: {
      control: false,
      description: 'The options associated with the select',
      table: {
        type: { summary: `{ label: string, value: string}[]` },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'If the input is disabled',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    readOnly: {
      control: { type: 'boolean' },
      description: 'If the input is read-only',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description:
        "If the input value is invalid but shouldn't use default browser messaging.",
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    invalid: {
      control: { type: 'boolean' },
      description: 'If the input value is invalid',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    'aria-required': {
      control: { type: 'boolean' },
      description:
        'If the input should be required but not prevent the form from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: { type: 'boolean' },
      description:
        'If the input value is required and should prevent the from submitting.',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    message: {
      control: { type: 'text' },
      description: 'Used for validation messages',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
  render({ defaultValue, onChange, options: optionsProp, ...props }) {
    const [, updateArgs] = useArgs();
    return (
      <Select
        {...props}
        options={optionsProp as SelectOptions<string>}
        onChange={(v) => {
          onChange?.(v);
          updateArgs({ value: v });
        }}
      />
    );
  },
} satisfies Meta<typeof Select>;

export const SelectStory: Story = {
  name: 'Select',
};

const groups: SelectOptionGroup<string>[] = [
  {
    label: 'Group One',
    options,
  },
  {
    label: 'Group Two Group Two Group Two Group Two Group Two Group Two ',
    options: options2,
  },
];

export const SelectGroups: Story = {
  name: 'Select with Groups',
  args: {
    label: 'Pick some options',
    options: groups,
  },
};
