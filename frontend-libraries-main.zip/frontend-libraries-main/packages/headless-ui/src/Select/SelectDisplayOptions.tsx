import { ListboxOption } from '@headlessui/react';
import {
  SelectOption,
  SelectOptionGroup,
  SelectOptions,
  getUITextStyles,
  textEllipsisStyles,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

import { isSingleOptions } from './SingleSelectOptions';

type SingleSelectOptionsProps<T> = {
  options: SelectOptions<T>;
};

const OptionText = styled.span`
  ${getUITextStyles()};
  ${textEllipsisStyles};
`;

const BaseOptions = <T,>({ options }: { options: SelectOption<T>[] }) =>
  options.map((item) => (
    <ListboxOption
      as={OptionText}
      value={item.value}
      key={item.value as string}
    >
      {item.label}
    </ListboxOption>
  ));

const BaseGroups = <T,>({ options }: { options: SelectOptionGroup<T>[] }) =>
  options.map((group) => (
    <BaseOptions key={group.label} options={group.options} />
  ));

export const SelectDisplayOptions = <T,>({
  options,
}: SingleSelectOptionsProps<T>) => {
  if (isSingleOptions(options)) {
    return <BaseOptions options={options} />;
  }
  return <BaseGroups options={options} />;
};
