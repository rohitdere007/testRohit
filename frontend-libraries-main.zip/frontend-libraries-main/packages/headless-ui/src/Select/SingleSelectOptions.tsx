import {
  SelectOption,
  SelectOptionGroup,
  SelectOptions,
  isSelectOption,
} from '@nationalgrid-engineering/styled-components';

import { ListboxTickOption } from '@/Listbox/ListboxTickOption';

import { SelectGroupHeader } from './SelectGroupHeader';

type SingleSelectOptionsProps<T> = {
  options: SelectOptions<T>;
};

const BaseOptions = <T,>({ options }: { options: SelectOption<T>[] }) =>
  options.map((item) => (
    <ListboxTickOption value={item.value} key={item.value as string}>
      {item.label}
    </ListboxTickOption>
  ));

const SingleSelectGroups = <T,>({
  options,
}: {
  options: SelectOptionGroup<T>[];
}) =>
  options.map((group) => (
    <>
      <SelectGroupHeader>{group.label}</SelectGroupHeader>
      <BaseOptions options={group.options} />
    </>
  ));

export const isSingleOptions = <T,>(
  options: SelectOptions<T>,
): options is SelectOption<T>[] => isSelectOption(options[0]);

export const SingleSelectOptions = <T,>({
  options,
}: SingleSelectOptionsProps<T>) => {
  if (isSingleOptions(options)) {
    return <BaseOptions options={options} />;
  }
  return <SingleSelectGroups options={options} />;
};
