import {
  getUITextStyles,
  textEllipsisStyles,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

export const SelectPlaceholder = styled.span`
  ${getUITextStyles({ color: 'fgPlaceholder' })};
  ${textEllipsisStyles};
`;
