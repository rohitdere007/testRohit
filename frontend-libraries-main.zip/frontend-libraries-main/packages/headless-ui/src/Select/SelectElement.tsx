import {
  Listbox,
  ListboxProps,
  ListboxSelectedOption,
} from '@headlessui/react';
import { AnchorProps } from '@headlessui/react/dist/internal/floating';
import {
  DropdownWrapperProps,
  FieldProps,
  InputSharedStylesProps,
  InputWidth,
  SelectOptions,
  forwardRefGeneric,
  inputWidths,
} from '@nationalgrid-engineering/styled-components';

import { useAnchorProp } from '@/anchor';
import { ListboxButtonStyled } from '@/Listbox/ListboxButtonStyled';
import {
  ListboxOptionsStyled,
  ListboxOptionsStyledProps,
} from '@/Listbox/ListboxOptionsStyled';

import { SelectDisplayOptions } from './SelectDisplayOptions';
import { SelectPlaceholder } from './SelectPlaceholder';
import { SingleSelectOptions } from './SingleSelectOptions';

type SingleSelectBaseProps<T = string> = {
  placeholder: string;
  options: SelectOptions<T>;
  value?: T | undefined;
  defaultValue?: T | undefined;
  onChange?: (value: T) => void;
};

export type SelectElementProps<T> = ListboxOptionsStyledProps &
  Omit<
    ListboxProps<'div', T>,
    | 'defaultValue'
    | 'children'
    | 'value'
    | 'multiple'
    | 'onChange'
    | 'horizontal'
  > &
  SingleSelectBaseProps<T>;

export type SelectProps<T> = Omit<DropdownWrapperProps, 'size' | 'onChange'> & {
  optionsSize?: InputWidth;
} & Omit<FieldProps, 'children' | 'as'> &
  InputSharedStylesProps &
  SelectElementProps<T>;

const SelectInput = <T,>(
  {
    value,
    defaultValue,
    onChange,
    placeholder,
    options,
    anchor = 'bottom start',
    error,
    invalid,
    size,
    width,
    modal,
    portal,
    unmount,
    optionsSize,
    zIndex,
    by,
    name,
    form,
    className,
    readOnly,
    ...props
  }: SelectProps<T>,
  ref: React.ForwardedRef<HTMLElement>,
) => {
  const a = useAnchorProp(anchor as AnchorProps);
  const disabled = props.disabled || props['aria-disabled'];
  const optionsWidth = optionsSize || 'md';

  return (
    <Listbox
      value={value}
      onChange={onChange}
      defaultValue={defaultValue}
      by={by}
      name={name}
      form={form}
      ref={ref}
    >
      <ListboxButtonStyled
        invalid={invalid}
        error={error}
        size={size}
        width={width}
        disabled={disabled}
        readOnly={readOnly}
      >
        <ListboxSelectedOption
          options={<SelectDisplayOptions options={options} />}
          placeholder={<SelectPlaceholder>{placeholder}</SelectPlaceholder>}
        />
      </ListboxButtonStyled>
      <ListboxOptionsStyled
        anchor={a}
        modal={modal}
        portal={portal}
        unmount={unmount}
        size={inputWidths[optionsWidth] || optionsWidth}
        zIndex={zIndex}
        className={className}
      >
        <SingleSelectOptions options={options} />
      </ListboxOptionsStyled>
    </Listbox>
  );
};

export const SelectElement = forwardRefGeneric(SelectInput);
