import { AnchorProps } from '@headlessui/react/dist/internal/floating';
import { useMemo } from 'react';

const getAnchorProp = (anchor: AnchorProps): AnchorProps => {
  const to = typeof anchor === 'object' ? anchor.to : anchor;
  if (typeof to === 'boolean') {
    return to;
  }
  return {
    gap: '4px',
    ...(typeof anchor === 'object' ? anchor : {}),
    to,
  };
};

export const useAnchorProp = (anchor: AnchorProps): AnchorProps =>
  useMemo(() => getAnchorProp(anchor), [anchor]);
