import {
  getColor,
  getRadius,
  getSpace,
} from '@nationalgrid-engineering/styled-components';
import { HTMLAttributes } from 'react';
import styled, { css } from 'styled-components';

export type OptionProps = HTMLAttributes<HTMLDivElement> & {
  disabled?: boolean;
};

export const optionStyles = css`
  padding: ${getSpace(2)};
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: ${getRadius(1.5)};
  overflow: hidden;
  gap: ${getSpace()};
  width: 100%;
  box-sizing: border-box;
  &:focus,
  &:focus-visible,
  &:focus-within {
    outline: none;
  }

  &:hover {
    background: ${getColor('bg')};
  }

  &[aria-selected='true'] {
    background: ${getColor('bgInfoSubtlest')};

    &:hover,
    &:focus {
      background: ${getColor('bgInfoSubtlestHover')};
    }
  }
`;

export const Option = styled.div<OptionProps>`
  ${optionStyles};
`;

Option.displayName = 'Option';
