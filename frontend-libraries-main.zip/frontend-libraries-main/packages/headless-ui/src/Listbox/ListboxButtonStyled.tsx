import { ListboxButton, ListboxButtonProps } from '@headlessui/react';
import { mdiChevronDown } from '@mdi/js';
import {
  Icon,
  InputSharedStylesProps,
  getColor,
  getRadius,
  getSize,
  getSpace,
  getSpacing,
  getUITextStyles,
  inputSharedStyles,
} from '@nationalgrid-engineering/styled-components';
import styled, { css } from 'styled-components';

type ListboxButtonWrapperProps = Omit<InputSharedStylesProps, 'label'>;
const ListboxButtonWrapper = styled.button<ListboxButtonWrapperProps>`
  border-radius: ${getRadius()};
  ${getUITextStyles({ color: 'fg', weight: 'regular' })};
  padding: ${getSpacing('0 1.5')};
  height: ${getSize(8)};
  width: 100%;
  text-align: left;
  display: flex;
  justify-content: space-between;
  flex-direction: row-reverse;
  align-items: center;

  border: 1px solid ${getColor('border')};
  ${getUITextStyles({ color: 'fg', weight: 'regular' })};

  box-sizing: border-box;
  background: ${getColor('bgPrimary')};
  ${inputSharedStyles};
  &:focus-within {
    outline: 1px solid ${getColor('borderInfo')} !important;
  }
  gap: ${getSpace(1)};
`;

export const ListboxButtonStyled = ({
  children,
  ...props
}: ListboxButtonProps<typeof ListboxButtonWrapper>) => (
  <ListboxButton as={ListboxButtonWrapper} {...props}>
    {(args) => (
      <>
        <ChevronWrapper>
          {!props.readOnly && (
            <Chevron icon={mdiChevronDown} rotate={args.open} />
          )}
        </ChevronWrapper>
        {typeof children === 'function' ? children(args) : children}
      </>
    )}
  </ListboxButton>
);

const ChevronWrapper = styled.div`
  border-left: 1px solid ${getColor('border')};
  padding-left: ${getSpace(1.5)};
  display: flex;
`;

const Chevron = styled(Icon).withConfig({
  shouldForwardProp: (p) => p !== 'rotate',
})<{ rotate?: boolean }>`
  transition: transform 200ms ease-in-out;

  @media (prefers-reduced-motion) {
    transition-duration: 0ms;
  }

  ${({ rotate }) =>
    rotate &&
    css`
      transform: rotate(180deg);
    `}
`;
