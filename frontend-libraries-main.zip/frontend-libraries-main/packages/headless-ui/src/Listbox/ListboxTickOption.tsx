import {
  ListboxOptionProps,
  ListboxOption as UIListboxOption,
} from '@headlessui/react';
import { mdiCheck } from '@mdi/js';
import {
  Icon,
  TextEllipsis,
} from '@nationalgrid-engineering/styled-components';
import { forwardRef } from 'react';

import { Option, OptionProps } from './Option';

const TickOption = forwardRef<HTMLDivElement, OptionProps>(
  ({ children, ...props }, ref) => (
    <Option {...props} ref={ref}>
      <TextEllipsis>{children}</TextEllipsis>
      {props['aria-selected'] && (
        <Icon size="sm" icon={mdiCheck} color="bgInfo" />
      )}
    </Option>
  ),
);
TickOption.displayName = 'TickOption';

export const ListboxTickOption = <T = string,>(
  props: ListboxOptionProps<'div', T>,
) => <UIListboxOption {...props} as={TickOption} />;
