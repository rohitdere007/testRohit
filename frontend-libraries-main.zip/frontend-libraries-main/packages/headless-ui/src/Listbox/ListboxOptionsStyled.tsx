import { ListboxOptions, ListboxOptionsProps } from '@headlessui/react';
import {
  dropdownScrollStyles,
  getSize,
  getSpace,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

import { DropdownTransitionWrapper } from '@/Dropdown';

const OptionsWrapper = styled(DropdownTransitionWrapper)`
  ${dropdownScrollStyles};
  padding: ${getSpace(2)};
  gap: ${getSpace()};
  max-height: ${getSize(100)};
  overflow-y: auto;
`;

export type ListboxOptionsStyledProps = Omit<
  ListboxOptionsProps<typeof OptionsWrapper>,
  'onChange' | 'onBlur' | 'onFocus'
>;

export const ListboxOptionsStyled = (props: ListboxOptionsStyledProps) => (
  <ListboxOptions transition modal={false} {...props} as={OptionsWrapper} />
);
