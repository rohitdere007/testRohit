import {
  ListboxOptionProps,
  ListboxOption as UIListboxOption,
} from '@headlessui/react';
import {
  InputCheckbox,
  TextEllipsis,
  getSpace,
} from '@nationalgrid-engineering/styled-components';
import { forwardRef } from 'react';
import styled from 'styled-components';

import { Option, OptionProps } from './Option';

const CheckboxWrapper = styled.div`
  pointer-events: none;
`;

const CheckOption = styled(Option)`
  gap: ${getSpace(2)};
  justify-content: flex-start;
`;

const CheckboxOption = forwardRef<HTMLDivElement, OptionProps>(
  ({ children, ...props }, ref) => (
    <CheckOption {...props} ref={ref}>
      <CheckboxWrapper aria-hidden="true">
        <InputCheckbox
          size="sm"
          label={children as string}
          hideLabel
          checked={!!props['aria-selected']}
          readOnly
          disabled={props.disabled}
        />
      </CheckboxWrapper>
      <TextEllipsis>{children}</TextEllipsis>
    </CheckOption>
  ),
);

CheckboxOption.displayName = 'CheckboxOption';

export const ListboxCheckboxOption = <T = string,>(
  props: ListboxOptionProps<'div', T>,
) => <UIListboxOption {...props} as={CheckboxOption} />;
