import { Popover, PopoverPanel, PopoverPanelProps } from '@headlessui/react';
import {
  DropdownWrapper,
  type DropdownWrapperProps,
} from '@nationalgrid-engineering/styled-components';
import React, { forwardRef } from 'react';
import styled from 'styled-components';

import { useAnchorProp } from '@/anchor';

export type DropdownProps = PopoverPanelProps<'div'> &
  DropdownWrapperProps & {
    handle: React.ReactNode;
    style?: React.CSSProperties | undefined;
  };

export const DropdownTransitionWrapper = styled(DropdownWrapper)`
  transition:
    opacity 200ms ease-in-out,
    transform 200ms ease-in-out;

  @media (prefers-reduced-motion) {
    transition: opacity 200ms ease-in-out;
  }

  &[data-closed] {
    opacity: 0;
    transform: scale(0.9);
  }
`;

export const Dropdown = forwardRef<HTMLDivElement, DropdownProps>(
  (
    { handle, children, anchor = 'bottom start', size = 'lg', style, ...rest },
    ref,
  ) => {
    const a = useAnchorProp(anchor);
    return (
      <Popover style={style}>
        {handle}
        <PopoverPanel
          transition
          {...rest}
          ref={ref}
          anchor={a}
          as={DropdownTransitionWrapper}
          size={size}
        >
          {children}
        </PopoverPanel>
      </Popover>
    );
  },
);

Dropdown.displayName = 'Dropdown';
