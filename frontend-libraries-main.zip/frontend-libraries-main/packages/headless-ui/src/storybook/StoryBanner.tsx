import {
  Notification,
  ThemeProvider,
  UIText,
} from '@nationalgrid-engineering/styled-components';

export const StoryBanner = () => (
  <ThemeProvider>
    <Notification variant="info">
      <Notification.Body>
        <Notification.Title title="Please Note:" />
        <UIText>
          This component requires the{' '}
          <UIText weight="semi-bold">
            @nationalgrid-engineering/headless-ui
          </UIText>{' '}
          and <UIText weight="semi-bold">@headlessui/react</UIText> packages to
          be installed before usage.
        </UIText>
      </Notification.Body>
    </Notification>
  </ThemeProvider>
);
