import type { Config } from '@jest/types';
import { pathsToModuleNameMapper } from 'ts-jest';

import { compilerOptions } from './tsconfig.json';

// eslint-disable-next-line import/no-default-export
export default {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['./jest.setup.ts'],
  moduleNameMapper: {
    '^@nationalgrid-engineering/(.*)': '<rootDir>/../$1',
    ...pathsToModuleNameMapper(compilerOptions.paths),
  },
  modulePaths: [compilerOptions.baseUrl],
  roots: ['<rootDir>'],
  transform: {
    '^.+\\.[t|j]sx?$': 'babel-jest',
  },
  collectCoverage: true,
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.stories.{ts,tsx}',
  ],
} satisfies Config.InitialOptions;
