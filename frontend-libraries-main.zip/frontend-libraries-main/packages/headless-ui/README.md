# Introduction

## National Grid Experience System - Headless UI
### @nationalgrid-engineering/headless-ui

This package provides an implementation of [@headlessui/react](https://headlessui.com/v1) with our experience system styles.

## Setup

It is assumed that you have already gone through the setup process for the `@nationalgrid-engineering/styled-components` library before attempting to setup this package. You can find instructions to do this (here)[https://curly-telegram-9ko6qwn.pages.github.io].

To add this package to your codebase after completing that process, navigate to your codebase in the terminal and then run the following:

```bash
yarn add @headlessui/react @nationalgrid-engineering/headless-ui
```
