import { getColor } from '@nationalgrid-engineering/styled-components';
import { PopoverPosition as PopoverPositionType } from 'react-tiny-popover';
import styled, { css } from 'styled-components';

export interface PopoverCaretTipProps {
  position?: PopoverPositionType;
  $inverse?: boolean;
}

const getRotation = ({ position }: PopoverCaretTipProps) => {
  switch (position) {
    case 'top':
      return '180deg';
    case 'left':
      return '90deg';
    case 'right':
      return '270deg';
    case 'bottom':
    default:
      return 0;
  }
};

export const popoverGap = '4px';
export const popoverBorderSize = '1px';
export const caretTipHeight = '8px';
export const caretTipWidth = '16px';

const CaretTip = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'position',
})<PopoverCaretTipProps>`
  z-index: 1000;
  position: absolute;
  inset: 0;

  path {
    fill: ${({ $inverse }) =>
      $inverse ? getColor('bgInverse') : getColor('bgPrimary')};
  }

  svg {
    transform: rotate(${getRotation});
    width: ${caretTipWidth};
    height: ${caretTipHeight};
  }

  width: ${caretTipWidth};
  height: ${caretTipHeight};

  ${({ position }) => {
    switch (position) {
      case 'right':
        return css`
          top: calc(50% - ${popoverGap});
          left: calc(-${popoverGap} + ${popoverBorderSize});
          height: ${caretTipWidth};
        `;
      case 'left':
        return css`
          top: calc(50% - ${popoverGap});
          left: calc(
            100% - ${caretTipWidth} + ${popoverGap} - ${popoverBorderSize}
          );
          height: ${caretTipWidth};
        `;
      case 'top':
        return css`
          left: calc(50% - ${caretTipHeight});
          top: calc(100% - ${caretTipHeight} - ${popoverBorderSize});
        `;
      case 'bottom':
      default:
        return css`
          left: calc(50% - ${caretTipHeight});
          top: ${popoverBorderSize};
        `;
    }
  }};
`;

export const PopoverCaretTip = (props: PopoverCaretTipProps) => (
  <CaretTip {...props}>
    <svg viewBox="0 0 16 8" fill="none">
      <path
        d="M6.58579 1.41421C7.36684 0.633164 8.63317 0.633165 9.41421 1.41421L16 8L0 8L6.58579 1.41421Z"
        fill="white"
      />
    </svg>
  </CaretTip>
);
