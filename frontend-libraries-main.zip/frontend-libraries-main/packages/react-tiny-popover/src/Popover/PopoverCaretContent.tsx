import { getSpace } from '@nationalgrid-engineering/styled-components';
import styled, { css } from 'styled-components';

import {
  PopoverPositionProps,
  isPopoverPositionProps,
} from './PopoverPosition';

export const PopoverCaretContent = styled.div.withConfig({
  shouldForwardProp: (p) => !isPopoverPositionProps(p),
})<PopoverPositionProps>`
  position: absolute;
  ${({ position, align }) => {
    switch (align) {
      case 'start':
        switch (position) {
          case 'right':
            return css`
              left: 0;
              padding-left: ${getSpace(2)};
              margin-top: -${getSpace(6)};
            `;
          case 'left':
            return css`
              right: 0;
              padding-right: ${getSpace(2)};
              margin-top: -${getSpace(6)};
            `;
          case 'top':
            return css`
              bottom: 0;
              padding-bottom: ${getSpace(2)};
              margin-left: -${getSpace(6)};
            `;
          case 'bottom':
          default:
            return css`
              top: 0;
              padding-top: ${getSpace(2)};
              margin-left: -${getSpace(6)};
            `;
        }

      case 'end':
        switch (position) {
          case 'right':
            return css`
              bottom: -${getSpace(6)};
              padding-left: ${getSpace(2)};
              left: 0;
            `;
          case 'left':
            return css`
              bottom: -${getSpace(6)};
              padding-right: ${getSpace(2)};
              right: 0;
            `;
          case 'top':
            return css`
              right: -${getSpace(6)};
              bottom: 0;
              padding-bottom: ${getSpace(2)};
            `;
          case 'bottom':
          default:
            return css`
              right: -${getSpace(6)};
              top: 0;
              padding-top: ${getSpace(2)};
            `;
        }
      case 'center':
      default:
        switch (position) {
          case 'right':
            return css`
              left: 0;
              padding-left: ${getSpace(2)};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'left':
            return css`
              right: 0;
              padding-right: ${getSpace(2)};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'top':
            return css`
              bottom: 0;
              padding-bottom: ${getSpace(2)};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
          case 'bottom':
          default:
            return css`
              top: 0;
              padding-top: ${getSpace(2)};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
        }
    }
  }};
`;
