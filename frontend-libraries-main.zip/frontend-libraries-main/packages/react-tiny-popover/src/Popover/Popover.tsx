import {
  WidthProps,
  getSpace,
  width,
} from '@nationalgrid-engineering/styled-components';
import { ReactNode } from 'react';
import {
  Popover as TinyPopover,
  PopoverProps as TinyPopoverProps,
} from 'react-tiny-popover';
import styled from 'styled-components';

import { PopoverCaretContent } from './PopoverCaretContent';
import { PopoverCaretTip } from './PopoverCaretTip';
import { PopoverContent, PopoverContentProps } from './PopoverContent';
import { PopoverPosition } from './PopoverPosition';
import { PopoverWrapper } from './PopoverWrapper';

export interface PopoverProps
  extends PopoverContentProps,
    Omit<TinyPopoverProps, 'content' | 'children' | 'padding'>,
    WidthProps {
  children: ReactNode;
  trigger: JSX.Element;
  caretTip?: boolean;
  $inverse?: boolean;
}

const TooltipContent = styled.div<WidthProps>`
  width: max-content;
  display: flex;
  flex-direction: column;
  gap: ${getSpace()};
  ${width};
`;

export const Popover = ({
  size,
  align = 'center',
  caretTip,
  children,
  trigger,
  $inverse,
  width: widthProp,
  w,
  ...props
}: PopoverProps) => {
  const content = (
    <PopoverContent $inverse={$inverse} size={size}>
      {children}
    </PopoverContent>
  );
  return (
    <TinyPopover
      positions={['top', 'bottom']}
      reposition={true}
      align={caretTip ? 'center' : align}
      padding={0}
      {...props}
      content={({ position /** nudgedLeft, nudgedTop */ }) => (
        <PopoverWrapper position={position}>
          <PopoverPosition
            position={position}
            align={caretTip ? 'center' : align}
          >
            {caretTip ? (
              <>
                <PopoverCaretContent position={position} align={align}>
                  <TooltipContent w={w} width={widthProp}>
                    {content}
                  </TooltipContent>
                </PopoverCaretContent>
                <PopoverCaretTip $inverse={$inverse} position={position} />
              </>
            ) : (
              <TooltipContent w={w} width={widthProp}>
                {content}
              </TooltipContent>
            )}
          </PopoverPosition>
        </PopoverWrapper>
      )}
    >
      <Wrapper>{trigger}</Wrapper>
    </TinyPopover>
  );
};

const Wrapper = styled.div`
  display: block;
`;
