import { getBodyTextStyles } from '@nationalgrid-engineering/styled-components';
import styled, { css } from 'styled-components';

import {
  PopoverPositionProps,
  isPopoverPositionProps,
} from './PopoverPosition';

export const PopoverWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => !isPopoverPositionProps(p),
})<Pick<PopoverPositionProps, 'position'>>`
  position: absolute;
  display: flex;
  height: 0;
  width: 0;
  overflow: hidden;
  opacity: 0;
  inset: 0;
  transition: opacity 300ms ease-in-out;
  ${getBodyTextStyles()};

  ${({ position }) => {
    switch (position) {
      case 'right':
        return css`
          transform: translate(100%, 0);
          flex-direction: row;
        `;
      case 'left':
        return css`
          transform: translate(-100%, 0);
          flex-direction: row-reverse;
        `;
      case 'top':
        return css`
          transform: translate(0, -100%);
          flex-direction: column-reverse;
        `;
      case 'bottom':
      default:
        return css`
          transform: translate(0, 100%);
          flex-direction: column;
        `;
    }
  }}

  opacity: 1;
  height: auto;
  width: auto;
  overflow: visible;
`;
