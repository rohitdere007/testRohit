import { getSpace } from '@nationalgrid-engineering/styled-components';
import {
  PopoverAlign,
  PopoverPosition as PopoverPositionType,
} from 'react-tiny-popover';
import styled, { css } from 'styled-components';

export interface PopoverPositionProps {
  position?: PopoverPositionType;
  align?: PopoverAlign;
}

export const isPopoverPositionProps = (p: string) =>
  ['position', 'align'].includes(p);

export const PopoverPosition = styled.div.withConfig({
  shouldForwardProp: (p) => !isPopoverPositionProps(p),
})<PopoverPositionProps>`
  position: absolute;
  ${({ position, align }) => {
    switch (align) {
      case 'start':
        switch (position) {
          case 'right':
            return css`
              padding-left: ${getSpace()};
            `;
          case 'left':
            return css`
              padding-right: ${getSpace()};
            `;
          case 'top':
            return css`
              padding-bottom: ${getSpace()};
            `;
          case 'bottom':
          default:
            return css`
              padding-top: ${getSpace()};
            `;
        }

      case 'end':
        switch (position) {
          case 'right':
            return css`
              bottom: 0;
              padding-left: ${getSpace()};
            `;
          case 'left':
            return css`
              bottom: 0;
              padding-right: ${getSpace()};
            `;
          case 'top':
            return css`
              right: 0;
              padding-bottom: ${getSpace()};
            `;
          case 'bottom':
          default:
            return css`
              right: 0;
              padding-top: ${getSpace()};
            `;
        }
      case 'center':
      default:
        switch (position) {
          case 'right':
            return css`
              padding-left: ${getSpace()};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'left':
            return css`
              padding-right: ${getSpace()};
              top: 50%;
              transform: translate(0%, -50%);
            `;
          case 'top':
            return css`
              padding-bottom: ${getSpace()};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
          case 'bottom':
          default:
            return css`
              padding-top: ${getSpace()};
              left: 50%;
              transform: translate(-50%, 0%);
            `;
        }
    }
  }};
`;
