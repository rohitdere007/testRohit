import { Button, UIText } from '@nationalgrid-engineering/styled-components';
import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import styled from 'styled-components';

import { Popover } from './Popover';

export default {
  component: Popover,
  args: {
    caretTip: true,
  },
  parameters: {
    layout: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '400px',

    docs: {
      description: {
        component:
          "The `Popover` component uses `react-tiny-popover`'s `Popover` component to create a dropdown menu that is triggered either by the default `IconButton` or a custom trigger if passed as a prop value.",
      },
    },
  },
  argTypes: {
    isOpen: {
      control: { type: 'boolean' },
      description: 'If the action list is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    children: {
      control: false,
      description: 'the contents of the popover',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    caretTip: {
      control: { type: 'boolean' },
      description: 'If the Popover has a caret tip',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    trigger: {
      control: false,
      description: 'A custom trigger node',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    positions: {
      control: {
        type: 'select',
      },
      options: ['top', 'bottom', 'left', 'right'],
    },
    align: {
      control: {
        type: 'select',
      },
      options: ['start', 'center', 'end'],
    },
    size: {
      control: {
        type: 'select',
      },
      options: ['sm', 'md', 'lg'],
    },
  },
} satisfies Meta<typeof Popover>;

type Story = StoryObj<typeof Popover>;

const TestContent = styled.div`
  width: 200px;
  display: flex;
  flex-direction: column;
`;
TestContent.displayName = 'TextContent';

export const Demo: Story = {
  render(props) {
    const [open, setOpen] = useState(false);

    return (
      <Popover
        {...props}
        isOpen={open}
        trigger={<Button onClick={() => setOpen(!open)}>Click Me</Button>}
      >
        <TestContent>
          <UIText weight="bold">Popover Header</UIText>
          <UIText size="sm">Popover content</UIText>
        </TestContent>
      </Popover>
    );
  },
};

export const OnHover: Story = {
  render: (props) => {
    const [open, setOpen] = useState(false);

    return (
      <div
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
      >
        <Popover {...props} isOpen={open} trigger={<Button>Hover Me</Button>}>
          <TestContent>
            <UIText weight="bold">Popover Header</UIText>
            <UIText size="sm">Popover content</UIText>
          </TestContent>
        </Popover>
      </div>
    );
  },
};
