import {
  Spacing,
  getBodyTextStyles,
  getColor,
  getRadius,
  getSpace,
  getSpacing,
} from '@nationalgrid-engineering/styled-components';
import styled from 'styled-components';

type PopoverSize = 'sm' | 'md' | 'lg';

const popoverSize: Record<PopoverSize, Spacing> = {
  sm: '2',
  md: '4',
  lg: '6',
};

export interface PopoverContentProps {
  size?: PopoverSize;
  $inverse?: boolean;
}

export const PopoverContent = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'size',
})<PopoverContentProps>`
  box-shadow: 0px 4px 16px 0px ${getColor('borderStrong')}3a;
  border-radius: ${getRadius()};
  background: ${({ $inverse }) =>
    $inverse ? getColor('bgInverse') : getColor('bgPrimary')};
  position: relative;
  outline: none;
  padding: ${getSpace(2)};
  ${({ $inverse }) =>
    $inverse
      ? getBodyTextStyles({ color: 'fgInverse' })
      : getBodyTextStyles({ color: 'fg' })};
  padding: ${({ size = 'sm', theme }) =>
    getSpacing(popoverSize[size])({ theme })};
`;
