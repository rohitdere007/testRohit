import { mdiDelete, mdiFileEdit } from '@mdi/js';
import { Button, MoonIcon } from '@nationalgrid-engineering/styled-components';
import { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import { ActionMenu } from './ActionMenu';

export default {
  component: ActionMenu,
  parameters: {
    layout: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '400px',

    docs: {
      description: {
        component:
          "The `ActionMenu` component uses `react-tiny-popover`'s `Popover` component to create a dropdown menu that is triggered either by the default `IconButton` or a custom trigger if passed as a prop value.",
      },
    },
  },
  argTypes: {
    children: {
      control: false,
      description: 'The `ActionMenu.Item`s to display when triggered',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    isOpen: {
      control: { type: 'boolean' },
      description: 'If the action list is open',
      table: {
        type: { summary: 'true | false' },
        defaultValue: { summary: 'false' },
      },
    },
    trigger: {
      control: false,
      description:
        'A custom trigger node to replace the default `IconButton` instance',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
  },
} satisfies Meta<typeof ActionMenu>;

type Story = StoryObj<typeof ActionMenu>;

export const Demo: Story = {
  render: () => {
    const [isOpen, setOpen] = useState(false);
    const toggle = () => setOpen((prev) => !prev);
    return (
      <ActionMenu
        isOpen={isOpen}
        onClickOutside={toggle}
        trigger={<ActionMenu.Trigger onClick={toggle} isOpen={isOpen} />}
      >
        <ActionMenu.Body>
          <ActionMenu.Item icon={<MoonIcon />}>Custom Icon</ActionMenu.Item>
          <ActionMenu.Item icon={mdiFileEdit}>Edit Item</ActionMenu.Item>
        </ActionMenu.Body>
        <ActionMenu.Divider />
        <ActionMenu.Body>
          <ActionMenu.Item variant="critical" icon={mdiDelete}>
            To long to put in the width of a menu
          </ActionMenu.Item>
        </ActionMenu.Body>
      </ActionMenu>
    );
  },
};

export const CustomTrigger: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const toggle = () => setOpen((prev) => !prev);
    return (
      <div>
        <ActionMenu
          trigger={<Button onClick={toggle}>Menu</Button>}
          onClickOutside={toggle}
          isOpen={open}
        >
          <ActionMenu.Item icon={<MoonIcon />}>Custom Icon</ActionMenu.Item>
          <ActionMenu.Item icon={mdiFileEdit}>Edit Item</ActionMenu.Item>
          <ActionMenu.Item variant="critical" icon={mdiDelete}>
            Remove Item
          </ActionMenu.Item>
        </ActionMenu>
      </div>
    );
  },
};

export const OnHover: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const toggle = () => setOpen((prev) => !prev);
    return (
      <div
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
      >
        <ActionMenu
          trigger={<Button onClick={toggle}>Menu</Button>}
          onClickOutside={toggle}
          isOpen={open}
        >
          <ActionMenu.Item icon={<MoonIcon />}>Custom Icon</ActionMenu.Item>
          <ActionMenu.Item icon={mdiFileEdit} chevron>
            Edit Item
          </ActionMenu.Item>
          <ActionMenu.Item variant="critical" icon={mdiDelete}>
            Remove Item
          </ActionMenu.Item>
        </ActionMenu>
      </div>
    );
  },
};
