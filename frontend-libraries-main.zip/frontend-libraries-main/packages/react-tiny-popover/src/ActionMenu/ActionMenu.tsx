import {
  DropdownContainer,
  DropdownDivider,
  DropdownWrapper,
  DropdownWrapperProps,
} from '@nationalgrid-engineering/styled-components';
import { ReactNode } from 'react';
import { Popover, PopoverProps } from 'react-tiny-popover';

import { ActionMenuBody } from './ActionMenuBody';
import { ActionMenuItem } from './ActionMenuItem';
import { ActionMenuTrigger } from './ActionMenuTrigger';

export interface ActionMenuProps
  extends Omit<PopoverProps, 'content' | 'children' | 'padding'>,
    DropdownWrapperProps {
  children: ReactNode;
  trigger: JSX.Element;
}

export const ActionMenu = ({
  children,
  trigger,
  size,
  zIndex,
  ...props
}: ActionMenuProps) => (
  <Popover
    positions={['bottom', 'top']}
    reposition={true}
    align="end"
    padding={0}
    {...props}
    content={({ position }) => (
      <DropdownContainer position={position}>
        <DropdownWrapper size={size} zIndex={zIndex}>
          {children}
        </DropdownWrapper>
      </DropdownContainer>
    )}
  >
    {trigger}
  </Popover>
);

ActionMenu.Item = ActionMenuItem;
ActionMenu.Trigger = ActionMenuTrigger;
ActionMenu.Body = ActionMenuBody;
ActionMenu.Divider = DropdownDivider;
