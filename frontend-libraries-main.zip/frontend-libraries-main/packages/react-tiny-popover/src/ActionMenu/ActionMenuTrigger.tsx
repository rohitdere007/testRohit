import { mdiDotsVertical } from '@mdi/js';
import { IconButton } from '@nationalgrid-engineering/styled-components';
import { forwardRef } from 'react';

export interface ActionMenuTriggerProps {
  isOpen: boolean | undefined;
  onClick: React.MouseEventHandler<HTMLButtonElement>;
  label?: string;
}

export const ActionMenuTrigger = forwardRef<
  HTMLButtonElement,
  ActionMenuTriggerProps
>(({ onClick, isOpen, label }, ref) => (
  <IconButton
    ref={ref}
    type="button"
    ghost
    icon={mdiDotsVertical}
    onClick={onClick}
    aria-expanded={isOpen}
    aria-label={label || 'Actions Menu'}
  />
));

ActionMenuTrigger.displayName = 'ActionMenu.Trigger';
