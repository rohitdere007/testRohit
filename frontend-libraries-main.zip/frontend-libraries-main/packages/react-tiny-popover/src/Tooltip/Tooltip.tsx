import { mdiInformationOutline } from '@mdi/js';
import {
  Icon,
  UIText,
  WidthProps,
} from '@nationalgrid-engineering/styled-components';
import { ReactNode, useState } from 'react';
import styled from 'styled-components';

import { Popover, PopoverProps } from '../Popover/Popover';

export interface TooltipProps
  extends WidthProps,
    Omit<PopoverProps, 'isOpen' | 'children' | 'trigger'> {
  heading?: string;
  text?: ReactNode;
  children?: ReactNode;
  className?: string;
  trigger?: JSX.Element;
}
const Wrapper = styled.div`
  display: block;
`;

export const Tooltip = ({
  heading,
  text,
  trigger = <Icon icon={mdiInformationOutline} size="sm" color="fgInfo" />,
  positions = ['top', 'bottom'],
  $inverse = true,
  children,
  className,
  ...props
}: TooltipProps) => {
  const [isOpen, setOpen] = useState(false);
  return (
    <Wrapper
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      className={className}
    >
      <Popover
        caretTip
        isOpen={isOpen}
        positions={positions}
        size="md"
        $inverse={$inverse}
        trigger={trigger}
        {...props}
      >
        {heading && <UIText weight="semi-bold">{heading}</UIText>}
        {text && <UIText size="sm">{text}</UIText>}
        {children}
      </Popover>
    </Wrapper>
  );
};
