import { Meta, StoryObj } from '@storybook/react';
import styled from 'styled-components';

import { Tooltip } from './Tooltip';

export default {
  component: Tooltip,
  args: {},
  parameters: {
    layout: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '400px',

    docs: {
      description: {
        component:
          'The `Tooltip` wraps the `Popover` component to create a tooltip that is triggered onHover either by the default `IconButton` or a custom trigger if passed as a prop value.',
      },
    },
  },
  argTypes: {
    trigger: {
      control: false,
      description:
        'A custom trigger node, defaults to mdiInformationOutline icon',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    heading: {
      description: 'Heading text for the Tooltip',
    },
    text: {
      description: 'Body text for the Tooltip',
    },
    positions: {
      control: {
        type: 'select',
      },
      options: ['top', 'bottom', 'left', 'right'],
    },
  },
} satisfies Meta<typeof Tooltip>;

type Story = StoryObj<typeof Tooltip>;

const TestContent = styled.div`
  width: 200px;
  display: flex;
  flex-direction: column;
`;
TestContent.displayName = 'TextContent';

export const Demo: Story = {
  render(props) {
    return (
      <Tooltip text="Important information" heading="I'm tooltip" {...props} />
    );
  },
};
