# Introduction

## National Grid Experience System - React Select
### @nationalgrid-engineering/react-select

This package provides an implementation of [react-select](https://react-select.com/props) with our experience system styles.

## Setup

It is assumed that you have already gone through the setup process for the `@nationalgrid-engineering/styled-components` library before attempting to setup this package. You can find instructions to do this (here)[https://curly-telegram-9ko6qwn.pages.github.io].

To add this package to your codebase after completing that process, navigate to your codebase in the terminal and then run the following:

```bash
yarn add @nationalgrid-engineering/react-select react-select
```

Once added, you should be able to import the `Select` component into your codebase and use it using the same sdk provided by react-select](https://react-select.com/props)

This implementation also has an `isCreatable` prop in place of using react-select's `Creatable` component.
