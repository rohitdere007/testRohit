describe('toast()', () => {
  it('outputs the message when called', () => {
    expect(true).toBe(true);
  });
});
