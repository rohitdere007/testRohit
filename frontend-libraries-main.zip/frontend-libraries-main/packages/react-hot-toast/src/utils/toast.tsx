import { ReactNode } from 'react';
import hotToast, { ToastOptions as HotToastOptions } from 'react-hot-toast';

import { Toast, ToastProps } from '../components/Toast';

type Message = Parameters<typeof hotToast.custom>[0];

export type ToastOptions = Omit<HotToastOptions, 'iconTheme' | 'style'> &
  Pick<ToastProps, 'variant'>;

export const toast = (
  message: ReactNode,
  { variant = 'info', ...options }: ToastOptions = {},
) =>
  hotToast(
    ((t: typeof hotToast & { id: string }) => (
      <Toast
        variant={variant}
        dismiss={() => {
          hotToast.dismiss(t.id);
        }}
      >
        {message}
      </Toast>
    )) as unknown as Message,
    {
      duration: variant === 'loading' ? Infinity : 4000,
      position: 'top-right',
      ...options,
      icon: null,
      style: {
        position: 'relative',
        boxSizing: 'content-box',
        background: 'transparent',
        margin: 0,
        padding: 0,
        minWidth: '288px',
        borderRadius: '4px',
      },
    },
  );

toast.dismiss = hotToast.dismiss;

type ToastVariantOptions = Omit<ToastOptions, 'variant'>;

toast.info = (message: ReactNode, options: ToastVariantOptions = {}) =>
  toast(message, options);

toast.loading = (message: ReactNode, options: ToastVariantOptions = {}) =>
  toast(message, { ...options, variant: 'loading' });

toast.success = (message: ReactNode, options: ToastVariantOptions = {}) =>
  toast(message, { ...options, variant: 'success' });

toast.error = (message: ReactNode, options: ToastVariantOptions = {}) =>
  toast(message, { ...options, variant: 'critical' });

interface ToastPropsMessages<T = null, E extends object = Error> {
  loading?: string;
  success: string | ((data: T) => string);
  error: string | ((error: E) => string);
}

interface ToastPromiseOptions {
  loading?: ToastVariantOptions;
  success?: ToastVariantOptions;
  error?: ToastVariantOptions;
  catch?: boolean;
}

toast.promise = async <T = null, E extends object = Error>(
  promise: Promise<T>,
  { success, error, loading }: ToastPropsMessages<T, E>,
  {
    catch: shouldCatch = true,
    success: successOptions,
    error: errorOptions,
  }: ToastPromiseOptions = {},
) => {
  let loadingId = '';
  try {
    if (loading) {
      loadingId = toast.loading(loading);
    }
    const data = await promise;
    if (loadingId) {
      toast.dismiss(loadingId);
    }
    toast.success(
      typeof success === 'string' ? success : success(data),
      successOptions,
    );
    return data;
  } catch (e: unknown) {
    const err = e as E;
    if (loading) {
      toast.dismiss(loadingId);
    }
    toast.error(typeof error === 'string' ? error : error(err), errorOptions);
    if (!shouldCatch) {
      throw err;
    }
  }
};
