import { mdiClose } from '@mdi/js';
import {
  IconButton,
  NotificationBody,
  NotificationIcon,
  NotificationVariant,
  SquareButton,
  getBodyTextStyles,
  getColor,
  getRadius,
  getSize,
  getSpace,
  getSpacing,
  notificationBgColor,
  notificationFgColor,
} from '@nationalgrid-engineering/styled-components';
import { PropsWithChildren } from 'react';
import styled, { css } from 'styled-components';

export type ToastVariant = NotificationVariant | 'loading';

export interface ToastProps extends PropsWithChildren {
  variant?: ToastVariant;
  dismiss?: () => void;
}

const ToastWrapper = styled.div.withConfig({
  shouldForwardProp: (p) => p !== 'variant',
})<ToastProps>`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: ${getSpace(2)};
  box-shadow: 0px 4px 16px 0px ${getColor('borderStrong')}3a;
  border-radius: ${getRadius()};
  border: none;
  padding: ${getSpacing('3 2 2 2')};
  min-width: ${getSize(72)};
  ${getBodyTextStyles({ size: 'sm', weight: 'regular', color: 'fg' })};
  ${({ variant = 'info' }) => css`
    border-left: 3px solid ${getColor(notificationFgColor[variant])};
    background: ${getColor(notificationBgColor[variant])};
  `}

  ${SquareButton} {
    margin-top: ${getSpace(-1)};
    margin-right: ${getSpace(-1)};
  }

  // override react-hot-toast margin
  margin: -4px -10px;

  ${NotificationBody} {
    padding-top: ${getSpace(1.5)};
    box-sizing: content-box;
  }
`;

export const Toast: React.FC<ToastProps> = ({
  children,
  variant = 'info',
  dismiss,
}) => (
  <ToastWrapper variant={variant === 'loading' ? 'info' : variant}>
    <NotificationIcon variant={variant} />
    <NotificationBody>{children}</NotificationBody>
    <IconButton
      ghost
      icon={mdiClose}
      aria-label="Dismiss Notification"
      onClick={dismiss}
      size="md"
    />
  </ToastWrapper>
);

Toast.displayName = 'Toast';
