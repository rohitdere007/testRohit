import {
  Button,
  notificationIcon,
} from '@nationalgrid-engineering/styled-components';
import { Meta, StoryObj } from '@storybook/react';
import { ComponentType, PropsWithChildren } from 'react';

import { ToastOptions, toast } from '../../utils/toast';
import { Toaster } from '../Toaster/';

type ToastComponent = ComponentType<PropsWithChildren<ToastOptions>>;

export default {
  component: Toaster as ToastComponent,
  title: 'Toast',
  args: {
    children: 'This is the contents of the toast message',
  },
  argTypes: {
    variant: {
      description: 'The color variant of the spinner',
      table: {
        type: {
          summary: Object.keys(notificationIcon).join(' | '),
        },
        defaultValue: { summary: '"info"' },
      },
      control: {
        type: 'select',
      },
      options: Object.keys(notificationIcon),
    },
    duration: {
      description: 'The duration the toast is shown',
      table: {
        type: {
          summary: 'number',
        },
        defaultValue: { summary: '4000' },
      },
      control: {
        type: 'number',
      },
    },
    id: {
      description: 'The id to assign the toast',
      table: {
        type: {
          summary: 'string',
        },
        defaultValue: { summary: 'undefined' },
      },
      control: {
        type: 'text',
      },
    },
    children: {
      description: 'The toast message content',
      table: {
        type: {
          summary: 'string',
        },
        defaultValue: { summary: 'undefined' },
      },
      control: {
        type: 'text',
      },
    },
  },
  parameters: {
    docs: {
      description: {
        component: 'Toaster & toast message usage',
      },
    },
    layout: 'flex',
    minHeight: '400px',
  },
  // tags: ['autodocs'],
} satisfies Meta<ToastComponent>;

type Story = StoryObj<ToastComponent>;

export const Toast: Story = {
  render: ({ children, ...options }) => {
    const onClick = () => toast(children, options);
    return (
      <>
        <Button onClick={onClick}>Trigger Toast</Button>
        <Toaster />
      </>
    );
  },
};

export const ToastPromise: Story = {
  render: () => {
    const promise = () =>
      new Promise<string>((resolve, reject) => {
        const random = Math.round(Math.random());
        setTimeout(
          () => (random ? resolve('Resolved') : reject(new Error('Rejected'))),
          3000,
        );
      });
    const onClick = () =>
      toast.promise(promise(), {
        success: (d) => d,
        error: (e) => e.message,
        loading: 'Processing...',
      });
    return (
      <>
        <Button onClick={onClick}>Trigger Toast</Button>
        <Toaster />
      </>
    );
  },
};
