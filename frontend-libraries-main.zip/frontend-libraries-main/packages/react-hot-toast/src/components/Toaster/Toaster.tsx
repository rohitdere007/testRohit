import { Toaster as HotToaster, ToasterProps } from 'react-hot-toast';

export const Toaster = (props: ToasterProps) => (
  <HotToaster position="top-right" {...props} />
);
