# Security Policy

This file outlines how to report security vulnerabilties identified for this repository.

## Reporting a Vulnerability

Please get in touch with the core engineering team via Microsoft teams who will be able to assist you and/or open an issue against the repo.
